<?php
/**
 * The searchform.php template.
 *
 * Used any time that get_search_form() is called.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Iceberg
 * @since Iceberg 2.1
 */

/*
 * Generate a unique ID for each form and a string containing an aria-label
 * if one was passed to get_search_form() in the args array.
 */
$iceberg_unique_id = iceberg_unique_id( 'search-form-' );

$iceberg_aria_label = ! empty( $args['aria_label'] ) ? 'aria-label="' . esc_attr( $args['aria_label'] ) . '"' : '';
// Backward compatibility, in case a child theme template uses a `label` argument.
if ( empty( $iceberg_aria_label ) && ! empty( $args['label'] ) ) {
	$iceberg_aria_label = 'aria-label="' . esc_attr( $args['label'] ) . '"';
}
?>
<form role="search" <?php echo esc_attr( $iceberg_aria_label ); ?> method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<div class="search-form-inner">
		<label for="<?php echo esc_attr( $iceberg_unique_id ); ?>">
			<span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'iceberg' ); ?></span>
			<input type="search" id="<?php echo esc_attr( $iceberg_unique_id ); ?>" class="search-field" placeholder="<?php echo esc_attr_x( 'Search &hellip;', 'placeholder', 'iceberg' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
		</label>
		<button type="submit" class="search-submit" aria-label="<?php echo esc_attr_x( 'Search', 'submit button', 'iceberg' ); ?>"><?php iceberg_the_theme_svg( 'search' ); ?></button>
	</div>
</form>
