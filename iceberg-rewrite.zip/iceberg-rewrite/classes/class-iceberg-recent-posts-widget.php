<?php
/**
 * Custom Recent Posts Widget
 *
 * Displays recent posts with optional thumbnails and dates.
 *
 * @since Iceberg 2.6
 */

class Iceberg_Recent_Posts_Widget extends WP_Widget
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct(
            'iceberg_recent_posts',
            esc_html__('Recent Posts (Iceberg)', 'iceberg'),
            array(
                'description' => esc_html__('Show recent posts with thumbnails and dates.', 'iceberg'),
                'classname' => 'widget-iceberg-recent-posts',
            )
        );
    }

    /**
     * Front-end display of the widget.
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget($args, $instance)
    {
        $title = !empty($instance['title']) ? apply_filters('widget_title', $instance['title']) : '';
        $count = !empty($instance['count']) ? absint($instance['count']) : 5;
        $show_date = !empty($instance['show_date']);
        $show_thumb = !empty($instance['show_thumb']);
        $category = isset($instance['category']) ? absint($instance['category']) : 0;

        $query_args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => max(1, min(12, $count)),
            'no_found_rows' => true,
            'ignore_sticky_posts' => true,
        );

        if ($category > 0) {
            $query_args['cat'] = $category;
        }

        $recent = new WP_Query($query_args);

        if (!$recent->have_posts()) {
            wp_reset_postdata();
            return;
        }

        echo $args['before_widget'];

        if ($title) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }
        ?>

        <ul class="iceberg-recent-posts">
            <?php while ($recent->have_posts()): $recent->the_post(); ?>
                <li class="iceberg-recent-post">
                    <?php if ($show_thumb && has_post_thumbnail()): ?>
                        <a class="iceberg-recent-post__thumb" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
                            <?php the_post_thumbnail('thumbnail', array('loading' => 'lazy')); ?>
                        </a>
                    <?php endif; ?>

                    <div class="iceberg-recent-post__body">
                        <a class="iceberg-recent-post__title" href="<?php the_permalink(); ?>">
                            <?php the_title(); ?>
                        </a>
                        <?php if ($show_date): ?>
                            <time class="iceberg-recent-post__date" datetime="<?php echo esc_attr(get_the_date('c')); ?>">
                                <?php echo esc_html(get_the_date()); ?>
                            </time>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endwhile; ?>
        </ul>

        <?php
        echo $args['after_widget'];
        wp_reset_postdata();
    }

    /**
     * Back-end widget form.
     *
     * @param array $instance Previously saved values from database.
     * @return void
     */
    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $count = !empty($instance['count']) ? absint($instance['count']) : 5;
        $show_date = !empty($instance['show_date']);
        $show_thumb = !empty($instance['show_thumb']);
        $category = isset($instance['category']) ? absint($instance['category']) : 0;
        ?>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>">
                <?php esc_html_e('Title:', 'iceberg'); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
                name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text"
                value="<?php echo esc_attr($title); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('count')); ?>">
                <?php esc_html_e('Number of posts (1-12):', 'iceberg'); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('count')); ?>"
                name="<?php echo esc_attr($this->get_field_name('count')); ?>" type="number" min="1" max="12"
                value="<?php echo esc_attr($count); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('category')); ?>">
                <?php esc_html_e('Category:', 'iceberg'); ?>
            </label>
            <?php
            wp_dropdown_categories(array(
                'show_option_all' => esc_html__('All Categories', 'iceberg'),
                'name' => $this->get_field_name('category'),
                'id' => $this->get_field_id('category'),
                'selected' => $category,
                'class' => 'widefat',
                'hide_empty' => 0,
            ));
            ?>
        </p>

        <p>
            <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id('show_thumb')); ?>"
                name="<?php echo esc_attr($this->get_field_name('show_thumb')); ?>" <?php checked($show_thumb); ?>>
            <label for="<?php echo esc_attr($this->get_field_id('show_thumb')); ?>">
                <?php esc_html_e('Show thumbnails', 'iceberg'); ?>
            </label>
        </p>

        <p>
            <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id('show_date')); ?>"
                name="<?php echo esc_attr($this->get_field_name('show_date')); ?>" <?php checked($show_date); ?>>
            <label for="<?php echo esc_attr($this->get_field_id('show_date')); ?>">
                <?php esc_html_e('Show date', 'iceberg'); ?>
            </label>
        </p>

        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     * @return array Updated safe values.
     */
    public function update($new_instance, $old_instance)
    {
        $instance = array();

        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['count'] = max(1, min(12, absint($new_instance['count'])));
        $instance['show_date'] = !empty($new_instance['show_date']) ? 1 : 0;
        $instance['show_thumb'] = !empty($new_instance['show_thumb']) ? 1 : 0;
        $instance['category'] = isset($new_instance['category']) ? absint($new_instance['category']) : 0;

        return $instance;
    }
}
