<?php
/**
 * Custom Ads Image Widget
 *
 * Allows uploading an ad image, specifying a link URL, and alt text
 * using the WordPress media uploader.
 *
 * @since Iceberg 2.5
 */

class Iceberg_Ad_Image_Widget extends WP_Widget
{

    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct(
            'iceberg_ad_image',
            esc_html__('Ad Image', 'iceberg'),
            array(
                'description' => esc_html__('Display an advertisement image with a link.', 'iceberg'),
                'classname' => 'widget-ad-image',
            )
        );

        // Enqueue media uploader scripts on admin widget pages
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }

    /**
     * Enqueue the WordPress media uploader scripts on widget admin screens.
     *
     * @param string $hook_suffix The current admin page hook.
     */
    public function enqueue_admin_scripts($hook_suffix)
    {
        if ($hook_suffix === 'widgets.php' || $hook_suffix === 'customize.php') {
            wp_enqueue_media();
            wp_enqueue_script(
                'iceberg-ad-widget-admin',
                get_template_directory_uri() . '/assets/js/ad-widget-admin.js',
                array('jquery'),
                wp_get_theme()->get('Version'),
                true
            );
        }
    }

    /**
     * Front-end display of the widget.
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget($args, $instance)
    {
        $image_url = !empty($instance['image_url']) ? $instance['image_url'] : '';
        $link_url = !empty($instance['link_url']) ? $instance['link_url'] : '';
        $alt_text = !empty($instance['alt_text']) ? $instance['alt_text'] : '';
        $title = !empty($instance['title']) ? apply_filters('widget_title', $instance['title']) : '';
        $open_new_tab = !empty($instance['open_new_tab']) ? true : false;

        if (empty($image_url)) {
            return;
        }

        echo $args['before_widget'];

        if ($title) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }
        ?>

        <div class="ad-image-wrapper">
            <?php if ($link_url): ?>
                <a href="<?php echo esc_url($link_url); ?>" <?php echo $open_new_tab ? 'target="_blank"' : ''; ?>
                    rel="nofollow noopener"
                    title="
        <?php echo esc_attr($alt_text); ?>">
                <?php endif; ?>

                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($alt_text); ?>" class="ad-image"
                    loading="lazy">

                <?php if ($link_url): ?>
                </a>
            <?php endif; ?>
        </div>

        <?php
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form.
     *
     * @param array $instance Previously saved values from database.
     * @return void
     */
    public function form($instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $image_url = !empty($instance['image_url']) ? $instance['image_url'] : '';
        $image_id = !empty($instance['image_id']) ? $instance['image_id'] : '';
        $link_url = !empty($instance['link_url']) ? $instance['link_url'] : '';
        $alt_text = !empty($instance['alt_text']) ? $instance['alt_text'] : '';
        $open_new_tab = !empty($instance['open_new_tab']) ? true : false;
        ?>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>">
                <?php esc_html_e('Title (optional):', 'iceberg'); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
                name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text"
                value="<?php echo esc_attr($title); ?>">
        </p>

        <p>
            <label>
                <?php esc_html_e('Ad Image:', 'iceberg'); ?>
            </label>
        </p>
        <div class="iceberg-ad-image-preview" id="<?php echo esc_attr($this->get_field_id('preview')); ?>">
            <?php if ($image_url): ?>
                <img src="<?php echo esc_url($image_url); ?>" alt=""
                    style="max-width:100%; height:auto; display:block; margin-bottom:10px; border-radius:4px;">
            <?php endif; ?>
        </div>
        <p>
            <input type="hidden" class="iceberg-ad-image-url" id="<?php echo esc_attr($this->get_field_id('image_url')); ?>"
                name="<?php echo esc_attr($this->get_field_name('image_url')); ?>" value="<?php echo esc_url($image_url); ?>">
            <input type="hidden" class="iceberg-ad-image-id" id="<?php echo esc_attr($this->get_field_id('image_id')); ?>"
                name="<?php echo esc_attr($this->get_field_name('image_id')); ?>" value="<?php echo esc_attr($image_id); ?>">
            <button type="button" class="button iceberg-ad-upload-btn"
                data-preview="#<?php echo esc_attr($this->get_field_id('preview')); ?>"
                data-url-field="#<?php echo esc_attr($this->get_field_id('image_url')); ?>"
                data-id-field="#<?php echo esc_attr($this->get_field_id('image_id')); ?>">
                <?php echo $image_url ? esc_html__('Change Image', 'iceberg') : esc_html__('Upload Image', 'iceberg'); ?>
            </button>

            <?php if ($image_url): ?>
                <button type="button" class="button iceberg-ad-remove-btn"
                    data-preview="#<?php echo esc_attr($this->get_field_id('preview')); ?>"
                    data-url-field="#<?php echo esc_attr($this->get_field_id('image_url')); ?>"
                    data-id-field="#<?php echo esc_attr($this->get_field_id('image_id')); ?>" style="color:#a00;">
                    <?php esc_html_e('Remove', 'iceberg'); ?>
                </button>
            <?php endif; ?>
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('link_url')); ?>">
                <?php esc_html_e('Ad Link URL:', 'iceberg'); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('link_url')); ?>"
                name="<?php echo esc_attr($this->get_field_name('link_url')); ?>" type="url"
                value="<?php echo esc_url($link_url); ?>" placeholder="https://">
        </p>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('alt_text')); ?>">
                <?php esc_html_e('Alt Text:', 'iceberg'); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('alt_text')); ?>"
                name="<?php echo esc_attr($this->get_field_name('alt_text')); ?>" type="text"
                value="<?php echo esc_attr($alt_text); ?>"
                placeholder="<?php esc_attr_e('Describe the ad image', 'iceberg'); ?>">
        </p>

        <p>
            <input type="checkbox" class="checkbox" id="<?php echo esc_attr($this->get_field_id('open_new_tab')); ?>"
                name="<?php echo esc_attr($this->get_field_name('open_new_tab')); ?>" <?php checked($open_new_tab); ?>>
            <label for="<?php echo esc_attr($this->get_field_id('open_new_tab')); ?>">
                <?php esc_html_e('Open link in a new tab', 'iceberg'); ?>
            </label>
        </p>

        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     * @return array Updated safe values.
     */
    public function update($new_instance, $old_instance)
    {
        $instance = array();

        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['image_url'] = esc_url_raw($new_instance['image_url']);
        $instance['image_id'] = absint($new_instance['image_id']);
        $instance['link_url'] = esc_url_raw($new_instance['link_url']);
        $instance['alt_text'] = sanitize_text_field($new_instance['alt_text']);
        $instance['open_new_tab'] = !empty($new_instance['open_new_tab']) ? 1 : 0;

        return $instance;
    }
}
