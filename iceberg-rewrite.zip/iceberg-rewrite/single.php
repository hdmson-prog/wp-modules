<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @since Iceberg 1.0
 */

get_header();

?>

<div id="primary" class="content-area">

    <main id="main" class="site-main">

        <?php
        // Start the loop.
        while (have_posts()):
            the_post();

            /*
             * Include the post format-specific template for the content. If you want to
             * use this in a child theme, then include a file called called content-___.php
             * (where ___ is the post format) and that will be used instead.
             */

            iceberg_render_ad('above_single_content');

            // Get the post format (returns false if none is set)
            $post_format = get_post_format();

            // Load the template part based on the post format
            if ($post_format) {
                get_template_part('template-parts/content', $post_format);
            } else {
                get_template_part('template-parts/content', 'single'); // fallback for standard format
            }

            iceberg_render_ad('below_single_content');

            if (get_theme_mod('display_related_posts', 1)) {
                iceberg_related_posts(sprintf('<div class="related-posts-wrapper inner-box"><div class="content-container"><h3 class="section-title">%s</h3>', esc_html__('You might also like', 'iceberg')), '</div></div>');
            }

            // Author bio.
            if (get_the_author_meta('description') && get_theme_mod('display_published_by', 1)):
                get_template_part('template-parts/author-bio');
            endif;

            // If comments are open or we have at least one comment, load up the comment template.
            if (comments_open() || get_comments_number()):
                comments_template();
            endif;

            // Previous/next post navigation.
            get_template_part('template-parts/navigation');

            // End the loop.
        endwhile;
        ?>

    </main><!-- .site-main -->

</div><!-- .content-area -->

<?php get_footer(); ?>