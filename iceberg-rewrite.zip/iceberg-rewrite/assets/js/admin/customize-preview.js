/**
 * Live-update changed settings in real time in the Customizer preview.
 */

( function( $ ) {
	"use strict";
	
	var api = wp.customize,
		$head = $('head');

	let root = document.documentElement;

	function hexToRgba( hex, opacity ) {
		var red = parseInt( hex.substring(1, 3), 16 ),
			green = parseInt( hex.substring(3, 5), 16 ),
			blue = parseInt( hex.substring(5, 7), 16 );

		return 'rgba( ' + red + ', ' + green + ', ' + blue + ', ' + opacity + ' )';
	}

	// Site title
	api( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );

	// Logo size
	api( 'logo_width', function( value ) {
		value.bind( function( to ) {
      		root.style.setProperty( '--logo--max-width', parseFloat( to ) + 'rem' );
		} );
	} );

	// Logo margin bottom
	api( 'logo_margin_bottom', function( value ) {
		value.bind( function( to ) {
      		root.style.setProperty( '--logo--margin-bottom', parseFloat( to ) + 'rem' );
		} );
	} );

	// Sidebar Background Color
	api( 'sidebar_background_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--sidebar--background-color', to );
		} );
	} );

	// Sidebar Text Color
	api( 'sidebar_text_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--sidebar--text-color', to );
			root.style.setProperty( '--sidebar--table-border-color', hexToRgba( to, 0.15 ) );
		} );
	} );

	api( 'sidebar_divider_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--sidebar--styled-divider-box-shadow-color', 'transparent' );
			root.style.setProperty( '--sidebar--styled-divider-border-color', to );
		} );
	} );

	api( 'sidebar_links_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--sidebar--link-color', to );
			root.style.setProperty( '--widget--tag-border-color', hexToRgba( to, 0.2 ) );
			root.style.setProperty( '--widget--tag-text-color', hexToRgba( to, 0.7 ) );
			root.style.setProperty( '--widget--tag-border-color-hover', hexToRgba( to, 0.7 ) );
			root.style.setProperty( '--widget--tag-text-color-hover', to );
		} );
	} );

	api( 'sidebar_links_hover_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--sidebar--link-color-hover', to );
		} );
	} );

	api( 'sidebar_inputs_background_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--sidebar--input-background-color', to );
		} );
	} );

	api( 'sidebar_inputs_text_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--sidebar--input-text-color', to );
			root.style.setProperty( '--sidebar--input-placeholder-color', hexToRgba( to, 0.7 ) );
		} );
	} );

	api( 'sidebar_mobile_button_background_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--mobile-button--background-color', to );
		} );
	} );

	// Site Title Color
	api( 'site_title_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--site-title--color', to );
		} );
	} );

	api( 'social_icons_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--social-menu--icon-color', to );
		} );
	} );

	api( 'link_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--global--accent-color-link', to );
		} );
	} );

	api( 'link_color_hover', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--global--accent-color-link-hover', to );
		} );
	} );

	api( 'button_background_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--button--background-color', to );
		} );
	} );

	api( 'button_background_color_hover', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--button--background-color-hover', to );
		} );
	} );

	api( 'button_text_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--button--text-color', to );
		} );
	} );

	api( 'category_label_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--category-link--background-color', to );
		} );
	} );

	api( 'selection_color', function( value ) {
		value.bind( function( to ) {
			root.style.setProperty( '--global--selection-background-color', to );
		} );
	} );

	// Tagline
	api( 'tagline', function( value ) {
		value.bind( function( to ) {
			$( '.tagline' ).html( to );
		} );
	} );

} )( jQuery );
