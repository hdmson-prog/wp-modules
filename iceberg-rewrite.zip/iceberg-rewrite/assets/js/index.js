/**
 * Is the DOM ready?
 *
 * This implementation is coming from https://gomakethings.com/a-native-javascript-equivalent-of-jquerys-ready-method/
 *
 * @since Iceberg 2.1
 *
 * @param {Function} fn Callback function to run.
 */
function icebergDomReady(fn) {
	if (typeof fn !== 'function') {
		return;
	}

	if (document.readyState === 'interactive' || document.readyState === 'complete') {
		return fn();
	}

	document.addEventListener('DOMContentLoaded', fn, false);
}

icebergDomReady(function () {
	var body = document.body;

	/* Preloader */
	if (icebergVars.preloaderEnabled && typeof imagesLoaded === "function") {
		imagesLoaded(body, function (instance) {
			body.classList.add('site-loaded');
		});
	}

	/* Init Swiper */
	if (typeof Swiper === 'function') {
		const swiper = new Swiper('.iceberg-swiper', {
			loop: true,
			autoHeight: true,
			speed: parseInt(icebergSwiperVars.speed),
			autoplay: {
				delay: parseInt(icebergSwiperVars.autoplayDelay)
			},
			pagination: { ...(!!icebergSwiperVars.pagination) && { el: '.swiper-pagination', type: 'bullets', clickable: true } },
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			},
			a11y: {
				firstSlideMessage: icebergSwiperVars.firstSlideMessage,
				lastSlideMessage: icebergSwiperVars.lastSlideMessage,
				paginationBulletMessage: icebergSwiperVars.paginationBulletMessage,
				prevSlideMessage: icebergSwiperVars.prevSlideMessage,
				nextSlideMessage: icebergSwiperVars.nextSlideMessage,
				containerMessage: icebergSwiperVars.containerMessage,
				containerRoleDescriptionMessage: icebergSwiperVars.containerRoleDescriptionMessage,
				itemRoleDescriptionMessage: icebergSwiperVars.itemRoleDescriptionMessage
			}
		});
	}

	/* Language Switcher Dropdown */
	const langToggle = document.getElementById('lang-switcher-toggle');
	if (langToggle) {
		const langDropdown = langToggle.closest('.lang-dropdown');
		const langList = langDropdown.querySelector('.lang-list');

		langToggle.addEventListener('click', function (e) {
			e.stopPropagation();
			const isActive = langDropdown.classList.contains('is-active');
			langDropdown.classList.toggle('is-active');
			langToggle.setAttribute('aria-expanded', !isActive);
			langList.setAttribute('aria-hidden', isActive);
		});

		document.addEventListener('click', function (e) {
			if (!langDropdown.contains(e.target)) {
				langDropdown.classList.remove('is-active');
				langToggle.setAttribute('aria-expanded', 'false');
				langList.setAttribute('aria-hidden', 'true');
			}
		});

		// Close on Escape key
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && langDropdown.classList.contains('is-active')) {
				langDropdown.classList.remove('is-active');
				langToggle.setAttribute('aria-expanded', 'false');
				langList.setAttribute('aria-hidden', 'true');
				langToggle.focus();
			}
		});
	}
	/* Init Highlight.js */
	if (typeof hljs === 'object') {
		hljs.highlightAll();

		/* Add Copy Button */
		document.querySelectorAll('pre').forEach((pre) => {
			// Only add if it contains a code block and doesn't already have a button
			const codeBlock = pre.querySelector('code');
			if (codeBlock && !pre.querySelector('.hljs-copy-button')) {
				const button = document.createElement('button');
				button.className = 'hljs-copy-button';
				button.type = 'button';
				button.innerText = 'Copy';

				button.addEventListener('click', (e) => {
					e.preventDefault();
					const code = codeBlock.innerText;

					// Fallback for non-HTTPS or unsupported browsers
					if (navigator.clipboard && navigator.clipboard.writeText) {
						navigator.clipboard.writeText(code).then(() => {
							updateButtonState(button);
						}).catch(err => {
							console.error('Failed to copy: ', err);
						});
					} else {
						// Old-fashioned way
						const textArea = document.createElement("textarea");
						textArea.value = code;
						document.body.appendChild(textArea);
						textArea.select();
						try {
							document.execCommand('copy');
							updateButtonState(button);
						} catch (err) {
							console.error('Fallback copy failed: ', err);
						}
						document.body.removeChild(textArea);
					}
				});

				function updateButtonState(btn) {
					btn.innerText = 'Copied!';
					btn.classList.add('is-copied');
					setTimeout(() => {
						btn.innerText = 'Copy';
						btn.classList.remove('is-copied');
					}, 2000);
				}

				pre.appendChild(button);
			}
		});
	}
});
