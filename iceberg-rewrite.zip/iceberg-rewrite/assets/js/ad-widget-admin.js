/**
 * Ad Image Widget - Admin JavaScript
 *
 * Handles the WordPress media uploader integration
 * for the Ad Image widget.
 *
 * @since Iceberg 2.5
 */
(function ($) {
    'use strict';

    /**
     * Handle the Upload Image button click.
     * Opens the WP media uploader and fills in the hidden fields + preview.
     */
    $(document).on('click', '.iceberg-ad-upload-btn', function (e) {
        e.preventDefault();

        var $button = $(this);
        var $preview = $($button.data('preview'));
        var $urlField = $($button.data('url-field'));
        var $idField = $($button.data('id-field'));

        var frame = wp.media({
            title: 'Select Ad Image',
            button: { text: 'Use this image' },
            multiple: false,
            library: { type: 'image' }
        });

        frame.on('select', function () {
            var attachment = frame.state().get('selection').first().toJSON();

            // Use a medium or full-size URL
            var url = attachment.sizes && attachment.sizes.large
                ? attachment.sizes.large.url
                : attachment.url;

            $urlField.val(url).trigger('change');
            $idField.val(attachment.id).trigger('change');

            // Update preview
            $preview.html(
                '<img src="' + url + '" alt="" style="max-width:100%; height:auto; display:block; margin-bottom:10px; border-radius:4px;">'
            );

            // Change button text
            $button.text('Change Image');

            // Show remove button (if not already visible)
            if (!$button.next('.iceberg-ad-remove-btn').length) {
                $button.after(
                    ' <button type="button" class="button iceberg-ad-remove-btn" ' +
                    'data-preview="' + $button.data('preview') + '" ' +
                    'data-url-field="' + $button.data('url-field') + '" ' +
                    'data-id-field="' + $button.data('id-field') + '" ' +
                    'style="color:#a00;">Remove</button>'
                );
            }
        });

        frame.open();
    });

    /**
     * Handle the Remove Image button click.
     * Clears the hidden fields and preview.
     */
    $(document).on('click', '.iceberg-ad-remove-btn', function (e) {
        e.preventDefault();

        var $button = $(this);
        var $preview = $($button.data('preview'));
        var $urlField = $($button.data('url-field'));
        var $idField = $($button.data('id-field'));

        $urlField.val('').trigger('change');
        $idField.val('').trigger('change');
        $preview.html('');

        // Change upload button text back
        $button.prev('.iceberg-ad-upload-btn').text('Upload Image');

        // Remove the remove button
        $button.remove();
    });

})(jQuery);
