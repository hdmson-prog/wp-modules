<?php
/**
 * Custom template tags for Iceberg
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @since Iceberg 1.0
 */

if (!function_exists('iceberg_site_identity')):
    /**
     * Prints HTML with blog title and description.
     *
     * @since Iceberg 1.0
     */
    function iceberg_site_identity()
    {
        if (has_custom_logo()) {
            the_custom_logo();
        }

        if (get_theme_mod('display_site_title', 1)) {
            printf(
                '<%1$s class="site-title"><a href="%2$s">%3$s</a></%1$s>',
                (is_front_page() || is_home()) && !is_page() ? 'h1' : 'div',
                esc_url(home_url('/')),
                esc_html(get_bloginfo('name'))
            );
        }
    }
endif;

if (!function_exists('iceberg_custom_text')):
    /**
     * Prints HTML with custom customizer text.
     *
     * @since Iceberg 2.0
     */
    function iceberg_custom_text($name = '', $before = '', $after = '', $default_text = '')
    {
        if (!$name)
            return;

        $custom_text = get_theme_mod($name);

        if (!$custom_text && !is_customize_preview() && !$default_text)
            return;

        $custom_text = wp_kses(
            wpautop($custom_text),
            array(
                'a' => array(
                    'href' => array(),
                    'title' => array(),
                    'target' => array()
                ),
                'p' => array(),
                'b' => array(),
                'strong' => array(),
                'em' => array(),
                'i' => array(),
                'br' => array(),
                'span' => array(),
                'img' => array(
                    'src' => array(),
                    'alt' => array(),
                    'title' => array()
                )
            )
        );

        $custom_text = $default_text && !$custom_text ? $default_text : $custom_text;

        if ($custom_text || is_customize_preview())
            printf('%s%s%s', $before, $custom_text, $after);
    }
endif;

if (!function_exists('iceberg_post_thumbnail')):
    /**
     * Display an optional post thumbnail.
     *
     * Wraps the post thumbnail in an anchor element on index views, or a div
     * element when on single views.
     *
     * @since Iceberg 1.0
     */
    function iceberg_post_thumbnail()
    {
        if (post_password_required() || is_attachment() || !has_post_thumbnail()) {
            return;
        }

        if (is_singular()):
            ?>

            <div class="post-thumbnail">
                <?php the_post_thumbnail('iceberg-post-thumbnail-crop'); ?>
            </div><!-- .post-thumbnail -->

        <?php else: ?>

            <a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true">
                <?php the_post_thumbnail('iceberg-post-thumbnail-crop', array('alt' => get_the_title())); ?>
            </a>

        <?php endif; // End is_singular()
    }
endif;

if (!function_exists('iceberg_the_post_meta')):
    /**
     * Prints HTML with meta information for the categories, post date.
     *
     * @since Iceberg 2.0
     */
    function iceberg_the_post_meta($before = '', $after = '', $display_date = true, $display_author = true)
    {

        $output = '';

        $post_type = get_post_type();

        if (in_array($post_type, array('post', 'attachment')) && $display_date) {
            $time_string = sprintf('<span class="entry-date published" datetime="%1$s">%2$s</span>', esc_attr(get_the_date('c')), get_the_date());
            $time_string = sprintf(esc_html_x('Posted on %s', 'Post date', 'iceberg'), $time_string);

            $output .= sprintf('<span class="posted-on">%s</span>', $time_string);
        }

        if ('post' == $post_type && $display_author) {
            $author_string = sprintf('<a class="url fn" href="%s">%s</a>', esc_url(get_author_posts_url(get_the_author_meta('ID'))), get_the_author());
            $author_string = sprintf(esc_html_x('by %s', 'Post author', 'iceberg'), $author_string);

            $output .= sprintf('<span class="byline author vcard">%s</span>', $author_string);
        }

        if ($output)
            printf('%s%s%s', $before, $output, $after);

        return false;
    }
endif;

if (!function_exists('iceberg_the_category')):
    /**
     * Prints HTML with post categories list.
     *
     * @since Iceberg 2.0
     */
    function iceberg_the_category($before = '', $after = '', $display = true)
    {
        $post_type = get_post_type();

        $output = '';

        if ('post' == $post_type && $display) {
            $categories = get_the_category();

            if ($categories) {
                foreach ($categories as $category) {
                    $output .= sprintf('<a href="%s" class="category-%d">%s</a>', esc_url(get_category_link($category->term_id)), $category->term_id, esc_attr($category->cat_name));
                }
            }
        }

        if ($output) {
            printf('%s%s%s', $before, $output, $after);
        }
    }
endif;

if (!function_exists('iceberg_the_post_footer')):
    /**
     * Prints HTML with post tags and share buttons in post footer
     *
     * @since Iceberg 2.0
     */
    function iceberg_the_post_footer($display_tags = true, $display_share_buttons = true, $before = '', $after = '')
    {
        $output = '';

        $post = get_post();

        if (is_single() && $display_tags) {
            $output .= get_the_tag_list(sprintf('<span class="screen-reader-text">%s</span><div class="tags-list">', esc_html__('Tags', 'iceberg')), '', '</div>');
        }

        if (is_singular() && $display_share_buttons && function_exists('nsafb_get_share_buttons')) {
            $output .= sprintf('<div class="entry-share">%s</div>', nsafb_get_share_buttons());
        }

        if ($output)
            printf('%s%s%s', $before, $output, $after);
    }
endif;

if (!function_exists('iceberg_related_posts')):
    /**
     * Related posts for current post.
     *
     * @since Iceberg 1.0
     */
    function iceberg_related_posts($before = '', $after = '')
    {
        global $post;

        if (!$post)
            return;

        if ($post->post_type !== 'post')
            return;

        $query_args = array(
            'post__not_in' => array($post->ID),
            'posts_per_page' => 3,
            'orderby' => 'rand',
            'ignore_sticky_posts' => true
        );

        $related_by = get_theme_mod('related_by', 'none');

        switch ($related_by) {

            case 'category':
                $categories = get_the_category($post->ID);

                if ($categories) {
                    $category_ids = array();

                    foreach ($categories as $category)
                        $category_ids[] = $category->term_id;

                    $query_args['category__in'] = $category_ids;
                }
                break;

            case 'tags':
                $tags = wp_get_post_tags($post->ID);

                if ($tags) {
                    $tag_ids = array();

                    foreach ($tags as $tag)
                        $tag_ids[] = $tag->term_id;

                    $query_args['tag__in'] = $tag_ids;
                }
                break;

            case 'none':
                $query_args['orderby'] = 'rand';
                break;

        }

        $related_posts = new WP_Query($query_args);

        $output = '';

        if ($related_posts->have_posts()) {
            printf('%s<div class="related-posts">', $before);

            while ($related_posts->have_posts()):
                $related_posts->the_post(); ?>

                <div class="related-post">

                    <?php if (has_post_thumbnail()): ?>
                        <a href="<?php the_permalink() ?>" class="related-post-thumbnail" rel="bookmark" title="<?php the_title(); ?>">
                            <?php the_post_thumbnail('iceberg-medium-square-thumbnail'); ?>
                        </a>
                    <?php endif; ?>

                    <div class="related-post-content">

                        <a href="<?php the_permalink(); ?>" class="related-post-title" rel="bookmark"
                            title="<?php the_title(); ?>"><?php the_title(); ?></a>

                        <div class="related-post-date">
                            <?php echo get_the_date(); ?>
                        </div>

                    </div>

                </div>

            <?php
            endwhile;

            printf('</div>%s', $after);
        }

        wp_reset_postdata();
    }
endif;

/**
 * Displays SVG icons in social links menu.
 *
 * @param string   $item_output The menu item's starting HTML output.
 * @param WP_Post  $item        Menu item data object.
 * @param int      $depth       Depth of the menu. Used for padding.
 * @param stdClass $args        An object of wp_nav_menu() arguments.
 * @return string The menu item output with social icon.
 */
function iceberg_nav_menu_social_icons($item_output, $item, $depth, $args)
{
    // Change SVG icon inside social links menu if there is supported URL.
    if ($args->theme_location === 'social') {
        $svg = Iceberg_SVG_Icons::get_social_link_svg($item->url);
        if (empty($svg)) {
            $svg = iceberg_get_theme_svg('link');
        }
        $item_output = str_replace($args->link_after, '</span>' . $svg, $item_output);
    }

    return $item_output;
}

add_filter('walker_nav_menu_start_el', 'iceberg_nav_menu_social_icons', 10, 4);

/**
 * Filters classes of wp_list_pages items to match menu items.
 *
 * Filter the class applied to wp_list_pages() items with children to match the menu class, to simplify.
 * styling of sub levels in the fallback. Only applied if the match_menu_classes argument is set.
 *
 * @since Iceberg 2.1
 *
 * @param string[] $css_class    An array of CSS classes to be applied to each list item.
 * @param WP_Post  $page         Page data object.
 * @param int      $depth        Depth of page, used for padding.
 * @param array    $args         An array of arguments.
 * @param int      $current_page ID of the current page.
 * @return array CSS class names.
 */
function iceberg_filter_wp_list_pages_item_classes($css_class, $page, $depth, $args, $current_page)
{

    // Only apply to wp_list_pages() calls with match_menu_classes set to true.
    $match_menu_classes = isset($args['match_menu_classes']);

    if (!$match_menu_classes) {
        return $css_class;
    }

    // Add current menu item class.
    if (in_array('current_page_item', $css_class, true)) {
        $css_class[] = 'current-menu-item';
    }

    // Add menu item has children class.
    if (in_array('page_item_has_children', $css_class, true)) {
        $css_class[] = 'menu-item-has-children';
    }

    return $css_class;

}

add_filter('page_css_class', 'iceberg_filter_wp_list_pages_item_classes', 10, 5);

/**
 * Adds a Sub Nav Toggle to the Expanded Menu and Mobile Menu.
 *
 * @since Iceberg 2.1
 *
 * @param stdClass $args  An object of wp_nav_menu() arguments.
 * @param WP_Post  $item  Menu item data object.
 * @param int      $depth Depth of menu item. Used for padding.
 * @return stdClass An object of wp_nav_menu() arguments.
 */
function iceberg_add_sub_toggles_to_main_menu($args, $item, $depth)
{

    // Add sub menu toggles to the Expanded Menu with toggles.
    if (isset($args->show_toggles) && $args->show_toggles) {

        // Wrap the menu item link contents in a div, used for positioning.
        $args->before = '<div class="ancestor-wrapper">';
        $args->after = '';

        // Add a toggle to items with children.
        if (in_array('menu-item-has-children', $item->classes, true)) {
            $parent_selector = isset($args->parent_selector) ? esc_attr($args->parent_selector) : '';
            $toggle_target_string = $parent_selector . ' .menu-item-' . $item->ID . ' > .sub-menu';

            // Add the sub menu toggle.
            $args->after .= '<button class="toggle sub-menu-toggle" data-bs-toggle="collapse" data-bs-target="' . $toggle_target_string . '" aria-expanded="false"><span class="screen-reader-text">' . esc_html__('Show sub menu', 'iceberg') . '</span>' . iceberg_get_theme_svg('chevron-down') . '</button>';

        }

        // Close the wrapper.
        $args->after .= '</div><!-- .ancestor-wrapper -->';

    }

    return $args;

}

add_filter('nav_menu_item_args', 'iceberg_add_sub_toggles_to_main_menu', 10, 3);

/**
 * Filters classes of sub-menu for primary navigation.
 *
 * @since Iceberg 2.1
 *
 * @param string[] $classes    An array of CSS classes to be applied to each submenu.
 * @param int      $depth        Depth of page, used for padding.
 * @param array    $args         An array of arguments.
 * @return array CSS class names.
 */
function iceberg_add_class_to_submenu($classes, $args, $depth)
{
    if (isset($args->collapse) && $args->collapse) {
        $classes[] = 'collapse';
    }

    return $classes;
}

add_filter('nav_menu_submenu_css_class', 'iceberg_add_class_to_submenu', 10, 3);

/**
 * Filters the HTML attributes applied to a menu item's anchor element.
 *
 * @since Iceberg 2.1
 *
 * @param array $atts {
 *     The HTML attributes applied to the menu item's `<a>` element, empty strings are ignored.
 *
 *     @type string $title        Title attribute.
 *     @type string $target       Target attribute.
 *     @type string $rel          The rel attribute.
 *     @type string $href         The href attribute.
 *     @type string $aria-current The aria-current attribute.
 * }
 * @param WP_Post  $item  The current menu item.
 * @param stdClass $args  An object of wp_nav_menu() arguments.
 * @param int      $depth Depth of menu item. Used for padding.
 */
function iceberg_filter_nav_menu_link_attributes($atts, $item, $args, $depth)
{
    if (isset($args->collapse) && $args->collapse && in_array('menu-item-has-children', $item->classes)) {
        if (isset($atts['href']) && substr($atts['href'], 0, 1) === '#') {
            $parent_selector = isset($args->parent_selector) ? esc_attr($args->parent_selector) : '';

            $atts['data-bs-toggle'] = 'collapse';
            $atts['data-bs-target'] = $parent_selector . ' .menu-item-' . $item->ID . ' > .sub-menu';
            $atts['aria-expanded'] = 'false';
        }
    }

    return $atts;
}

add_filter('nav_menu_link_attributes', 'iceberg_filter_nav_menu_link_attributes', 10, 4);

/**
 * Filters the arguments for the Navigation Menu widget.
 *
 * @since Iceberg 2.1
 *
 * @param array   $nav_menu_args {
 *     An array of arguments passed to wp_nav_menu() to retrieve a navigation menu.
 *
 *     @type callable|bool $fallback_cb Callback to fire if the menu doesn't exist. Default empty.
 *     @type mixed         $menu        Menu ID, slug, or name.
 * }
 * @param WP_Term $nav_menu      Nav menu object for the current menu.
 * @param array   $args          Display arguments for the current widget.
 * @param array   $instance      Array of settings for the current widget.
 */
function iceberg_filter_widget_nav_menu_args($nav_menu_args, $nav_menu, $args, $instance)
{
    $nav_menu_args['show_toggles'] = true;
    $nav_menu_args['collapse'] = true;
    $nav_menu_args['parent_selector'] = '#' . $args['widget_id'];

    return $nav_menu_args;
}

add_filter('widget_nav_menu_args', 'iceberg_filter_widget_nav_menu_args', 10, 4);

/**
 * Checks if the specified comment is written by the author of the post commented on.
 *
 * @since Iceberg 2.1
 *
 * @param object $comment Comment data.
 * @return bool
 */
function iceberg_is_comment_by_post_author($comment = null)
{

    if (is_object($comment) && $comment->user_id > 0) {

        $user = get_userdata($comment->user_id);
        $post = get_post($comment->comment_post_ID);

        if (!empty($user) && !empty($post)) {

            return $comment->user_id === $post->post_author;

        }
    }
    return false;

}

/**
 * Include a skip to content link at the top of the page so that users can bypass the menu.
 *
 * @since Twenty Twenty 2.1
 */
function iceberg_skip_link()
{
    echo '<a class="skip-link screen-reader-text" href="#main">' . esc_html__('Skip to the content', 'iceberg') . '</a>';
}

add_action('wp_body_open', 'iceberg_skip_link', 5);

/**
 * Gets unique ID.
 *
 * This is a PHP implementation of Underscore's uniqueId method. A static variable
 * contains an integer that is incremented with each call. This number is returned
 * with the optional prefix. As such the returned value is not universally unique,
 * but it is unique across the life of the PHP process.
 *
 * @since Iceberg 2.1
 *
 * @see wp_unique_id() Themes requiring WordPress 5.0.3 and greater should use this instead.
 *
 * @param string $prefix Prefix for the returned ID.
 * @return string Unique ID.
 */
function iceberg_unique_id($prefix = '')
{
    static $id_counter = 0;
    if (function_exists('wp_unique_id')) {
        return wp_unique_id($prefix);
    }
    return $prefix . (string) ++$id_counter;
}

if (!function_exists('iceberg_render_ad')):
    /**
     * Renders an advertisement slot based on customizer settings.
     *
     * @since Iceberg 1.0
     * @param string $slot_id The ID of the ad slot.
     */
    function iceberg_render_ad($slot_id)
    {
        $ad_img = get_theme_mod('ad_' . $slot_id . '_img');
        $ad_link = get_theme_mod('ad_' . $slot_id . '_link');
        $ad_alt = get_theme_mod('ad_' . $slot_id . '_alt', 'Advertisement');

        if ($ad_img): ?>
            <div class="iceberg-ad-slot ad-<?php echo esc_attr(str_replace('_', '-', $slot_id)); ?>"
                style="text-align: center; margin-bottom: 30px;">
                <?php if ($ad_link): ?>
                    <a href="<?php echo esc_url($ad_link); ?>" target="_blank" rel="nofollow"
                        title="<?php echo esc_attr($ad_alt); ?>">
                    <?php endif; ?>

                    <img src="<?php echo esc_url($ad_img); ?>" alt="<?php echo esc_attr($ad_alt); ?>"
                        style="display: block; margin: 0 auto; max-width: 100%; height: auto;">

                    <?php if ($ad_link): ?>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif;
    }
endif;
?>