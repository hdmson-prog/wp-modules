=== Nord Share and Follow Buttons ===
Tags: share, buttons, social, follow
Requires at least: 5.0
Tested up to: 5.3
Stable tag: 1.2.1
License: GPLv2 or later
Author URI: https://themeforest.net/user/nordstudio

== Description ==

A simple plugin that enables you to add Share and Follow buttons.

== Installation ==

Just install and activate.

== Changelog ==

= 0.1 =

* Initial release
