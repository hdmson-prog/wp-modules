<?php
/**
 * Dynamic Social Icons Implementation for WordPress
 * Add this code to your theme's functions.php file
 * Version: 2.0 - Clean, No Duplicates
 */

// Define all social networks in one place for easy management
function get_social_networks_config() {
    $networks = array(
        'facebook_url' => array(
            'label' => 'Facebook',
            'icon' => 'fab fa-facebook-f',
            'placeholder' => 'https://facebook.com/username',
            'color' => '#1877f2'
        ),
        'linkedin_url' => array(
            'label' => 'LinkedIn Profile',
            'icon' => 'fab fa-linkedin-in',
            'placeholder' => 'https://linkedin.com/in/username',
            'color' => '#0077b5'
        ),
        'linkedin_company_url' => array(
            'label' => 'LinkedIn Company',
            'icon' => 'fab fa-linkedin',
            'placeholder' => 'https://linkedin.com/company/company-name',
            'color' => '#0077b5'
        ),
        'twitter_url' => array(
            'label' => 'Twitter (X)',
            'icon' => 'fab fa-twitter',
            'placeholder' => 'https://twitter.com/username',
            'color' => '#1da1f2'
        ),
        'instagram_url' => array(
            'label' => 'Instagram',
            'icon' => 'fab fa-instagram',
            'placeholder' => 'https://instagram.com/username',
            'color' => '#e4405f'
        ),
        'tiktok_url' => array(
            'label' => 'TikTok',
            'icon' => 'fab fa-tiktok',
            'placeholder' => 'https://tiktok.com/@username',
            'color' => '#000000'
        ),
        'youtube_url' => array(
            'label' => 'YouTube',
            'icon' => 'fab fa-youtube',
            'placeholder' => 'https://youtube.com/channel/username',
            'color' => '#ff0000'
        ),
        'github_url' => array(
            'label' => 'GitHub',
            'icon' => 'fab fa-github',
            'placeholder' => 'https://github.com/username',
            'color' => '#333333'
        ),
        'dribbble_url' => array(
            'label' => 'Dribbble',
            'icon' => 'fab fa-dribbble',
            'placeholder' => 'https://dribbble.com/username',
            'color' => '#ea4c89'
        ),
        'behance_url' => array(
            'label' => 'Behance',
            'icon' => 'fab fa-behance',
            'placeholder' => 'https://behance.net/username',
            'color' => '#1769ff'
        ),
        'pinterest_url' => array(
            'label' => 'Pinterest',
            'icon' => 'fab fa-pinterest',
            'placeholder' => 'https://pinterest.com/username',
            'color' => '#bd081c'
        ),
        'snapchat_url' => array(
            'label' => 'Snapchat',
            'icon' => 'fab fa-snapchat-ghost',
            'placeholder' => 'https://snapchat.com/add/username',
            'color' => '#fffc00'
        ),
        'discord_url' => array(
            'label' => 'Discord',
            'icon' => 'fab fa-discord',
            'placeholder' => 'https://discord.gg/servername',
            'color' => '#5865f2'
        ),
        'telegram_url' => array(
            'label' => 'Telegram',
            'icon' => 'fab fa-telegram-plane',
            'placeholder' => 'https://t.me/username',
            'color' => '#0088cc'
        ),
        'whatsapp_url' => array(
            'label' => 'WhatsApp',
            'icon' => 'fab fa-whatsapp',
            'placeholder' => 'https://wa.me/1234567890',
            'color' => '#25d366'
        ),
        'website_url' => array(
            'label' => 'Website',
            'icon' => 'fas fa-globe',
            'placeholder' => 'https://yourwebsite.com',
            'color' => '#666666'
        ),
        'email_url' => array(
            'label' => 'Email',
            'icon' => 'fas fa-envelope',
            'placeholder' => 'mailto:your@email.com',
            'color' => '#ea4335'
        )
    );

    // Apply filter to allow customization
    return apply_filters('social_networks_config', $networks);
}

// 1. Add dynamic social media fields to user profile
add_action('show_user_profile', 'add_social_media_fields');
add_action('edit_user_profile', 'add_social_media_fields');

function add_social_media_fields($user) {
    $social_networks = get_social_networks_config();
    ?>
    <h3><?php _e('Social Media Links', 'textdomain'); ?></h3>
    
    <table class="form-table">
        <?php foreach ($social_networks as $field_key => $config): ?>
        <tr>
            <th>
                <label for="<?php echo esc_attr($field_key); ?>">
                    <i class="<?php echo esc_attr($config['icon']); ?>" style="margin-right: 5px; color: <?php echo esc_attr($config['color']); ?>;"></i>
                    <?php echo esc_html($config['label']); ?>
                </label>
            </th>
            <td>
                <input type="url" 
                       name="<?php echo esc_attr($field_key); ?>" 
                       id="<?php echo esc_attr($field_key); ?>" 
                       value="<?php echo esc_attr(get_the_author_meta($field_key, $user->ID)); ?>" 
                       class="regular-text" 
                       placeholder="<?php echo esc_attr($config['placeholder']); ?>" />
                <p class="description">
                    <?php printf(__('Enter your %s URL', 'textdomain'), $config['label']); ?>
                </p>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <style>
        .form-table th label i {
            width: 20px;
            text-align: center;
        }
        .form-table .description {
            margin-top: 5px;
            font-style: italic;
            color: #666;
        }
    </style>
    <?php
}

// 2. Save the dynamic social media fields
add_action('personal_options_update', 'save_social_media_fields');
add_action('edit_user_profile_update', 'save_social_media_fields');

function save_social_media_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }
    
    $social_networks = get_social_networks_config();
    
    foreach ($social_networks as $field_key => $config) {
        if (isset($_POST[$field_key])) {
            $url = sanitize_url($_POST[$field_key]);
            
            // Additional validation for email fields
            if ($field_key === 'email_url' && !empty($url) && !filter_var($url, FILTER_VALIDATE_EMAIL) && strpos($url, 'mailto:') !== 0) {
                // If it's an email field and doesn't start with mailto:, add it
                if (filter_var($url, FILTER_VALIDATE_EMAIL)) {
                    $url = 'mailto:' . $url;
                }
            }
            
            update_user_meta($user_id, $field_key, $url);
        }
    }
}

// 3. Function to display social icons dynamically
function display_social_icons($user_id = null, $show_empty = false) {
    // Get current user ID if not provided
    if (!$user_id) {
        $user_id = get_current_user_id();
        // If still no user ID, try to get post author
        if (!$user_id && is_singular()) {
            $user_id = get_the_author_meta('ID');
        }
    }
    
    if (!$user_id) {
        return '';
    }
    
    // Get dynamic social networks configuration
    $social_networks = get_social_networks_config();
    
    $output = '<div class="social-icons">';
    $has_links = false;
    
    foreach ($social_networks as $meta_key => $config) {
        $url = get_user_meta($user_id, $meta_key, true);
        
        if (!empty($url)) {
            $has_links = true;
            $output .= sprintf(
                '<a href="%s" target="_blank" rel="noopener noreferrer" aria-label="%s" data-social="%s">
                    <i class="%s"></i>
                </a>',
                esc_url($url),
                esc_attr($config['label']),
                esc_attr(str_replace('_url', '', $meta_key)),
                esc_attr($config['icon'])
            );
        } elseif ($show_empty) {
            // Show placeholder for empty links if requested
            $output .= sprintf(
                '<a href="#" class="social-icon-disabled" aria-label="%s (not set)" data-social="%s">
                    <i class="%s"></i>
                </a>',
                esc_attr($config['label']),
                esc_attr(str_replace('_url', '', $meta_key)),
                esc_attr($config['icon'])
            );
        }
    }
    
    $output .= '</div>';
    
    // Return output only if there are links or show_empty is true
    return ($has_links || $show_empty) ? $output : '';
}

// 4. Shortcode for easy use in posts/pages
add_shortcode('social_icons', 'social_icons_shortcode');

function social_icons_shortcode($atts) {
    $atts = shortcode_atts(array(
        'user_id' => null,
        'show_empty' => false
    ), $atts, 'social_icons');
    
    return display_social_icons($atts['user_id'], $atts['show_empty']);
}

// 5. Widget for displaying social icons
class Social_Icons_Widget extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'social_icons_widget',
            __('Social Icons', 'textdomain'),
            array('description' => __('Display user social media icons', 'textdomain'))
        );
    }
    
    public function widget($args, $instance) {
        $user_id = !empty($instance['user_id']) ? $instance['user_id'] : get_current_user_id();
        $title = !empty($instance['title']) ? $instance['title'] : '';
        
        echo $args['before_widget'];
        
        if (!empty($title)) {
            echo $args['before_title'] . apply_filters('widget_title', $title) . $args['after_title'];
        }
        
        echo display_social_icons($user_id, false);
        
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $user_id = !empty($instance['user_id']) ? $instance['user_id'] : '';
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" 
                   name="<?php echo $this->get_field_name('title'); ?>" type="text" 
                   value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('user_id'); ?>"><?php _e('User ID (leave empty for current user):'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('user_id'); ?>" 
                   name="<?php echo $this->get_field_name('user_id'); ?>" type="number" 
                   value="<?php echo esc_attr($user_id); ?>">
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['user_id'] = (!empty($new_instance['user_id'])) ? intval($new_instance['user_id']) : '';
        return $instance;
    }
}

// Register the widget
add_action('widgets_init', function() {
    register_widget('Social_Icons_Widget');
});

// 6. Template functions for theme integration

/**
 * Display social icons for current post author
 */
function the_author_social_icons() {
    if (is_singular()) {
        echo display_social_icons(get_the_author_meta('ID'));
    }
}

/**
 * Get social icons for current post author (returns HTML)
 */
function get_the_author_social_icons() {
    if (is_singular()) {
        return display_social_icons(get_the_author_meta('ID'));
    }
    return '';
}

/**
 * Display social icons for specific user
 */
function display_user_social_icons($user_id) {
    echo display_social_icons($user_id);
}

/**
 * Get social icons for specific user (returns HTML)
 */
function get_user_social_icons($user_id) {
    return display_social_icons($user_id);
}

// 7. Add dynamic CSS for better styling
add_action('wp_head', 'social_icons_custom_css');

function social_icons_custom_css() {
    $social_networks = get_social_networks_config();
    ?>
    <style>
    .social-icons {
        display: flex;
        gap: 10px;
        align-items: center;
        flex-wrap: wrap;
    }
    
    .social-icons a {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: #f0f0f0;
        color: #333;
        text-decoration: none;
        transition: all 0.3s ease;
        position: relative;
    }
    
    .social-icons a:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    <?php foreach ($social_networks as $key => $config): 
        $social_name = str_replace('_url', '', $key);
    ?>
    .social-icons a[data-social="<?php echo esc_attr($social_name); ?>"]:hover {
        background: <?php echo esc_attr($config['color']); ?>;
        color: white;
    }
    <?php endforeach; ?>
    
    .social-icon-disabled {
        opacity: 0.3;
        pointer-events: none;
    }

    /* Responsive design */
    @media (max-width: 480px) {
        .social-icons {
            gap: 8px;
        }
        .social-icons a {
            width: 35px;
            height: 35px;
        }
    }
    </style>
    <?php
}

// 8. Admin enhancements - Add FontAwesome if not already loaded
add_action('admin_enqueue_scripts', 'enqueue_admin_social_assets');

function enqueue_admin_social_assets($hook) {
    // Only load on user profile pages
    if ($hook !== 'profile.php' && $hook !== 'user-edit.php') {
        return;
    }
    
    // Check if FontAwesome is already loaded, if not, load it
    if (!wp_script_is('font-awesome', 'enqueued')) {
        wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/all.min.css');
    }
}

// 9. Filter to allow custom social networks (for developers)
add_filter('social_networks_config', 'add_custom_social_network');

function add_custom_social_network($networks) {
    // Example: Add a custom network
    // $networks['custom_url'] = array(
    //     'label' => 'Custom Platform',
    //     'icon' => 'fas fa-link',
    //     'placeholder' => 'https://custom-platform.com/username',
    //     'color' => '#ff6b6b'
    // );
    
    return $networks;
}

// 10. Utility functions for developers

/**
 * Get available social network keys
 */
function get_social_network_keys() {
    return array_keys(get_social_networks_config());
}

/**
 * Get a specific social URL for a user
 */
function get_user_social_url($user_id, $network) {
    $network_key = $network . '_url';
    return get_user_meta($user_id, $network_key, true);
}

/**
 * Check if user has any social links
 */
function user_has_social_links($user_id) {
    $networks = get_social_networks_config();
    
    foreach ($networks as $key => $config) {
        $url = get_user_meta($user_id, $key, true);
        if (!empty($url)) {
            return true;
        }
    }
    
    return false;
}

/**
 * Get social links count for a user
 */
function get_user_social_count($user_id) {
    $networks = get_social_networks_config();
    $count = 0;
    
    foreach ($networks as $key => $config) {
        $url = get_user_meta($user_id, $key, true);
        if (!empty($url)) {
            $count++;
        }
    }
    
    return $count;
}
?>