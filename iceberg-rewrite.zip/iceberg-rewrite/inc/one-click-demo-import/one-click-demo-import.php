<?php
if ( class_exists( 'OCDI_Plugin' ) ) {

    function iceberg_ocdi_import_files() {
        return array(
            array(
                'import_file_name'             => 'Iceberg Demo',
                'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/one-click-demo-import/demo-content.xml',
                'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/one-click-demo-import/widgets.wie',
                'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/one-click-demo-import/customizer.dat',
                'import_preview_image_url'     => 'http://nordthemes.com/wp-content/uploads/2021/07/demo-iceberg.png',
                'import_notice'                => esc_html__( 'Please click the "Import Demo Data" button and waiting for a few minutes, do not close the window or refresh the page until the data is imported.', 'iceberg' ),
                'preview_url'                  => 'http://nordthemes.com/iceberg/',
            )
        );
    }
    add_filter( 'ocdi/import_files', 'iceberg_ocdi_import_files' );

    function iceberg_after_import( $selected_import ) {

        if ( 'Iceberg Demo' === $selected_import['import_file_name'] ) {
            //Set Menu
            $primary_menu = get_term_by( 'name', 'Primary', 'nav_menu' );
            $social_menu = get_term_by( 'name', 'Social Menu', 'nav_menu' );

            set_theme_mod( 'nav_menu_locations' , array( 
                'primary' => $primary_menu->term_id, 
                'social' => $social_menu->term_id 
                ) 
            );
        }

    }
    add_action( 'pt-ocdi/after_import', 'iceberg_after_import' );
}
?>