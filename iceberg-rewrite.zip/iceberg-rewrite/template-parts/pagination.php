<?php
/**
 * A template partial to output pagination for the Iceberg default theme.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Iceberg
 * @since Iceberg 2.1
 */

$prev_text = sprintf(
	'%s <span class="nav-prev-text screen-reader-text">%s</span>',
	is_rtl() ? iceberg_get_theme_svg( 'chevron-right' ) : iceberg_get_theme_svg( 'chevron-left' ),
	esc_html__( 'Newer Posts', 'iceberg' )
);
$next_text = sprintf(
	'<span class="nav-next-text screen-reader-text">%s</span> %s',
	esc_html__( 'Older Posts', 'iceberg' ),
	is_rtl() ? iceberg_get_theme_svg( 'chevron-left' ) : iceberg_get_theme_svg( 'chevron-right' )
);

$posts_pagination = get_the_posts_pagination(
	array(
		'mid_size'  => 1,
		'prev_text' => $prev_text,
		'next_text' => $next_text,
	)
);

if ( $posts_pagination ) { 
	printf( '<div class="pagination-wrapper">%s</div>', $posts_pagination );
}
