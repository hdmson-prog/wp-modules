<?php
/**
 * The template used for displaying page content
 *
 * @since Iceberg 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <?php 
    $gallery_before = '
        <div class="swiper iceberg-swiper" ' . ( is_rtl() ? 'dir="rtl"' : '' ) . '>
            <div class="swiper-wrapper">';
    $gallery_after = '
            </div><!-- .swiper-wrapper -->
            <div class="swiper-button-prev">' . ( is_rtl() ? iceberg_get_theme_svg( 'chevron-right' ) : iceberg_get_theme_svg( 'chevron-left' ) ) . '</div>
            <div class="swiper-button-next">' . ( is_rtl() ? iceberg_get_theme_svg( 'chevron-left' ) : iceberg_get_theme_svg( 'chevron-right' ) ) . '</div>
            <div class="swiper-pagination"></div>
        </div><!-- .swiper -->';

    iceberg_format_content( 
        array( 
            'before'          => $gallery_before,
            'after'           => $gallery_after,
            'images_size'     => 'post-thumbnail',
            'fallback_cb'     => 'iceberg_post_thumbnail',
            'enqueue_scripts' => array( 'swiper-bundle' ),
            'enqueue_styles'  => array( 'swiper-bundle' )
        )
    );
    ?>
  
    <div class="inner-box">

        <div class="content-container">

            <header class="entry-header">
                <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
            </header><!-- .entry-header -->

            <div class="entry-content">

                <?php the_content( esc_html__( 'Continue reading', 'iceberg' ) ); ?>  

            </div><!-- .entry-content -->

            <?php
                wp_link_pages( array(
                'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'iceberg' ) . '</span>',
                'after'       => '</div>',
                'pagelink'    => '%',
                'separator'   => ' ',
                ) );
            ?>

            <?php iceberg_the_post_footer( false, get_theme_mod( 'display_page_share_buttons', 1 ), '<footer class="entry-footer">', '</footer>' ); ?>

        </div><!-- .content-container -->

    </div><!-- .inner-box -->
    
</article><!-- #post-## -->
