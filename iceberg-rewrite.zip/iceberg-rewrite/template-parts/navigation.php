<?php
/**
 * Displays the next and previous post navigation in single posts.
 *
 * @package WordPress
 * @subpackage Iceberg
 * @since Iceberg 1.0
 */

$next_post = get_next_post();
$prev_post = get_previous_post();

if ( $next_post || $prev_post ) {

	$pagination_classes = '';

	if ( ! $next_post ) {
		$pagination_classes = ' only-one only-prev';
	} elseif ( ! $prev_post ) {
		$pagination_classes = ' only-one only-next';
	}
	$previous_post_wrapper_classes = '';
	$next_post_wrapper_classes = '';

	if( $next_post ) {
		$next_post_has_thumbnail = has_post_thumbnail( $next_post->ID );
		
		if( $next_post_has_thumbnail ) {
			$next_post_wrapper_classes = ' has-cover-image';
		}
	}

	if( $prev_post ) {
		$previous_post_has_thumbnail = has_post_thumbnail( $prev_post->ID );

		if( $previous_post_has_thumbnail ) {
			$previous_post_wrapper_classes = ' has-cover-image';
		}
	}
	?>

	<nav class="pagination-single <?php echo esc_attr( $pagination_classes ); ?>" aria-label="<?php esc_attr_e( 'Post', 'iceberg' ); ?>" role="navigation">

		<?php
		if ( $prev_post ) {
			?>
			<div class="prevous-post<?php echo esc_attr( $previous_post_wrapper_classes ); ?>">

				<?php 
				if( $previous_post_has_thumbnail ) { 
					?>

					<div class="pagination-single-cover">
						<?php echo get_the_post_thumbnail( $prev_post->ID ); ?>
					</div>

					<?php
				}
				?>

				<div class="prevous-post-inner">
					<span class="nav-meta"><?php esc_html_e( 'Previous post', 'iceberg' ); ?></span>
					<a class="post-link previous-post-link" href="<?php echo esc_url( get_permalink( $prev_post->ID ) ); ?>">
						<?php echo wp_kses_post( get_the_title( $prev_post->ID ) ); ?>
					</a>
				</div>
			</div>
			<?php
		}

		if ( $next_post ) {
			?>
			<div class="next-post<?php echo esc_attr( $next_post_wrapper_classes ); ?>">

				<?php 
				if( $next_post_has_thumbnail ) { 
					?>

					<div class="pagination-single-cover">
						<?php echo get_the_post_thumbnail( $next_post->ID ); ?>
					</div>

					<?php
				}
				?>

				<div class="next-post-inner">
					<span class="nav-meta"><?php esc_html_e( 'Next post', 'iceberg' ); ?></span>
					<a class="post-link next-post-link" href="<?php echo esc_url( get_permalink( $next_post->ID ) ); ?>">
						<?php echo wp_kses_post( get_the_title( $next_post->ID ) ); ?>
					</a>
				</div>
			</div>
			<?php
		}
		?>

	</nav><!-- .pagination-single -->

	<?php
}
