<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @since Iceberg 1.0
 */
?>
<?php iceberg_render_ad('footer_wide'); ?>

</div><!-- .site-content -->

</div><!-- .wrapper -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>

</html>