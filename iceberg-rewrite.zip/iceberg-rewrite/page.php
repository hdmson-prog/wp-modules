<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @since Iceberg 1.0
 */

get_header(); ?>

<div id="primary" class="content-area">

	<main id="main" class="site-main">

		<?php
		// Start the loop.
		while (have_posts()):
			the_post();

			// Include the page content template.
			iceberg_render_ad('above_single_content');
			get_template_part('template-parts/content-page', get_post_format());
			iceberg_render_ad('below_single_content');

			// If comments are open or we have at least one comment, load up the comment template.
			if (comments_open() || get_comments_number()):
				comments_template();
			endif;

			// End the loop.
		endwhile;
		?>

	</main><!-- .site-main -->

</div><!-- .content-area -->

<?php get_footer(); ?>