<?php
/**
 * Theme setup class.
 *
 * Set up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support post thumbnails.
 *
 */

class Iceberg_Setup
{

    // Theme version
    protected $version;

    // Theme unique id
    protected $theme_slug;

    public function __construct()
    {
        $this->version = wp_get_theme()->get('Version');
        $this->theme_slug = 'iceberg';
    }

    /**
     * Setup theme. Add actions, filters, features etc.
     *
     * @since Iceberg 1.0
     */
    public function setup()
    {
        global $content_width;

        /**
         * Set up the content width value based on the theme's design.
         */
        if (!isset($content_width)) {
            $content_width = 1180;
        }

        /*
         * Make theme available for translation.
         *
         * Translations can be added to the /languages/ directory.
         */
        load_theme_textdomain('iceberg', get_template_directory() . '/languages');

        // Add RSS feed links to <head> for posts and comments.
        add_theme_support('automatic-feed-links');

        // Enable support for Post Thumbnails, and declare two sizes.
        add_theme_support('post-thumbnails');
        set_post_thumbnail_size(1200, 9999, false);
        add_image_size('iceberg-post-thumbnail-crop', 1200, 750, true);
        add_image_size('iceberg-medium-thumbnail', 500, 320, true);
        add_image_size('iceberg-medium-square-thumbnail', 500, 500, true);

        // Register navigation menus.
        register_nav_menus(array(
            'primary' => esc_html__('Primary Navigation', 'iceberg'),
            'social' => esc_html__('Sidebar Social Links', 'iceberg')
        ));

        add_theme_support(
            'custom-logo',
            array(
            'flex-height' => true,
            'flex-width' => true
        )
        );

        /*
         * Switch default core markup for search form, comment form, and comments
         * to output valid HTML5.
         */
        add_theme_support(
            'html5',
            array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'script',
            'style',
        )
        );

        /*
         * Enable support for Post Formats.
         *
         * See: https://codex.wordpress.org/Post_Formats
         */
        add_theme_support('post-formats', array('video', 'gallery'));
        add_post_type_support('page', 'post-formats');

        // Add document title tag to HTML <head>.
        add_theme_support('title-tag');

        // Setup the WordPress core custom background feature.    
        add_theme_support('custom-background', array(
            'default-color' => 'f1f1f1'
        ));

        // Add public scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'), 10);

        // Widgets init
        add_action('widgets_init', array($this, 'widgets_init'));

        // Set new excerpt more text
        add_filter('excerpt_more', array($this, 'custom_excerpt_more'));

        // Add classes to body tag.
        add_filter('body_class', array($this, 'add_body_class'));

        add_filter('wp_list_categories', array($this, 'cat_count_span'));
        add_filter('get_archives_link', array($this, 'archive_count_span'), 10, 6);

        // Comment form fields
        add_filter('comment_form_default_fields', array($this, 'comment_form_default_fields'), 10, 1);

        // Modification archives title
        add_filter('get_the_archive_title', array($this, 'archive_title'), 10, 1);

        // Add support for Block Styles.
        add_theme_support('wp-block-styles');

        add_theme_support('responsive-embeds');


        add_filter('the_content_more_link', array($this, 'read_more_tag'));
    }

    /**
     * Register and enqueue theme scripts.
     *
     * @since Iceberg 1.0
     */
    public function enqueue_scripts()
    {
        // Enqueue scripts
        if ((!is_admin()) && is_singular() && comments_open() && get_option('thread_comments')) {
            wp_enqueue_script('comment-reply');
        }

        wp_enqueue_script('highlight-min-js', get_template_directory_uri() . '/assets/js/highlight.min.js', array(), '11.9.0', true);

        wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array(), '5.1.3', true);

        wp_register_script('swiper-bundle', get_template_directory_uri() . '/assets/js/swiper-bundle.min.js', array(), '7.4.1', true);

        wp_localize_script(
            'swiper-bundle',
            'icebergSwiperVars',
            array(
            'speed' => apply_filters('iceberg_swiper_speed', 600),
            'autoplayDelay' => apply_filters('iceberg_swiper_autoplay_delay', get_theme_mod('owl_autoplay_timeout', 4000)),
            'pagination' => apply_filters('iceberg_swiper_autoplay_delay', true),
            'firstSlideMessage' => esc_html__('This is the first slide', 'iceberg'),
            'lastSlideMessage' => esc_html__('This is the last slide', 'iceberg'),
            'nextSlideMessage' => esc_html__('Next slide', 'iceberg'),
            'paginationBulletMessage' => esc_html__('Go to slide {{index}}', 'iceberg'),
            'prevSlideMessage' => esc_html__('Previous slide', 'iceberg'),
            'containerMessage' => esc_html__('Image Carousel', 'iceberg'),
            'containerRoleDescriptionMessage' => esc_html__('carousel', 'iceberg'),
            'itemRoleDescriptionMessage' => esc_html__('slide', 'iceberg')
        )
        );

        $preloader_enabled = (bool)get_theme_mod('show_preloader_screen', 1);

        if ($preloader_enabled) {
            wp_enqueue_script('imagesloaded');
        }

        wp_enqueue_script('iceberg-js', get_template_directory_uri() . '/assets/js/index.js', array('highlight-min-js'), $this->version, true);

        wp_localize_script(
            'iceberg-js',
            'icebergVars',
            array(
            'preloaderEnabled' => $preloader_enabled
        )
        );
    }

    /**
     * Register and enqueue theme styles.
     *
     * @since Iceberg 1.0
     */
    public function enqueue_styles()
    {
        // Add fonts, used in the main stylesheet.
        //wp_enqueue_style( 'iceberg-fonts', esc_url( $this->get_google_fonts_url() ), array(), null );

        wp_register_style('swiper-bundle', get_template_directory_uri() . '/assets/css/swiper-bundle.min.css', array(), '7.4.1');

        // Load our main stylesheet.
        wp_enqueue_style('iceberg-style', get_stylesheet_uri(), array(), $this->version);

        // Highlight.js CSS theme.
        wp_enqueue_style('highlight-js-style', get_template_directory_uri() . '/assets/css/github-dark.min.css', array(), '11.9.0');

        // Highlight.js compatibility CSS.
        wp_add_inline_style('highlight-js-style', '
            pre {
                padding: 2em 2.5em !important;
                position: relative !important;
                background: #0d1117 !important;
                border: 1px solid rgba(255,255,255,0.1) !important;
                border-radius: 6px !important;
                color: #e6edf3 !important;
            }
            pre code {
                padding: 0 !important;
                background: transparent !important;
                font-family: var(--primary-font-family, monospace) !important;
                font-size: 1.3rem !important;
                display: block;
                overflow-x: auto;
            }
            .hljs-copy-button {
                position: absolute;
                top: 0.8rem;
                right: 0.8rem;
                padding: 0.5rem 1rem;
                font-size: 1.1rem;
                background: rgba(255, 255, 255, 0.1) !important;
                color: #ffffff !important;
                border: 1px solid rgba(255, 255, 255, 0.2) !important;
                border-radius: 4px;
                cursor: pointer;
                transition: all 0.2s ease;
                text-transform: none;
                font-weight: 500;
                line-height: 1;
                opacity: 0;
                z-index: 10;
            }
            pre:hover .hljs-copy-button {
                opacity: 1;
            }
            .hljs-copy-button:hover {
                background: rgba(255, 255, 255, 0.2) !important;
                border-color: rgba(255, 255, 255, 0.4) !important;
            }
            .hljs-copy-button.is-copied {
                background: #238636 !important;
                border-color: #2ea043 !important;
            }
        ');

        // Add customizer css.
        wp_add_inline_style('iceberg-style', strip_tags($this->inline_style_css()));
    }

    /**
     * Register Google fonts for Wild Book.
     *
     * @since Iceberg 2.0.2
     *
     * @return string Google fonts URL for the theme.
     */
    public function get_google_fonts_url()
    {
        $fonts_url = '';
        $fonts = array();

        /* translators: If there are characters in your language that are not supported by PT Serif, translate this to 'off'. Do not translate into your own language. */
        if ('off' !== esc_attr_x('on', 'PT Serif font: on or off', 'iceberg')) {
            $fonts[] = 'PT+Serif:ital,wght@0,400;0,700;1,400;1,700';
        }

        /* translators: If there are characters in your language that are not supported by Poppins, translate this to 'off'. Do not translate into your own language. */
        if ('off' !== esc_attr_x('on', 'Poppins font: on or off', 'iceberg')) {
            $fonts[] = 'Poppins:ital,wght@0,400;0,600;1,400;1,600';
        }

        /* Use Open Sans font if language that are not supported by Poppins */
        if ('off' !== _x('off', 'Open Sans font: on or off', 'iceberg')) {
            $fonts[] = 'Open+Sans:ital,wght@0,400;0,600;0,700;1,400;1,600;1,700';
        }

        /* Use Cairo font for Arabic language */
        if ('off' !== _x('off', 'Cairo font: on or off', 'iceberg')) {
            $fonts[] = 'Cairo:wght@400;700';
        }

        /* Use Rubik font for Hebrew language */
        if ('off' !== _x('off', 'Rubik font: on or off', 'iceberg')) {
            $fonts[] = 'Rubik:ital,wght@0,400;0,700;1,400;1,700';
        }

        if ($fonts) {
            $fonts_url = '//fonts.googleapis.com/css2?family=' . implode('&family=', $fonts) . '&display=swap';
        }

        return $fonts_url;
    }

    /**
     * Inline style. Used in wp_add_inline_style.
     *
     * @since Iceberg 1.0
     */
    public function inline_style_css()
    {
        $inline_style = $this->get_inline_style_css();

        $inline_style .= '
            .site {
                visibility:hidden;
            }
            body.site-loaded .site {
                visibility:visible;
            }';

        return $inline_style;
    }

    /**
     * Get inline style CSS.
     *
     * @since Iceberg 1.0
     *
     * @return string Css with custom styles.
     */
    public function get_inline_style_css()
    {
        $css = '';
        $root = '';

        $logo_width = get_theme_mod('logo_width');

        if ($logo_width) {
            $root .= sprintf(
                '
                --logo--max-width: %drem;',
                absint($logo_width)
            );
        }

        $logo_margin_bottom = get_theme_mod('logo_margin_bottom');

        if ($logo_margin_bottom) {
            $root .= sprintf(
                '
                --logo--margin-bottom: %drem;',
                absint($logo_margin_bottom)
            );
        }

        $sidebar_background_color = get_theme_mod('sidebar_background_color');

        if ($sidebar_background_color && $sidebar_background_color !== '#27282b') {
            $root .= sprintf(
                '
                --sidebar--background-color: %s;',
                $sidebar_background_color
            );
        }

        $sidebar_text_color = get_theme_mod('sidebar_text_color');

        if ($sidebar_text_color && $sidebar_text_color !== '#cccccc') {
            $root .= sprintf(
                '
                --sidebar--text-color: %s;',
                $sidebar_text_color
            );
            $root .= sprintf(
                '
                --sidebar--table-border-color: %s;',
                $this->hex2rgba($sidebar_text_color, 0.15, true)
            );
        }

        $site_title_color = get_theme_mod('site_title_color');

        if ($site_title_color && $site_title_color !== '#ffffff') {
            $root .= sprintf(
                '
                --site-title--color: %s;',
                $site_title_color
            );
        }

        $social_icons_color = get_theme_mod('social_icons_color');

        if ($social_icons_color && $social_icons_color !== '#ffffff') {
            $root .= sprintf(
                '
                --social-menu--icon-color: %s;',
                $social_icons_color
            );
        }

        $sidebar_links_color = get_theme_mod('sidebar_links_color');

        if ($sidebar_links_color && $sidebar_links_color !== '#ffffff') {
            $root .= sprintf(
                '
                --sidebar--link-color: %s;',
                $sidebar_links_color
            );
            $root .= sprintf(
                '
                --widget--tag-border-color: %s;
                --widget--tag-text-color: %s;
                --widget--tag-border-color-hover: %s;
                --widget--tag-text-color-hover: %s;',
                $this->hex2rgba($sidebar_links_color, 0.2, true),
                $this->hex2rgba($sidebar_links_color, 0.7, true),
                $this->hex2rgba($sidebar_links_color, 0.7, true),
                $sidebar_links_color
            );
        }

        $sidebar_links_hover_color = get_theme_mod('sidebar_links_hover_color');

        if ($sidebar_links_hover_color && $sidebar_links_hover_color !== '#ffffff') {
            $root .= sprintf(
                '
                --sidebar--link-color-hover: %s;',
                $sidebar_links_hover_color
            );
        }

        $sidebar_divider_color = get_theme_mod('sidebar_divider_color');

        if ($sidebar_divider_color && $sidebar_divider_color !== '#1d1e21') {
            $root .= sprintf(
                '
                --sidebar--styled-divider-box-shadow-color: transparent;
                --sidebar--styled-divider-border-color: %s;',
                $sidebar_divider_color
            );
        }

        $sidebar_inputs_background_color = get_theme_mod('sidebar_inputs_background_color');

        if ($sidebar_inputs_background_color && $sidebar_inputs_background_color !== '#2f3032') {
            $root .= sprintf(
                '
                --sidebar--input-background-color: %s;',
                $sidebar_inputs_background_color
            );
        }

        $sidebar_inputs_text_color = get_theme_mod('sidebar_inputs_text_color');

        if ($sidebar_inputs_text_color && $sidebar_inputs_text_color !== '#ffffff') {
            $root .= sprintf(
                '
                --sidebar--input-text-color: %s;',
                $sidebar_inputs_text_color
            );
            $root .= sprintf(
                '
                --sidebar--input-placeholder-color: %s;',
                $this->hex2rgba($sidebar_inputs_text_color, 0.7, true)
            );
        }

        $sidebar_mobile_button_background_color = get_theme_mod('sidebar_mobile_button_background_color');

        if ($sidebar_mobile_button_background_color && $sidebar_mobile_button_background_color !== '#2f3032') {
            $root .= sprintf(
                '
                --mobile-button--background-color: %s;',
                $sidebar_mobile_button_background_color
            );
        }

        $link_color = get_theme_mod('link_color');

        if ($link_color && $link_color !== '#40824d') {
            $root .= sprintf(
                '
                --global--accent-color-link: %s;',
                $link_color
            );
        }

        $link_color_hover = get_theme_mod('link_color_hover');

        if ($link_color_hover && $link_color_hover !== '#366d41') {
            $root .= sprintf(
                '
                --global--accent-color-link-hover: %s;',
                $link_color_hover
            );
        }

        $button_background_color = get_theme_mod('button_background_color');

        if ($button_background_color && $button_background_color !== '#40824d') {
            $root .= sprintf(
                '
                --button--background-color: %s;',
                $button_background_color
            );
        }

        $button_background_color_hover = get_theme_mod('button_background_color_hover');

        if ($button_background_color_hover && $button_background_color_hover !== '#366d41') {
            $root .= sprintf(
                '
                --button--background-color-hover: %s;',
                $button_background_color_hover
            );
        }

        $button_text_color = get_theme_mod('button_text_color');

        if ($button_text_color && $button_text_color !== '#ffffff') {
            $root .= sprintf(
                '
                --button--text-color: %s;',
                $button_text_color
            );
        }

        $category_label_color = get_theme_mod('category_label_color');

        if ($category_label_color && $category_label_color !== '#247abc') {
            $root .= sprintf(
                '
                --category-link--background-color: %s;',
                $category_label_color
            );
        }

        $preloader_color = get_theme_mod('preloader_color');

        if ($preloader_color && $preloader_color !== '#d1d1d1') {
            $root .= sprintf(
                '
                --preloader--background-color: %s;',
                $preloader_color
            );
        }

        $selection_color = get_theme_mod('selection_color');

        if ($selection_color && $selection_color !== '#3579ce') {
            $root .= sprintf(
                '
                --global--selection-background-color: %s;',
                $selection_color
            );
        }

        if ($root) {
            $css .= sprintf(
                '
                :root {
                    %s
                }',
                $root
            );
        }

        $categories_color = get_option('iceberg_categories_color');

        if (is_array($categories_color)) {

            foreach ($categories_color as $category_id => $category_color) {

                if ($category_color) {

                    $css .= sprintf(
                        '
                        .entry-categories .category-%1$d,
                        .widget_categories .cat-item-%1$d a:before { 
                            background-color: %2$s;
                            opacity: 1;
                        }
                        ',
                        absint($category_id),
                        $category_color
                    );

                }

            }

        }

        return $css;
    }
    /**
     * Convert hex to rgba.
     *
     * @since Iceberg 2.0
     *
     * @return string/array Converted color.
     */
    public function hex2rgba($color, $opacity = 1, $css = false)
    {
        if (empty($color))
            return;

        $color = str_replace('#', '', $color);

        if (strlen($color) == 6) {
            $r = hexdec($color[0] . $color[1]);
            $g = hexdec($color[2] . $color[3]);
            $b = hexdec($color[4] . $color[5]);
        }
        elseif (strlen($color) == 3) {
            $r = hexdec($color[0] . $color[0]);
            $g = hexdec($color[1] . $color[1]);
            $b = hexdec($color[2] . $color[2]);
        }
        else {
            return false;
        }

        $opacity = floatval($opacity);

        if ($css)
            return 'rgba( ' . $r . ', ' . $g . ', ' . $b . ', ' . $opacity . ' )';
        else
            return compact($r, $g, $b, $opacity);
    }

    /**
     * Sanitizes a hex color.
     *
     * @since Iceberg 1.0
     */
    public function sanitize_hex_color($color)
    {
        if ('' === $color)
            return '';

        // 3 or 6 hex digits, or the empty string.
        if (preg_match('|^#([A-Fa-f0-9]{3}){1,2}$|', $color))
            return $color;
    }

    /**
     * Register widget area.
     *
     * @since Iceberg 1.0
     *
     * @link https://codex.wordpress.org/Function_Reference/register_sidebar
     */
    public function widgets_init()
    {

        // Register sidebar
        register_sidebar(array(
            'name' => esc_html__('Widget Area', 'iceberg'),
            'id' => 'widget-area',
            'description' => esc_html__('Add widgets here to appear in sidebar', 'iceberg'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));

        // Register custom widgets
        register_widget('Iceberg_Ad_Image_Widget');
        register_widget('Iceberg_Recent_Posts_Widget');
    }

    /**
     * Modification default excerpt more.
     *
     * @since Iceberg 1.0
     *
     * @return string Excerpt more text.
     */
    public function custom_excerpt_more($more)
    {
        return '&hellip;';
    }

    /**
     * Add classes to body tag.
     *
     * @since Iceberg 1.0
     *
     * @return array Body classes array.
     */
    public function add_body_class($classes)
    {
        if (!(bool)get_theme_mod('show_preloader_screen', 1)) {
            $classes[] = 'site-loaded';
        }

        if (in_array(get_theme_mod('basic_layout', 'sidebar-left'), array('sidebar-left', 'sidebar-right'))) {
            $classes[] = get_theme_mod('basic_layout', 'sidebar-left');
        }

        return $classes;
    }

    /**
     * Remove () and add <span> tag to posts count in categories list.
     *
     * @since Iceberg 1.0
     *
     * @return string Html with links
     */
    function cat_count_span($links)
    {
        $links = str_replace('</a> (', '</a> <span>', $links);
        $links = str_replace(')', '</span>', $links);

        return $links;
    }

    /**
     * Remove () and add <span> tag to posts count in archives list.
     *
     * @since Iceberg 1.0
     *
     * @return string Html with links
     */
    function archive_count_span($link_html, $url, $text, $format, $before, $after)
    {
        if ($format !== 'option') {
            $link_html = str_replace('</a>&nbsp;(', '</a> <span>', $link_html);
            $link_html = str_replace(')', '</span>', $link_html);
        }

        return $link_html;
    }

    /**
     * Modification of the default fields of the comment form.
     *
     * @since Iceberg 1.4
     */
    public function comment_form_default_fields($fields)
    {
        $commenter = wp_get_current_commenter();

        $req = get_option('require_name_email');
        $html_req = ($req ? " required='required'" : '');
        $html5 = 'html5';
        $aria_req = '';

        $fields['author'] = sprintf(
            '<p class="comment-form-author">%s %s</p>',
            sprintf(
            '<label for="author" class="screen-reader-text">%s%s</label>',
            esc_attr__('Name', 'iceberg'),
            ($req ? ' <span class="required">*</span>' : '')
        ),
            sprintf(
            '<input id="author" name="author" type="text" placeholder="%s" value="%s" size="30" maxlength="245"%s />',
            esc_attr__('Name', 'iceberg') . ($req ? ' *' : ''),
            esc_attr($commenter['comment_author']),
            $html_req
        )
        );

        $fields['email'] = sprintf(
            '<p class="comment-form-email" class="screen-reader-text">%s %s</p>',
            sprintf(
            '<label for="email" class="screen-reader-text">%s%s</label>',
            esc_attr__('Email', 'iceberg'),
            ($req ? ' <span class="required">*</span>' : '')
        ),
            sprintf(
            '<input id="email" name="email" %s placeholder="%s" value="%s" size="30" maxlength="100" aria-describedby="email-notes"%s />',
            ($html5 ? 'type="email"' : 'type="text"'),
            esc_attr__('Email', 'iceberg') . ($req ? ' *' : ''),
            esc_attr($commenter['comment_author_email']),
            $html_req
        )
        );

        $fields['url'] = sprintf(
            '<p class="comment-form-url">%s %s</p>',
            sprintf(
            '<label for="url" class="screen-reader-text">%s</label>',
            esc_attr__('Website', 'iceberg')
        ),
            sprintf(
            '<input id="url" name="url" %s placeholder="%s" value="%s" size="30" maxlength="200" />',
            ($html5 ? 'type="url"' : 'type="text"'),
            esc_attr__('Website', 'iceberg'),
            esc_attr($commenter['comment_author_url'])
        )
        );

        return $fields;
    }

    /**
     * Overwrite default more tag with styling and screen reader markup.
     *
     * @param string $html The default output HTML for the more tag.
     * @return string
     */
    public function read_more_tag($html)
    {
        return preg_replace('/<a(.*)>(.*)<\/a>/iU', sprintf('<div class="read-more-button-wrap"><a$1>$2 <span class="screen-reader-text">"%1$s"</span></a></div>', get_the_title(get_the_ID())), $html);
    }

    /**
     * Changing default archive title for portfolio post type.
     *
     * @since Iceberg 1.4
     */
    public function archive_title($title)
    {
        if (is_category()) {
            return sprintf('<span class="screen-reader-text">%s</span> %s', esc_html__('Category:', 'iceberg'), single_cat_title('', false));
        }

        if (is_author()) {
            return sprintf('<span class="screen-reader-text">%s</span> %s', esc_html__('Author:', 'iceberg'), get_the_author());
        }

        return $title;
    }
}

$iceberg_setup = new Iceberg_Setup();

add_action('after_setup_theme', array($iceberg_setup, 'setup'), 10);

/**
 * Customizer additions.
 *
 * @since Iceberg 1.0
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Custom template tags for this theme.
 *
 * @since Iceberg 1.0
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Post formats output class.
 *
 * @since Iceberg 1.0
 */
require get_template_directory() . '/classes/class-iceberg-post-formats.php';

/**
 * Add fields to category form.
 *
 * @since Iceberg 1.2
 */
require get_template_directory() . '/classes/class-iceberg-category-form-fields-setup.php';

/**
 * TGM Plugin Activation
 *
 * @since Iceberg 1.5
 */
require get_template_directory() . '/inc/tgmpa/tgmpa.php';

/**
 * Handle SVG icons
 *
 * @since Iceberg 2.0
 */
require get_template_directory() . '/classes/class-iceberg-svg-icons.php';
require get_template_directory() . '/inc/svg-icons.php';

/**
 * One Click Demo Import
 *
 * @since Iceberg 2.0.3
 */
require get_template_directory() . '/inc/one-click-demo-import/one-click-demo-import.php';

/**
 * Custom page walker
 *
 * @since Iceberg 2.1
 */
require get_template_directory() . '/classes/class-iceberg-walker-page.php';

/**
 * Custom comment walker
 *
 * @since Iceberg 2.1
 */
require get_template_directory() . '/classes/class-iceberg-walker-comment.php';

/**
 * Custom Ad Image Widget
 *
 * @since Iceberg 2.5
 */
require get_template_directory() . '/classes/class-iceberg-ad-image-widget.php';
/**
 * Custom Recent Posts Widget
 *
 * @since Iceberg 2.6
 */
require get_template_directory() . '/classes/class-iceberg-recent-posts-widget.php';

//clean up
require_once get_template_directory() . '/inc/clean-ups.php';

//url rewriter
require_once get_template_directory() . '/inc/url-rewriter.php';

//user avatar
require_once get_template_directory() . '/inc/user-avatar.php';

//custom post types
require_once get_template_directory() . '/inc/custom-posttypes.php';

//custom login page
require_once get_template_directory() . '/inc/custom-login.php';

//polylang
require_once get_template_directory() . '/inc/polylang-pro.php';

//nord share and follow buttons
require_once get_template_directory() . '/inc/nord-share-and-follow-buttons/nord-share-and-follow-buttons.php';


/**
 * Custom language switcher for Polylang
 */
function iceberg_language_switcher()
{
    if (!function_exists('pll_the_languages')) {
        return;
    }

    $languages = pll_the_languages(array(
        'raw' => 1,
        'hide_if_no_translation' => 0,
        'force_home' => 1,
    ));

    if (empty($languages)) {
        return;
    }

    $current_lang = array();
    foreach ($languages as $lang) {
        if ($lang['current_lang']) {
            $current_lang = $lang;
            break;
        }
    }

    if (empty($current_lang) && !empty($languages)) {
        $current_lang = reset($languages);
    }
?>
    <div class="iceberg-language-switcher">
        <div class="lang-dropdown">
            <button class="lang-toggle" aria-haspopup="true" aria-expanded="false" id="lang-switcher-toggle">
                <span class="lang-current">
                    <?php if (!empty($current_lang['flag'])): ?>
                        <span class="lang-flag">
                            <?php
        if (strpos($current_lang['flag'], '<img') !== false) {
            echo $current_lang['flag'];
        }
        else {
            echo '<img src="' . esc_url($current_lang['flag']) . '" alt="' . esc_attr($current_lang['name']) . '" />';
        }
?>
                        </span>
                    <?php
    endif; ?>
                    <span class="lang-name"><?php echo esc_html($current_lang['name']); ?></span>
                </span>
                <span class="lang-arrow"><?php iceberg_the_theme_svg('chevron-down'); ?></span>
            </button>
            <ul class="lang-list" aria-labelledby="lang-switcher-toggle">
                <?php foreach ($languages as $lang):
        if ($lang['current_lang'])
            continue;
?>
                    <li class="lang-item">
                        <a href="<?php echo esc_url($lang['url']); ?>" class="lang-link">
                            <?php if (!empty($lang['flag'])): ?>
                                <span class="lang-flag">
                                    <?php
            if (strpos($lang['flag'], '<img') !== false) {
                echo $lang['flag'];
            }
            else {
                echo '<img src="' . esc_url($lang['flag']) . '" alt="' . esc_attr($lang['name']) . '" />';
            }
?>
                                </span>
                            <?php
        endif; ?>
                            <span class="lang-name"><?php echo esc_html($lang['name']); ?></span>
                        </a>
                    </li>
                <?php
    endforeach; ?>
            </ul>
        </div>
    </div>
    <?php
}
