<?php
/**
 * The Sidebar containing the main widget area
 *
 * @since Iceberg 1.0
 */
?>

<div id="sidebar" class="sidebar">

    <header id="musthead" class="site-header" role="banner">

        <div class="site-identity">

            <?php iceberg_site_identity(); ?>
            <?php iceberg_custom_text('tagline', '<div class="tagline">', '</div>'); ?>

        </div>

        <?php if (has_nav_menu('social')) { ?>

            <nav aria-label="<?php esc_attr_e('Social links', 'iceberg'); ?>" class="social-menu-wrapper">

                <ul class="social-menu sidebar-social">

                    <?php
                    wp_nav_menu(
                        array(
                            'theme_location' => 'social',
                            'container' => '',
                            'container_class' => '',
                            'items_wrap' => '%3$s',
                            'menu_id' => '',
                            'menu_class' => '',
                            'depth' => 1,
                            'link_before' => '<span class="screen-reader-text">',
                            'link_after' => '</span>',
                            'fallback_cb' => '',
                        )
                    );
                    ?>

                </ul><!-- .sidebar-social -->

            </nav><!-- .social-menu-wrapper -->

        <?php } ?>

        <?php if (has_nav_menu('primary') || is_active_sidebar('widget-area') || wp_list_pages(array('echo' => false)) || function_exists('pll_the_languages')): ?>
            <div class="toggles">
                <button id="mobile-toggle" class="mobile-toggle toggle" data-bs-toggle="collapse"
                    data-bs-target="#sidebar-content" aria-expanded="false" aria-controls="sidebar-content"
                    aria-label="<?php esc_attr_e('Open Menu', 'iceberg'); ?>"><?php iceberg_the_theme_svg('menu'); ?></button>
            </div>
        <?php endif; ?>

    </header>

    <?php if (has_nav_menu('primary') || is_active_sidebar('widget-area') || wp_list_pages(array('echo' => false))): ?>

        <div class="sidebar-toggle-content collapse" id="sidebar-content">

            <?php iceberg_render_ad('sidebar_top'); ?>

            <hr class="styled-hr primary-menu-divider" aria-hidden="true" />

            <?php iceberg_language_switcher();

            if (has_nav_menu('primary') || wp_list_pages(array('echo' => false))): ?>

                <nav class="primary-menu-wrapper" aria-label="<?php echo esc_attr_x('Vertical', 'menu', 'iceberg'); ?>"
                    role="navigation">

                    <ul class="primary-menu vertical-menu reset-list-style">

                        <?php
                        if (has_nav_menu('primary')) {

                            wp_nav_menu(
                                array(
                                    'container' => '',
                                    'items_wrap' => '%3$s',
                                    'theme_location' => 'primary',
                                    'show_toggles' => true,
                                    'collapse' => true,
                                    'parent_selector' => '.primary-menu'
                                )
                            );

                        } else {

                            wp_list_pages(
                                array(
                                    'match_menu_classes' => true,
                                    'show_toggles' => true,
                                    'title_li' => false,
                                    'walker' => new Iceberg_Walker_Page(),
                                )
                            );

                        }
                        ?>

                    </ul>

                </nav>

            <?php endif; ?>

            <?php
            if (is_active_sidebar('widget-area')): ?>

                <hr class="styled-hr widgets-divider" aria-hidden="true" />

                <aside id="widget-area" class="widget-area" role="complementary">
                    <?php dynamic_sidebar('widget-area'); ?>
                </aside>

            <?php endif; ?>

            <?php
            iceberg_custom_text(
                'copyright',
                '<footer id="colophon" class="site-footer"><div class="site-copyright">',
                '</div></footer>',
                sprintf('&copy; %1$d <a href="%2$s">%3$s</a>', date('Y'), esc_url(home_url('/')), esc_html(get_bloginfo('name')))
            );
            ?>

        </div><!-- .toggle-wrap -->

    <?php endif; ?>

</div>