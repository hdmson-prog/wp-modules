<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * e.g., it puts together the home page when no home.php file exists.
 *
 * Learn more: {@link https://codex.wordpress.org/Template_Hierarchy}
 *
 * @since Iceberg 1.0
 */

get_header(); ?>

<div id="primary" class="content-area">

	<main id="main" class="site-main">
		<?php iceberg_render_ad('above_posts_loop'); ?>

		<?php if (have_posts()): ?>

			<?php if (is_home() && !is_front_page()): ?>

				<header class="page-header">
					<h1 class="page-title"><?php single_post_title(); ?></h1>
				</header>

			<?php endif; ?>

			<?php
			// Start the loop.
			while (have_posts()):
				the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part('template-parts/content', get_post_format());

				// End the loop.
			endwhile;

			// Pagination
			get_template_part('template-parts/pagination');

		// If no content, include the "No posts found" template.
	else:
		get_template_part('template-parts/content', 'none');
	endif;
	?>

	</main><!-- .site-main -->

</div><!-- .content-area -->

<?php get_footer(); ?>