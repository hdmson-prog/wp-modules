<?php
/**
 * The Header for our theme
 *
 * Displays all of the <head> section and everything up till <div id="main">
 */
?><!doctype html>

    <html <?php language_attributes(); ?>>

        <head>

          <meta charset="<?php bloginfo( 'charset' ); ?>" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <link rel="profile" href="https://gmpg.org/xfn/11" />
          <?php wp_head(); ?>

        </head>

        <body <?php body_class(); ?>>
<!-- 
            <?php 
$ad_image = get_theme_mod( 'ad_above_single_content' );
if ( $ad_image ) : ?>
    <div class="iceberg-ad-container ad-single-top" style="margin-bottom: 20px;">
        <img src="<?php echo esc_url( $ad_image ); ?>" alt="<?php esc_attr_e( 'Advertisement', 'iceberg' ); ?>" style="max-width:100%; height:auto;">
    </div>
<?php endif; ?> -->

            <?php wp_body_open(); ?>

            <div class="preloader">
                <div class="spinner">
                    <div class="double-bounce1"></div>
                    <div class="double-bounce2"></div>
                </div>
            </div>

            <div id="page" class="hfeed site container">

                <div class="wrapper">

                    <?php get_sidebar(); ?>

                    <div id="content" class="site-content">