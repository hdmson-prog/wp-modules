<?php
/**
 * WP Starter Theme functions and definitions.
 *
 * @package WP_Starter
 */

define('WP_STARTER_VERSION', '1.0.0');

require get_template_directory() . '/inc/setup.php';
require get_template_directory() . '/inc/enqueue.php';


// The common-scripts.php enqueued all assets indiscriminately, causing style conflicts.

require_once get_template_directory() . '/framework/vendor/wp-rapid-fields.php';
require_once get_template_directory() . '/framework/admin/wrf-init.php';

require_once get_template_directory() . '/framework/widgets.php';
require_once get_template_directory() . '/framework/functions/theme-functions.php';

require_once get_template_directory() . '/framework/admin/ws-nav-walker.php';

require_once get_template_directory() . '/framework/admin/custom-sliders.php';

require_once get_template_directory() . '/framework/admin/ws-posttypes.php';

//theme blocks 
require_once get_template_directory() . '/themeblocks/themeblocks.php';

// =========================================================================
require_once get_template_directory() . '/framework/admin/clean-ups.php';


require_once get_template_directory() . '/framework/admin/products-enhancement.php';


//user avatar
require_once get_template_directory() . '/framework/admin/user-avatar.php';


//image_collections
require_once get_template_directory() . '/framework/admin/image-collections.php';

//templates tags
require_once get_template_directory() . '/framework/functions/template-tags.php';


// contact form
require_once get_template_directory() . '/framework/admin/ws-custom-form.php';

// Polylang REST API Extension
//require_once get_template_directory() . '/framework/admin/polylang.php';
require_once get_template_directory() . '/framework/admin/polylang-pro.php';


/**
 * Custom Login Page Enhancements
 */

// Custom login errors (Security: don't reveal if username or password was wrong)
function wp_starter_login_errors()
{
    return __('Invalid username or password. Please try again.', 'tqb');
}
add_filter('login_errors', 'wp_starter_login_errors');

// Redirect failed login to the custom login page instead of wp-login.php
function wp_starter_redirect_failed_login($username)
{
    $referrer = $_SERVER['HTTP_REFERER'];
    if (!empty($referrer) && !strstr($referrer, 'wp-login') && !strstr($referrer, 'wp-admin')) {
        wp_redirect(add_query_arg('login', 'failed', $referrer));
        exit;
    }
}
add_action('wp_login_failed', 'wp_starter_redirect_failed_login');
