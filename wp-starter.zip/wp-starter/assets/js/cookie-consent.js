/**
 * Cookie Consent Manager
 *
 * Handles displaying the cookie consent banner,
 * saving user preferences to localStorage, and
 * triggering events for analytics/marketing scripts.
 *
 * @package WP_Starter
 */
(function () {
    'use strict';

    const STORAGE_KEY = 'tqb_cookie_consent';
    const CONSENT_VERSION = 1; // Bump this to re-prompt users after policy changes

    // DOM elements (cached after DOMContentLoaded)
    let banner, backdrop, acceptBtn, rejectBtn, manageBtn, prefsPanel;
    let analyticsToggle, marketingToggle;

    /**
     * Get saved consent from localStorage.
     * @returns {object|null}
     */
    function getSavedConsent() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) return null;
            const data = JSON.parse(raw);
            // Re-prompt if consent version changed
            if (data.version !== CONSENT_VERSION) return null;
            return data;
        } catch (e) {
            return null;
        }
    }

    /**
     * Save consent to localStorage.
     * @param {object} consent - { essential: true, analytics: bool, marketing: bool }
     */
    function saveConsent(consent) {
        const data = {
            version: CONSENT_VERSION,
            timestamp: new Date().toISOString(),
            essential: true,
            analytics: !!consent.analytics,
            marketing: !!consent.marketing,
        };
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        } catch (e) {
            // localStorage might be full or disabled
        }
        applyConsent(data);
    }

    /**
     * Apply consent — dispatch a custom event so other scripts can react.
     * For example, analytics scripts can listen for this event before initializing.
     * @param {object} consent
     */
    function applyConsent(consent) {
        // Set data attributes on <html> for CSS-based conditional loading
        document.documentElement.setAttribute('data-cookie-analytics', consent.analytics ? 'true' : 'false');
        document.documentElement.setAttribute('data-cookie-marketing', consent.marketing ? 'true' : 'false');

        // Dispatch custom event
        window.dispatchEvent(new CustomEvent('cookieConsentUpdated', {
            detail: {
                analytics: consent.analytics,
                marketing: consent.marketing,
            }
        }));
    }

    /**
     * Show the banner with animation.
     */
    function showBanner() {
        if (!banner) return;
        banner.style.display = '';
        // Force reflow for animation
        void banner.offsetHeight;
        banner.classList.add('is-visible');

        // Trap focus in the banner for accessibility
        const focusable = banner.querySelectorAll('button, input, a[href]');
        if (focusable.length) {
            focusable[focusable.length - 1].focus();
        }
    }

    /**
     * Hide the banner with animation.
     */
    function hideBanner() {
        if (!banner) return;
        banner.classList.add('is-dismissed');
        banner.classList.remove('is-visible');

        setTimeout(function () {
            banner.style.display = 'none';
            banner.classList.remove('is-dismissed');
        }, 500);
    }

    /**
     * Toggle preferences panel.
     */
    function togglePreferences() {
        if (!prefsPanel) return;

        const isOpen = prefsPanel.style.display !== 'none';

        if (isOpen) {
            prefsPanel.style.display = 'none';
            banner.classList.remove('prefs-open');
            manageBtn.textContent = manageBtn.getAttribute('data-label-manage');
            // Show Accept All, hide Save Preferences
            acceptBtn.style.display = '';
            var saveBtn = banner.querySelector('#cookieSave');
            if (saveBtn) saveBtn.remove();
        } else {
            prefsPanel.style.display = '';
            banner.classList.add('prefs-open');
            manageBtn.setAttribute('data-label-manage', manageBtn.textContent);
            manageBtn.textContent = manageBtn.getAttribute('data-label-close') || '✕ Close';
            // Replace Accept All with Save Preferences
            acceptBtn.style.display = 'none';
            var saveBtn = document.createElement('button');
            saveBtn.id = 'cookieSave';
            saveBtn.className = 'cookie-btn cookie-btn--save';
            saveBtn.type = 'button';
            saveBtn.textContent = acceptBtn.getAttribute('data-label-save') || 'Save Preferences';
            saveBtn.addEventListener('click', function () {
                saveConsent({
                    analytics: analyticsToggle ? analyticsToggle.checked : false,
                    marketing: marketingToggle ? marketingToggle.checked : false,
                });
                hideBanner();
            });
            acceptBtn.parentElement.appendChild(saveBtn);
        }
    }

    /**
     * Initialize everything on DOM ready.
     */
    function init() {
        banner = document.getElementById('cookieConsent');
        if (!banner) return;

        backdrop = banner.querySelector('.cookie-consent__backdrop');
        acceptBtn = document.getElementById('cookieAccept');
        rejectBtn = document.getElementById('cookieReject');
        manageBtn = document.getElementById('cookieManage');
        prefsPanel = document.getElementById('cookiePreferences');
        analyticsToggle = document.getElementById('cookieAnalytics');
        marketingToggle = document.getElementById('cookieMarketing');

        // Store original label for Manage button
        if (manageBtn) {
            manageBtn.setAttribute('data-label-manage', manageBtn.textContent);
            manageBtn.setAttribute('data-label-close', '✕');
        }

        // Store "Save Preferences" label from Accept button as a data attribute
        if (acceptBtn) {
            acceptBtn.setAttribute('data-label-save', acceptBtn.getAttribute('data-save-label') || 'Save Preferences');
        }

        // Check if consent already given
        var saved = getSavedConsent();
        if (saved) {
            applyConsent(saved);
            return; // Don't show banner
        }

        // Accept All
        if (acceptBtn) {
            acceptBtn.addEventListener('click', function () {
                saveConsent({ analytics: true, marketing: true });
                hideBanner();
            });
        }

        // Reject All
        if (rejectBtn) {
            rejectBtn.addEventListener('click', function () {
                saveConsent({ analytics: false, marketing: false });
                hideBanner();
            });
        }

        // Manage Preferences
        if (manageBtn) {
            manageBtn.addEventListener('click', togglePreferences);
        }

        // Show banner after a short delay for better UX
        setTimeout(showBanner, 800);
    }

    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
