// News Data - fetched from PHP (home.php)
const newsData = window.wpNewsData || [];

// Pagination settings
const itemsPerPage = 6;
let currentPage = 1;
let currentCategory = 'all';
let filteredData = [...newsData];

// Initialize news list
function initNews() {
    renderNews();
    renderPagination();
    setupFilterButtons();
}

// Filter news
function filterNews(category) {
    currentCategory = category;
    currentPage = 1;

    if (category === 'all') {
        filteredData = [...newsData];
    } else {
        filteredData = newsData.filter(item => item.category === category);
    }

    renderNews();
    renderPagination();
}

// Render news items
function renderNews() {
    const newsList = document.getElementById('newsList');
    const loadingDiv = document.getElementById('news-loading');

    if (loadingDiv) loadingDiv.style.display = 'none';

    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageItems = filteredData.slice(startIndex, endIndex);

    newsList.innerHTML = '';

    if (pageItems.length === 0) {
        newsList.innerHTML = '<div style="text-align: center; padding: 50px; width: 100%;"><p>No news found in this category.</p></div>';
        return;
    }

    pageItems.forEach((item, index) => {
        const newsItem = document.createElement('div');
        newsItem.className = 'news-list-item';
        newsItem.style.animationDelay = `${index * 0.1}s`;

        const featuredHtml = item.featured
            ? `<img src="${item.featured}" alt="${item.title}" style="width: 100%; height: 100%; object-fit: cover;">`
            : `<svg width="120" height="120" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="20" y="30" width="80" height="60" rx="4" stroke="#1D4E89" stroke-width="2"/>
                    <path d="M30 40 L50 50 M70 40 L90 50" stroke="#1D4E89" stroke-width="2"/>
                    <path d="M30 55 L90 55 M30 65 L80 65 M30 75 L85 75" stroke="#1D4E89" stroke-width="2"/>
                </svg>`;

        newsItem.innerHTML = `
            <div class="news-list-image">
                ${featuredHtml}
            </div>
            <div class="news-list-content">
                <div class="news-list-meta">
                    <span class="news-list-category">${item.categoryName}</span>
                    <span class="news-list-date">${item.date}</span>
                </div>
                <h2 class="news-list-title">
                    <a href="${item.link}">${item.title}</a>
                </h2>
                <p class="news-list-excerpt">${item.excerpt}</p>
                <a href="${item.link}" class="news-list-link">Read Full Article →</a>
            </div>
        `;

        newsList.appendChild(newsItem);
    });
}

// Render pagination
function renderPagination() {
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    const paginationNumbers = document.getElementById('paginationNumbers');
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');

    if (totalPages <= 1) {
        if (paginationNumbers.parentElement) paginationNumbers.parentElement.style.display = 'none';
        return;
    } else {
        if (paginationNumbers.parentElement) paginationNumbers.parentElement.style.display = 'flex';
    }

    // Update button states
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;

    // Render page numbers
    paginationNumbers.innerHTML = '';

    for (let i = 1; i <= totalPages; i++) {
        if (
            i === 1 ||
            i === totalPages ||
            (i >= currentPage - 1 && i <= currentPage + 1)
        ) {
            const pageBtn = document.createElement('button');
            pageBtn.className = 'pagination-number';
            pageBtn.textContent = i;
            if (i === currentPage) pageBtn.classList.add('active');

            pageBtn.addEventListener('click', () => {
                currentPage = i;
                renderNews();
                renderPagination();
                const gridTop = document.getElementById('newsList').getBoundingClientRect().top + window.pageYOffset - 100;
                window.scrollTo({ top: gridTop, behavior: 'smooth' });
            });

            paginationNumbers.appendChild(pageBtn);
        } else if (
            i === currentPage - 2 ||
            i === currentPage + 2
        ) {
            const dots = document.createElement('span');
            dots.textContent = '...';
            dots.style.padding = '0 0.5rem';
            dots.style.color = 'var(--color-text-light)';
            paginationNumbers.appendChild(dots);
        }
    }

    // Setup navigation
    prevBtn.onclick = () => {
        if (currentPage > 1) {
            currentPage--;
            renderNews();
            renderPagination();
            const gridTop = document.getElementById('newsList').getBoundingClientRect().top + window.pageYOffset - 100;
            window.scrollTo({ top: gridTop, behavior: 'smooth' });
        }
    };

    nextBtn.onclick = () => {
        if (currentPage < totalPages) {
            currentPage++;
            renderNews();
            renderPagination();
            const gridTop = document.getElementById('newsList').getBoundingClientRect().top + window.pageYOffset - 100;
            window.scrollTo({ top: gridTop, behavior: 'smooth' });
        }
    };
}

// Setup filter buttons
function setupFilterButtons() {
    const filterBtns = document.querySelectorAll('.filter-btn');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterNews(btn.getAttribute('data-category'));
        });
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', initNews);
