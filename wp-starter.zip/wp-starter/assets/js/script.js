// ===================================
// HERO SLIDER FUNCTIONALITY
// ===================================

const heroSlider = document.getElementById('heroSlider');

if (heroSlider) {
    const slides = heroSlider.querySelectorAll('.slide');
    const dots = heroSlider.querySelectorAll('.slider-dot');
    const prevBtn = heroSlider.querySelector('.slider-arrow-prev');
    const nextBtn = heroSlider.querySelector('.slider-arrow-next');

    let currentSlide = 0;
    let slideInterval;

    function showSlide(index) {
        // Remove active class from all slides and dots
        slides.forEach(slide => slide.classList.remove('active'));
        dots.forEach(dot => dot.classList.remove('active'));

        // Wrap around if needed
        if (index >= slides.length) {
            currentSlide = 0;
        } else if (index < 0) {
            currentSlide = slides.length - 1;
        } else {
            currentSlide = index;
        }

        // Add active class to current slide and dot
        if (slides[currentSlide]) slides[currentSlide].classList.add('active');
        if (dots[currentSlide]) dots[currentSlide].classList.add('active');
    }

    function nextSlide() {
        showSlide(currentSlide + 1);
    }

    function prevSlide() {
        showSlide(currentSlide - 1);
    }

    // Auto-advance slides every 5 seconds
    function startSlideShow() {
        slideInterval = setInterval(nextSlide, 5000);
    }

    function stopSlideShow() {
        clearInterval(slideInterval);
    }

    // Event listeners for slider controls
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            nextSlide();
            stopSlideShow();
            startSlideShow(); // Restart timer after manual navigation
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            prevSlide();
            stopSlideShow();
            startSlideShow(); // Restart timer after manual navigation
        });
    }

    // Dot navigation
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            showSlide(index);
            stopSlideShow();
            startSlideShow(); // Restart timer after manual navigation
        });
    });

    // Pause slider on hover
    heroSlider.addEventListener('mouseenter', stopSlideShow);
    heroSlider.addEventListener('mouseleave', startSlideShow);

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            prevSlide();
            stopSlideShow();
            startSlideShow();
        } else if (e.key === 'ArrowRight') {
            nextSlide();
            stopSlideShow();
            startSlideShow();
        }
    });

    // Start the slideshow
    startSlideShow();
}

// ===================================
// SEARCH BAR FUNCTIONALITY
// ===================================

const searchToggle = document.getElementById('searchToggle');
const searchBar = document.getElementById('searchBar');
const searchClose = document.getElementById('searchClose');
const searchInput = searchBar ? searchBar.querySelector('.search-input') : null;

if (searchToggle && searchBar) {
    searchToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        searchBar.classList.add('active');
        if (searchInput) {
            setTimeout(() => searchInput.focus(), 300);
        }
    });

    if (searchClose) {
        searchClose.addEventListener('click', (e) => {
            e.stopPropagation();
            searchBar.classList.remove('active');
        });
    }

    // Prevent closing when clicking inside search bar
    searchBar.addEventListener('click', (e) => {
        e.stopPropagation();
    });

    // Close search bar when clicking anywhere outside
    document.addEventListener('click', (e) => {
        if (searchBar.classList.contains('active')) {
            searchBar.classList.remove('active');
        }
    });

    // Close search bar on escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && searchBar.classList.contains('active')) {
            searchBar.classList.remove('active');
        }
    });

    // Handle search form submission
    const searchForm = document.getElementById('searchForm');
    if (searchForm) {
        searchForm.addEventListener('submit', (e) => {
            const searchTerm = searchInput ? searchInput.value : '';
            console.log('Search term:', searchTerm);
        });
    }
}

// ===================================
// LANGUAGE SWITCHER FUNCTIONALITY
// ===================================

const langSwitcher = document.querySelector('.lang-switcher');
const langCurrent = langSwitcher ? langSwitcher.querySelector('.lang-current') : null;

if (langCurrent) {
    langCurrent.addEventListener('click', (e) => {
        e.stopPropagation();
        langSwitcher.classList.toggle('active');

        // Update aria-expanded
        const expanded = langSwitcher.classList.contains('active');
        langCurrent.setAttribute('aria-expanded', expanded);
    });

    // Close language dropdown when clicking anywhere outside
    document.addEventListener('click', (e) => {
        if (!langSwitcher.contains(e.target)) {
            langSwitcher.classList.remove('active');
            langCurrent.setAttribute('aria-expanded', 'false');
        }
    });

    // Close on escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && langSwitcher.classList.contains('active')) {
            langSwitcher.classList.remove('active');
            langCurrent.setAttribute('aria-expanded', 'false');
        }
    });
}


// ===================================
// NAVIGATION SCROLL EFFECT
// ===================================

const nav = document.getElementById('mainNav');
const navToggle = document.getElementById('navToggle');
const navMenu = document.getElementById('navMenu');

// Add scroll effect to navigation
if (nav) {
    let lastScroll = 0;
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;

        if (currentScroll > 100) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }

        lastScroll = currentScroll;
    });
}

// Mobile navigation toggle
if (navToggle && navMenu) {
    navToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');

        // Animate hamburger icon
        const spans = navToggle.querySelectorAll('span');
        if (spans.length >= 3) {
            if (navMenu.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translateY(7px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translateY(-7px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        }
    });
}

// Close mobile menu when clicking on a link
const navLinks = document.querySelectorAll('.nav-link, .nav-cta, .dropdown-link');
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        // For mobile dropdown toggle
        if (window.innerWidth <= 968 && link.classList.contains('nav-link')) {
            const parent = link.closest('.has-dropdown');
            if (parent) {
                e.preventDefault();
                parent.classList.toggle('active');
                return;
            }
        }

        // Close mobile menu
        if (navMenu) navMenu.classList.remove('active');
        if (navToggle) {
            const spans = navToggle.querySelectorAll('span');
            if (spans.length >= 3) {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        }
    });
});

// Desktop dropdown hover functionality
const dropdownItems = document.querySelectorAll('.has-dropdown');
dropdownItems.forEach(item => {
    let timeoutId;

    item.addEventListener('mouseenter', () => {
        clearTimeout(timeoutId);
        if (window.innerWidth > 968) {
            item.classList.add('active');
        }
    });

    item.addEventListener('mouseleave', () => {
        if (window.innerWidth > 968) {
            timeoutId = setTimeout(() => {
                item.classList.remove('active');
            }, 300);
        }
    });
});

// ===================================
// INTERSECTION OBSERVER FOR ANIMATIONS
// ===================================

const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animationPlayState = 'running';
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe animated elements
const animatedElements = document.querySelectorAll(`
    .feature-card,
    .application-card,
    .testimonial-card,
    .trust-logos,
    .value-text,
    .stat-item,
    .product-card,
    .news-card
`);

animatedElements.forEach(el => {
    el.style.animationPlayState = 'paused';
    observer.observe(el);
});

// ===================================
// SMOOTH SCROLL FOR ANCHOR LINKS
// ===================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');

        // Don't prevent default for empty hash
        if (href === '#') return;

        e.preventDefault();

        const target = document.querySelector(href);
        if (target) {
            const navHeight = nav.offsetHeight;
            const targetPosition = target.offsetTop - navHeight;

            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    });
});

// ===================================
// FORM SUBMISSION HANDLER
// ===================================

const contactForm = document.getElementById('contactForm');

if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();

        // Get form data
        const formData = new FormData(contactForm);
        const data = Object.fromEntries(formData);

        // Log form data (replace with actual submission logic)
        console.log('Form submitted:', data);

        // Show success message
        const submitButton = contactForm.querySelector('button[type="submit"]');
        if (submitButton) {
            const originalText = submitButton.innerHTML;

            submitButton.innerHTML = `
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M16.667 5L7.5 14.167L3.333 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Request Sent
            `;
            submitButton.disabled = true;
            submitButton.style.background = '#28a745';

            // Reset form
            setTimeout(() => {
                contactForm.reset();
                submitButton.innerHTML = originalText;
                submitButton.disabled = false;
                submitButton.style.background = '';
            }, 3000);
        }
    });
}

// ===================================
// PARALLAX EFFECT FOR HERO BACKGROUND
// ===================================

const heroBackground = document.querySelector('.hero-background');

window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const parallaxSpeed = 0.5;

    if (heroBackground && scrolled < window.innerHeight) {
        heroBackground.style.transform = `translateY(${scrolled * parallaxSpeed}px)`;
    }
});

// ===================================
// NUMBER COUNTER ANIMATION
// ===================================

function animateCounter(element, target, duration) {
    const start = 0;
    const increment = target / (duration / 16); // 60fps
    let current = start;

    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            // Format numbers with appropriate suffixes
            if (target >= 1000000) {
                element.textContent = (current / 1000000).toFixed(1) + 'M+';
            } else if (target >= 1000) {
                element.textContent = Math.floor(current / 1000) + 'K+';
            } else {
                element.textContent = current.toFixed(1) + '%';
            }
        }
    }, 16);
}

// Trigger counter animation when stats section is in view
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const statNumbers = entry.target.querySelectorAll('.stat-number');

            statNumbers.forEach((stat, index) => {
                // Read the actual value from the rendered HTML
                const originalText = stat.textContent.trim();
                stat.textContent = '0';

                // Animate back to the original text
                setTimeout(() => {
                    stat.textContent = originalText;
                }, index * 100);
            });

            statsObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.5 });

const heroStats = document.querySelector('.hero-stats');
if (heroStats) {
    statsObserver.observe(heroStats);
}

// ===================================
// CURSOR INTERACTION FOR CARDS
// ===================================

const cards = document.querySelectorAll('.feature-card, .application-card, .testimonial-card');

cards.forEach(card => {
    card.addEventListener('mouseenter', function () {
        this.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
    });

    card.addEventListener('mousemove', function (e) {
        const rect = this.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = (y - centerY) / 20;
        const rotateY = (centerX - x) / 20;

        this.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-8px)`;
    });

    card.addEventListener('mouseleave', function () {
        this.style.transform = '';
    });
});

// ===================================
// SHOWCASE CAROUSEL FUNCTIONALITY
// ===================================

const showcaseTrack = document.getElementById('showcaseTrack');
const showcasePrevBtn = document.getElementById('showcasePrev');
const showcaseNextBtn = document.getElementById('showcaseNext');
const showcaseIndicatorsContainer = document.getElementById('showcaseIndicators');

if (showcaseTrack) {
    const showcaseItems = showcaseTrack.querySelectorAll('.carousel-item');
    const totalShowcaseItems = showcaseItems.length;
    let currentShowcaseIndex = 0;
    let itemsPerView = 3;

    // Calculate items per view based on screen size
    function updateItemsPerView() {
        if (window.innerWidth <= 640) {
            itemsPerView = 1;
        } else if (window.innerWidth <= 968) {
            itemsPerView = 2;
        } else {
            itemsPerView = 3;
        }
    }

    // Create indicators
    function createShowcaseIndicators() {
        showcaseIndicatorsContainer.innerHTML = '';
        const totalPages = Math.ceil(totalShowcaseItems / itemsPerView);

        for (let i = 0; i < totalPages; i++) {
            const indicator = document.createElement('button');
            indicator.classList.add('carousel-indicator');
            indicator.setAttribute('aria-label', `Go to slide group ${i + 1}`);
            indicator.addEventListener('click', () => goToShowcaseSlide(i));
            showcaseIndicatorsContainer.appendChild(indicator);
        }

        updateShowcaseIndicators();
    }

    function updateShowcaseIndicators() {
        const indicators = showcaseIndicatorsContainer.querySelectorAll('.carousel-indicator');
        const currentPage = Math.floor(currentShowcaseIndex / itemsPerView);

        indicators.forEach((indicator, index) => {
            indicator.classList.toggle('active', index === currentPage);
        });
    }

    function updateShowcaseCarousel() {
        const itemWidth = showcaseItems[0].offsetWidth;
        const gap = 32; // 2rem in pixels
        const offset = currentShowcaseIndex * (itemWidth + gap);

        showcaseTrack.style.transform = `translateX(-${offset}px)`;

        // Update button states
        showcasePrevBtn.disabled = currentShowcaseIndex === 0;
        showcaseNextBtn.disabled = currentShowcaseIndex >= totalShowcaseItems - itemsPerView;

        updateShowcaseIndicators();
    }

    function goToShowcaseSlide(pageIndex) {
        currentShowcaseIndex = pageIndex * itemsPerView;
        updateShowcaseCarousel();
    }

    function nextShowcaseSlide() {
        if (currentShowcaseIndex < totalShowcaseItems - itemsPerView) {
            currentShowcaseIndex += itemsPerView;
            updateShowcaseCarousel();
        }
    }

    function prevShowcaseSlide() {
        if (currentShowcaseIndex > 0) {
            currentShowcaseIndex -= itemsPerView;
            if (currentShowcaseIndex < 0) currentShowcaseIndex = 0;
            updateShowcaseCarousel();
        }
    }

    showcasePrevBtn.addEventListener('click', prevShowcaseSlide);
    showcaseNextBtn.addEventListener('click', nextShowcaseSlide);

    // Touch/swipe support
    let showcaseTouchStartX = 0;
    let showcaseTouchEndX = 0;

    showcaseTrack.addEventListener('touchstart', (e) => {
        showcaseTouchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    showcaseTrack.addEventListener('touchend', (e) => {
        showcaseTouchEndX = e.changedTouches[0].screenX;
        handleShowcaseSwipe();
    }, { passive: true });

    function handleShowcaseSwipe() {
        const swipeThreshold = 50;
        const diff = showcaseTouchStartX - showcaseTouchEndX;

        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                nextShowcaseSlide();
            } else {
                prevShowcaseSlide();
            }
        }
    }

    // Initialize
    updateItemsPerView();
    createShowcaseIndicators();
    updateShowcaseCarousel();

    // Update on window resize
    let showcaseResizeTimer;
    window.addEventListener('resize', () => {
        clearTimeout(showcaseResizeTimer);
        showcaseResizeTimer = setTimeout(() => {
            const oldItemsPerView = itemsPerView;
            updateItemsPerView();

            if (oldItemsPerView !== itemsPerView) {
                currentShowcaseIndex = 0;
                createShowcaseIndicators();
                updateShowcaseCarousel();
            }
        }, 250);
    });

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        const showcaseSection = document.querySelector('.showcase-carousel');
        if (!showcaseSection) return;

        const rect = showcaseSection.getBoundingClientRect();
        const isInView = rect.top < window.innerHeight && rect.bottom >= 0;

        if (isInView) {
            if (e.key === 'ArrowLeft') {
                prevShowcaseSlide();
            } else if (e.key === 'ArrowRight') {
                nextShowcaseSlide();
            }
        }
    });
}

// ===================================
// INITIALIZE ON PAGE LOAD
// ===================================

window.addEventListener('load', () => {
    // Remove any preload classes
    document.body.classList.add('loaded');

    // Start animations that should play on load
    const heroContent = document.querySelector('.hero-content');
    const heroVisual = document.querySelector('.hero-visual');

    if (heroContent) heroContent.style.animationPlayState = 'running';
    if (heroVisual) heroVisual.style.animationPlayState = 'running';
});

// ===================================
// PERFORMANCE OPTIMIZATION
// ===================================

// Debounce function for scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply debounce to scroll-heavy operations
const debouncedParallax = debounce(() => {
    const scrolled = window.pageYOffset;
    const parallaxSpeed = 0.5;

    if (scrolled < window.innerHeight && heroBackground) {
        requestAnimationFrame(() => {
            heroBackground.style.transform = `translateY(${scrolled * parallaxSpeed}px)`;
        });
    }
}, 10);

window.addEventListener('scroll', debouncedParallax);

// ===================================
// ACCESSIBILITY ENHANCEMENTS
// ===================================

// Add focus visible styles for keyboard navigation
document.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
        document.body.classList.add('keyboard-navigation');
    }
});

document.addEventListener('mousedown', () => {
    document.body.classList.remove('keyboard-navigation');
});

// Announce dynamic content changes to screen readers
function announceToScreenReader(message) {
    const announcement = document.createElement('div');
    announcement.setAttribute('role', 'status');
    announcement.setAttribute('aria-live', 'polite');
    announcement.classList.add('sr-only');
    announcement.textContent = message;
    document.body.appendChild(announcement);

    setTimeout(() => {
        document.body.removeChild(announcement);
    }, 1000);
}

// Add screen reader only class to CSS
const style = document.createElement('style');
style.textContent = `
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border-width: 0;
    }
    
    body.keyboard-navigation *:focus {
        outline: 3px solid #1D4E89;
        outline-offset: 2px;
    }
`;
document.head.appendChild(style);

// ===================================
// FLOATING WIDGET FUNCTIONALITY
// ===================================

const scrollTopBtn = document.getElementById('scrollTopBtn');
const emailBtn = document.getElementById('emailBtn');
const whatsappBtn = document.getElementById('whatsappBtn');
const emailPopup = document.getElementById('emailPopup');
const whatsappPopup = document.getElementById('whatsappPopup');
const closePopupBtns = document.querySelectorAll('.close-popup');

// Scroll to Top Functionality
if (scrollTopBtn) {
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            scrollTopBtn.classList.add('visible');
        } else {
            scrollTopBtn.classList.remove('visible');
        }
    });

    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Popup Toggle Functionality
function togglePopup(popup, btn) {
    // Close other popups first
    document.querySelectorAll('.widget-popup').forEach(p => {
        if (p !== popup) p.classList.remove('active');
    });

    popup.classList.toggle('active');
}

if (emailBtn && emailPopup) {
    emailBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        togglePopup(emailPopup, emailBtn);
    });
}

if (whatsappBtn && whatsappPopup) {
    whatsappBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        togglePopup(whatsappPopup, whatsappBtn);
    });
}

// Close Popups
closePopupBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const popup = btn.closest('.widget-popup');
        if (popup) popup.classList.remove('active');
    });
});

// Close when clicking outside
document.addEventListener('click', (e) => {
    if (!e.target.closest('.widget-item')) {
        document.querySelectorAll('.widget-popup').forEach(popup => {
            popup.classList.remove('active');
        });
    }
});
