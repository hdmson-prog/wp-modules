// Gallery Data - fetched from PHP (gallery.php)
const galleryData = window.wpGalleryData || [];

// Pagination settings
const itemsPerPage = 12;
let currentPage = 1;
let currentCategory = 'all';
let filteredData = [...galleryData];

// Initialize gallery
function initGallery() {
    renderGallery();
    renderPagination();
    setupFilterButtons();
    setupLightbox();
}

// Filter gallery
function filterGallery(category) {
    currentCategory = category;
    currentPage = 1;

    if (category === 'all') {
        filteredData = [...galleryData];
    } else {
        filteredData = galleryData.filter(item => item.category === category);
    }

    renderGallery();
    renderPagination();
}

// Render gallery items
function renderGallery() {
    const galleryGrid = document.getElementById('galleryGrid');
    const loadingDiv = document.getElementById('gallery-loading');

    if (loadingDiv) loadingDiv.style.display = 'none';

    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageItems = filteredData.slice(startIndex, endIndex);

    galleryGrid.innerHTML = '';

    if (pageItems.length === 0) {
        galleryGrid.innerHTML = '<div style="text-align: center; padding: 50px; width: 100%;"><p>No images found in this category.</p></div>';
        return;
    }

    pageItems.forEach((item, index) => {
        const galleryItem = document.createElement('div');
        galleryItem.className = 'gallery-item';
        galleryItem.style.animationDelay = `${index * 0.05}s`;
        galleryItem.setAttribute('data-index', startIndex + index);

        galleryItem.innerHTML = `
            <div class="gallery-item-image">
                <img src="${item.url}" alt="${item.title}" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
            <div class="gallery-item-overlay">
                <div class="gallery-item-title">${item.title}</div>
                <div class="gallery-item-category">${item.category}</div>
            </div>
        `;

        galleryItem.addEventListener('click', () => openLightbox(startIndex + index));
        galleryGrid.appendChild(galleryItem);
    });
}

// ... (renderPagination, setupFilterButtons remains similar but I'll update it to ensure it works with the new data)

// Render pagination
function renderPagination() {
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    const paginationNumbers = document.getElementById('paginationNumbers');
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');

    if (totalPages <= 1) {
        if (paginationNumbers.parentElement) paginationNumbers.parentElement.style.display = 'none';
        return;
    } else {
        if (paginationNumbers.parentElement) paginationNumbers.parentElement.style.display = 'flex';
    }

    // Update button states
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;

    // Render page numbers
    paginationNumbers.innerHTML = '';

    for (let i = 1; i <= totalPages; i++) {
        if (
            i === 1 ||
            i === totalPages ||
            (i >= currentPage - 1 && i <= currentPage + 1)
        ) {
            const pageBtn = document.createElement('button');
            pageBtn.className = 'pagination-number';
            pageBtn.textContent = i;
            if (i === currentPage) pageBtn.classList.add('active');

            pageBtn.addEventListener('click', () => {
                currentPage = i;
                renderGallery();
                renderPagination();
                const gridTop = document.getElementById('galleryGrid').getBoundingClientRect().top + window.pageYOffset - 100;
                window.scrollTo({ top: gridTop, behavior: 'smooth' });
            });

            paginationNumbers.appendChild(pageBtn);
        } else if (
            i === currentPage - 2 ||
            i === currentPage + 2
        ) {
            const dots = document.createElement('span');
            dots.textContent = '...';
            dots.style.padding = '0 0.5rem';
            dots.style.color = 'var(--color-text-light)';
            paginationNumbers.appendChild(dots);
        }
    }

    // Setup navigation
    prevBtn.onclick = () => {
        if (currentPage > 1) {
            currentPage--;
            renderGallery();
            renderPagination();
            const gridTop = document.getElementById('galleryGrid').getBoundingClientRect().top + window.pageYOffset - 100;
            window.scrollTo({ top: gridTop, behavior: 'smooth' });
        }
    };

    nextBtn.onclick = () => {
        if (currentPage < totalPages) {
            currentPage++;
            renderGallery();
            renderPagination();
            const gridTop = document.getElementById('galleryGrid').getBoundingClientRect().top + window.pageYOffset - 100;
            window.scrollTo({ top: gridTop, behavior: 'smooth' });
        }
    };
}

// Setup filter buttons
function setupFilterButtons() {
    const filterBtns = document.querySelectorAll('.filter-btn');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterGallery(btn.getAttribute('data-category'));
        });
    });
}

// Lightbox functionality
let currentLightboxIndex = 0;

function setupLightbox() {
    const lightbox = document.getElementById('lightbox');
    const lightboxClose = document.getElementById('lightboxClose');
    const lightboxPrev = document.getElementById('lightboxPrev');
    const lightboxNext = document.getElementById('lightboxNext');
    if (!lightbox) return;

    lightboxClose.addEventListener('click', closeLightbox);
    lightboxPrev.addEventListener('click', () => navigateLightbox(-1));
    lightboxNext.addEventListener('click', () => navigateLightbox(1));

    // Close on overlay click
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox) {
            closeLightbox();
        }
    });

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (!lightbox.classList.contains('active')) return;

        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') navigateLightbox(-1);
        if (e.key === 'ArrowRight') navigateLightbox(1);
    });
}

function openLightbox(index) {
    currentLightboxIndex = index;
    const lightbox = document.getElementById('lightbox');
    const item = filteredData[index];
    if (!lightbox || !item) return;

    document.getElementById('lightboxTitle').textContent = item.title;
    document.getElementById('lightboxDescription').textContent = item.description;
    document.getElementById('lightboxCounter').textContent = `${index + 1} / ${filteredData.length}`;

    const lightboxImage = document.getElementById('lightboxImage');
    lightboxImage.src = item.full_url || item.url;
    lightboxImage.alt = item.title;

    lightbox.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    if (!lightbox) return;
    lightbox.classList.remove('active');
    document.body.style.overflow = '';
}

function navigateLightbox(direction) {
    currentLightboxIndex += direction;

    if (currentLightboxIndex < 0) {
        currentLightboxIndex = filteredData.length - 1;
    } else if (currentLightboxIndex >= filteredData.length) {
        currentLightboxIndex = 0;
    }

    openLightbox(currentLightboxIndex);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', initGallery);

