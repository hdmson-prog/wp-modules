<div class="news-card">
    <div class="news-image">
        <div class="news-image-placeholder"
            style="background: linear-gradient(135deg, #333333 0%, #555555 100%);">
           <a href="<?php the_permalink(  ); ?>"><?php the_post_thumbnail(); ?></a> 
        </div>
        <span class="news-badge"><?php esc_html_e('Press Release', 'tqb'); ?></span>
    </div>
    <div class="news-content">
        <div class="news-meta">
            <span class="news-category"><?php echo get_the_category_list(); ?></span>
            <span class="news-date"><?php echo esc_html(get_the_time(get_option('date_format'))); ?></span>
        </div>
        <h3 class="news-title"><a href="<?php the_permalink(  ); ?>"><?php the_title(); ?></a></h3>
        <p class="news-excerpt">
            <?php echo mb_strimwidth(strip_tags(get_the_content()), 0, 100) ?>
        </p>
        <a href="<?php the_permalink(); ?>" class="news-link"><?php esc_html_e('Read More', 'tqb'); ?> &rarr;</a>
    </div>
</div>