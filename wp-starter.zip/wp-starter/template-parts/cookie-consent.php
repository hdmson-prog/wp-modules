<?php
/**
 * Cookie Consent Banner Template
 *
 * Displays a GDPR/CCPA compliant cookie consent banner.
 * Users can accept all cookies, reject non-essential ones, or manage preferences.
 *
 * @package WP_Starter
 */
?>

<!-- Cookie Consent Banner -->
<div id="cookieConsent" class="cookie-consent" role="dialog" aria-label="<?php esc_attr_e('Cookie consent', 'tqb'); ?>" aria-describedby="cookieConsentDescription">
    <div class="cookie-consent__backdrop"></div>
    <div class="cookie-consent__banner">
        <div class="cookie-consent__content">
            <div class="cookie-consent__icon">
                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="16" cy="16" r="14" stroke="currentColor" stroke-width="2"/>
                    <circle cx="12" cy="10" r="2" fill="currentColor"/>
                    <circle cx="20" cy="14" r="1.5" fill="currentColor"/>
                    <circle cx="10" cy="18" r="1.5" fill="currentColor"/>
                    <circle cx="18" cy="22" r="2" fill="currentColor"/>
                    <circle cx="22" cy="8" r="1" fill="currentColor"/>
                    <circle cx="14" cy="24" r="1" fill="currentColor"/>
                </svg>
            </div>
            <div class="cookie-consent__text">
                <h3 class="cookie-consent__title"><?php esc_html_e('We value your privacy', 'tqb'); ?></h3>
                <p id="cookieConsentDescription" class="cookie-consent__description">
                    <?php esc_html_e('We use cookies to enhance your browsing experience, serve personalized content, and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.', 'tqb'); ?>
                    <?php
$privacy_page_id = get_option('wp_page_for_privacy_policy');
if ($privacy_page_id):
    $privacy_url = get_permalink($privacy_page_id);
?>
                        <a href="<?php echo esc_url($privacy_url); ?>" class="cookie-consent__link"><?php esc_html_e('Privacy Policy', 'tqb'); ?></a>
                    <?php
endif; ?>
                </p>
            </div>
        </div>

        <!-- Preferences Panel (hidden by default) -->
        <div id="cookiePreferences" class="cookie-consent__preferences" style="display: none;">
            <div class="cookie-preference__item">
                <div class="cookie-preference__info">
                    <span class="cookie-preference__name"><?php esc_html_e('Essential Cookies', 'tqb'); ?></span>
                    <span class="cookie-preference__desc"><?php esc_html_e('Required for the website to function. Cannot be disabled.', 'tqb'); ?></span>
                </div>
                <label class="cookie-toggle cookie-toggle--disabled">
                    <input type="checkbox" checked disabled>
                    <span class="cookie-toggle__slider"></span>
                </label>
            </div>
            <div class="cookie-preference__item">
                <div class="cookie-preference__info">
                    <span class="cookie-preference__name"><?php esc_html_e('Analytics Cookies', 'tqb'); ?></span>
                    <span class="cookie-preference__desc"><?php esc_html_e('Help us understand how visitors interact with our website.', 'tqb'); ?></span>
                </div>
                <label class="cookie-toggle">
                    <input type="checkbox" id="cookieAnalytics" checked>
                    <span class="cookie-toggle__slider"></span>
                </label>
            </div>
            <div class="cookie-preference__item">
                <div class="cookie-preference__info">
                    <span class="cookie-preference__name"><?php esc_html_e('Marketing Cookies', 'tqb'); ?></span>
                    <span class="cookie-preference__desc"><?php esc_html_e('Used to deliver relevant advertisements and track campaign performance.', 'tqb'); ?></span>
                </div>
                <label class="cookie-toggle">
                    <input type="checkbox" id="cookieMarketing">
                    <span class="cookie-toggle__slider"></span>
                </label>
            </div>
        </div>

        <div class="cookie-consent__actions">
            <button id="cookieManage" class="cookie-btn cookie-btn--manage" type="button">
                <?php esc_html_e('Manage Preferences', 'tqb'); ?>
            </button>
            <button id="cookieReject" class="cookie-btn cookie-btn--reject" type="button">
                <?php esc_html_e('Reject All', 'tqb'); ?>
            </button>
            <button id="cookieAccept" class="cookie-btn cookie-btn--accept" type="button">
                <?php esc_html_e('Accept All', 'tqb'); ?>
            </button>
        </div>
    </div>
</div>
