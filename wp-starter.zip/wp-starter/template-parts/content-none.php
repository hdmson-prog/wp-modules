<?php
/**
 * Template part for displaying no content.
 *
 * @package WP_Starter
 */
?>

<section class="no-results not-found">
	<header class="page-header">
		<h1 class="page-title"><?php esc_html_e('Nothing Found', 'tqb'); ?></h1>
	</header>

	<div class="page-content">
		<?php if (is_home() && current_user_can('publish_posts')): ?>
			<p>
				<?php
	printf(
		wp_kses(
		/* translators: 1: link to create new post. */
		__('Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'tqb'),
		array('a' => array('href' => array()))
	),
		esc_url(admin_url('post-new.php'))
	);
?>
			</p>
		<?php
elseif (is_search()): ?>
			<p><?php esc_html_e('Sorry, but nothing matched your search terms. Please try again with different keywords.', 'tqb'); ?></p>
			<?php get_search_form(); ?>
		<?php
else: ?>
			<p><?php esc_html_e('It seems we can not find what you are looking for. Perhaps searching can help.', 'tqb'); ?></p>
			<?php get_search_form(); ?>
		<?php
endif; ?>
	</div>
</section>

