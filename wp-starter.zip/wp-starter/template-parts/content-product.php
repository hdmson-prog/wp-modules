<div class="product-card">
    <div class="product-image">
        <!-- <div class="product-badge">Best Seller</div> -->
        <div class="product-image-placeholder">
            <?php the_post_thumbnail('medium'); ?>
        </div>
    </div>
    <div class="product-info">
        <h3 class="product-name"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <p class="product-code"><?php esc_html_e('Model:', 'tqb'); ?> <?php echo esc_html(ws_get_post_meta(get_the_ID(), 'partnumber', true)); ?></p>
        <p class="product-description"><?php echo esc_html(mb_strimwidth(strip_tags(get_the_content()), 0, 100)); ?></p>

        <div class="product-specs">
            <?php
$tags = get_the_tags();
if ($tags) {
    foreach ($tags as $tag) {
?>
                    <span class="spec-tag"><a href="<?php echo esc_url(get_tag_link($tag->term_id)); ?>"><?php echo esc_html($tag->name); ?></a></span>
                    <?php
    }
}
?>
        </div>
        <a href="<?php the_permalink(); ?>" class="product-link"><?php esc_html_e('View Details', 'tqb'); ?> &rarr;</a>
    </div>
</div>
