<?php
/**
 * The template for displaying 404 pages.
 *
 * @package WP_Starter
 */

get_header();
tqb_page_banner();
?>

<section class="error-section">
    <div class="container">
        <div class="error-content">
            <div class="error-number">
                <span class="digit digit-4">4</span>
                <span class="digit digit-0">
                    <div class="sad-face">
                        <div class="eyes">
                            <div class="eye left"></div>
                            <div class="eye right"></div>
                        </div>
                        <div class="mouth"></div>
                    </div>
                </span>
                <span class="digit digit-4">4</span>
            </div>

            <div class="error-message">
                <h1><?php esc_html_e('Oops! Page Not Found', 'tqb'); ?></h1>
                <p class="error-description">
                    <?php esc_html_e('The page you\'re looking for seems to have taken a detour. It might have been moved, deleted, or perhaps it never existed.', 'tqb'); ?>
                </p>
            </div>

            <div class="error-search">
                <h3><?php esc_html_e('Try searching for what you need:', 'tqb'); ?></h3>
                <form class="search-form" id="errorSearchForm">
                    <input
                        type="text"
                        class="search-input"
                        placeholder="<?php esc_attr_e('Search our website...', 'tqb'); ?>"
                        id="errorSearchInput"
                    >
                    <button type="submit" class="search-btn"><?php esc_html_e('Search', 'tqb'); ?></button>
                </form>
            </div>

            <div class="helpful-links">
                <h3><?php esc_html_e('Here are some helpful links instead:', 'tqb'); ?></h3>
                <div class="links-grid">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="link-card">
                        <div class="link-icon">H</div>
                        <div class="link-text">
                            <h4><?php esc_html_e('Home', 'tqb'); ?></h4>
                            <p><?php esc_html_e('Back to homepage', 'tqb'); ?></p>
                        </div>
                    </a>
                    <a href="<?php echo esc_url(home_url('/products')); ?>" class="link-card">
                        <div class="link-icon">P</div>
                        <div class="link-text">
                            <h4><?php esc_html_e('Products', 'tqb'); ?></h4>
                            <p><?php esc_html_e('Browse our catalog', 'tqb'); ?></p>
                        </div>
                    </a>
                    <a href="<?php echo esc_url(home_url('/about')); ?>" class="link-card">
                        <div class="link-icon">A</div>
                        <div class="link-text">
                            <h4><?php esc_html_e('About Us', 'tqb'); ?></h4>
                            <p><?php esc_html_e('Learn about our company', 'tqb'); ?></p>
                        </div>
                    </a>
                    <a href="<?php echo esc_url(home_url('/quality-control')); ?>" class="link-card">
                        <div class="link-icon">Q</div>
                        <div class="link-text">
                            <h4><?php esc_html_e('Quality Control', 'tqb'); ?></h4>
                            <p><?php esc_html_e('Our quality standards', 'tqb'); ?></p>
                        </div>
                    </a>
                    <a href="<?php echo esc_url(home_url('/news')); ?>" class="link-card">
                        <div class="link-icon">N</div>
                        <div class="link-text">
                            <h4><?php esc_html_e('News', 'tqb'); ?></h4>
                            <p><?php esc_html_e('Latest updates', 'tqb'); ?></p>
                        </div>
                    </a>
                    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="link-card">
                        <div class="link-icon">C</div>
                        <div class="link-text">
                            <h4><?php esc_html_e('Contact', 'tqb'); ?></h4>
                            <p><?php esc_html_e('Get in touch', 'tqb'); ?></p>
                        </div>
                    </a>
                </div>
            </div>

            <div class="error-actions">
                <button onclick="history.back()" class="btn btn-secondary"><?php esc_html_e('Go Back', 'tqb'); ?></button>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary"><?php esc_html_e('Go to Homepage', 'tqb'); ?></a>
            </div>
        </div>
    </div>
</section>

<section class="help-section">
    <div class="container">
        <div class="help-content">
            <div class="help-text">
                <h2><?php esc_html_e('Still can\'t find what you\'re looking for?', 'tqb'); ?></h2>
                <p><?php esc_html_e('Our team is here to help you. Contact us and we\'ll be happy to assist you in finding the information you need.', 'tqb'); ?></p>
            </div>
            <div class="help-action">
                <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-contact"><?php esc_html_e('Contact Support', 'tqb'); ?></a>
            </div>
        </div>
    </div>
</section>

<?php
get_footer();
