<?php


get_header();

tqb_page_banner();

?>


    <section class="news-list-section">
        <div class="container">
            <div class="news-list-grid" id="newsList">
                <?php
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args = array(
    'post_type' => 'post',
    'posts_per_page' => 6,
    'paged' => $paged,
    'cat' => get_queried_object_id(),
);

$news_query = new WP_Query($args);

if ($news_query->have_posts()):
    while ($news_query->have_posts()):
        $news_query->the_post();
        $categories = get_the_category();
        $category_name = !empty($categories) ? $categories[0]->name : __('Uncategorized', 'tqb');
?>
                        <article class="news-list-item">
                            <div class="news-list-image">
                                <?php if (has_post_thumbnail()): ?>
                                    <?php the_post_thumbnail('large', array('alt' => get_the_title())); ?>
                                <?php
        else: ?>
                                    <svg width="120" height="120" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect x="20" y="30" width="80" height="60" rx="4" stroke="#1D4E89" stroke-width="2"/>
                                        <path d="M30 40 L50 50 M70 40 L90 50" stroke="#1D4E89" stroke-width="2"/>
                                        <path d="M30 55 L90 55 M30 65 L80 65 M30 75 L85 75" stroke="#1D4E89" stroke-width="2"/>
                                    </svg>
                                <?php
        endif; ?>
                            </div>
                            <div class="news-list-content">
                                <div class="news-list-meta">
                                    <span class="news-list-category"><?php echo esc_html($category_name); ?></span>
                                    <span class="news-list-date"><?php echo get_the_date('F j, Y'); ?></span>
                                </div>
                                <h2 class="news-list-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                                <p class="news-list-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 25, '...'); ?></p>
                                <a href="<?php the_permalink(); ?>" class="news-list-link"><?php esc_html_e('Read Full Article →', 'tqb'); ?></a>
                            </div>
                        </article>
                <?php
    endwhile;
    wp_reset_postdata();
else:
?>
                    <div style="text-align: center; padding: 50px; width: 100%;">
                        <p><?php esc_html_e('No news found in this category.', 'tqb'); ?></p>
                    </div>
                <?php
endif; ?>
            </div>

            <!-- Pagination -->
            <div class="news-pagination">
                <?php
echo paginate_links(array(
    'total' => $news_query->max_num_pages,
    'current' => $paged,
    'prev_text' => '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.5 15L7.5 10L12.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg> ' . esc_html__('Previous', 'tqb'),
    'next_text' => esc_html__('Next', 'tqb') . ' <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>',
    'type' => 'plain',
    'before_page_number' => '<span class="pagination-number">',
    'after_page_number' => '</span>'
));
?>
            </div>
        </div>
    </section>

<?php get_footer(); ?>