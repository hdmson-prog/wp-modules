<form role="search" method="get" class="search-form" id="searchForm" action="<?php echo esc_url(home_url('/')); ?>">
    <input type="search" class="search-input" name="s" value="<?php echo get_search_query(); ?>"
        placeholder="<?php esc_attr_e('Search products, applications, or documentation...', 'tqb'); ?>" aria-label="<?php esc_attr_e('Search', 'tqb'); ?>">
    <button type="submit" class="search-submit">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="2" />
            <path d="M15 15L20 20" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
        </svg>
    </button>
</form>