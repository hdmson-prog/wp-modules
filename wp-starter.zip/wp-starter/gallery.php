<?php
/**
 * Template Name: Gallery
 */
get_header();
tqb_page_banner(); ?>

<section class="gallery-filter-section">
        <div class="container">
            <div class="gallery-filter">
                <button class="filter-btn active" data-category="all"><?php esc_html_e('All Images', 'tqb'); ?></button>
                <?php
$image_collections = new WP_Query(array(
    'post_type' => 'image_collection',
    'posts_per_page' => -1,
));

while ($image_collections->have_posts()) {
    $image_collections->the_post();
    $category = get_post_field('post_name');
?>
                    <button class="filter-btn" data-category="<?php echo $category; ?>"><?php echo get_the_title(); ?></button>
                    <?php
}
wp_reset_postdata();
?>
                
            </div>
        </div>
    </section>

    <section class="gallery-section">
        <div class="container">
            <div class="gallery-grid" id="galleryGrid">

                <?php
$image_collections = new WP_Query(array(
    'post_type' => 'image_collection',
    'posts_per_page' => -1,
));

$all_gallery_items = array();

if ($image_collections->have_posts()) {
    while ($image_collections->have_posts()) {
        $image_collections->the_post();
        $category = get_post_field('post_name');
        $gallery_images = ws_get_post_meta(get_the_ID(), '_gallery_images', true);

        if ($gallery_images && is_array($gallery_images)) {
            foreach ($gallery_images as $image_id) {
                $image_url = wp_get_attachment_image_url($image_id, 'large');
                $full_url = wp_get_attachment_url($image_id);
                $title = get_the_title($image_id);
                $caption = wp_get_attachment_caption($image_id);

                $all_gallery_items[] = array(
                    'id' => $image_id,
                    'category' => $category,
                    'title' => $title ? $title : get_the_title(), // Fallback to collection title
                    'description' => $caption ? $caption : '',
                    'url' => $image_url,
                    'full_url' => $full_url
                );
            }
        }
    }
    wp_reset_postdata();
}
?>

                <script>
                    // Pass the real gallery data to the JS file
                    window.wpGalleryData = <?php echo json_encode($all_gallery_items); ?>;
                </script>

                <!-- The gallery will be populated by assets/js/gallery.js using the data above -->
                <div id="gallery-loading" style="text-align: center; padding: 50px; width: 100%;">
                    <p><?php esc_html_e('Loading gallery...', 'tqb'); ?></p>
                </div>


    </div>

            <!-- Pagination -->
            <div class="gallery-pagination">
                <button class="pagination-btn" id="prevPage" disabled="">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12.5 15L7.5 10L12.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                    <?php esc_html_e('Previous', 'tqb'); ?>
                </button>
                <div class="pagination-numbers" id="paginationNumbers"><button class="pagination-number active">1</button><button class="pagination-number">2</button></div>
                <button class="pagination-btn" id="nextPage">
                    <?php esc_html_e('Next', 'tqb'); ?>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                </button>
            </div>
        </div>
    </section>

    <div class="lightbox" id="lightbox">
        <button class="lightbox-close" id="lightboxClose" aria-label="<?php esc_attr_e('Close lightbox', 'tqb'); ?>">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 8L8 24M8 8L24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
            </svg>
        </button>
        <button class="lightbox-nav lightbox-prev" id="lightboxPrev" aria-label="<?php esc_attr_e('Previous image', 'tqb'); ?>">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 26L10 16L20 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
        </button>
        <button class="lightbox-nav lightbox-next" id="lightboxNext" aria-label="<?php esc_attr_e('Next image', 'tqb'); ?>">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 26L22 16L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
        </button>
        <div class="lightbox-content">
            <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAwIiBoZWlnaHQ9IjYwMCIgdmlld0JveD0iMCAwIDgwMCA2MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjgwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IiNlOWVjZWYiLz48cmVjdCB4PSIyMDAiIHk9IjE1MCIgd2lkdGg9IjQwMCIgaGVpZ2h0PSIzMDAiIHJ4PSI4IiBzdHJva2U9IiMxRDRFODkiIHN0cm9rZS13aWR0aD0iNCIvPjxjaXJjbGUgY3g9IjMwMCIgY3k9IjI1MCIgcj0iNDAiIGZpbGw9IiMxRDRFODkiLz48cGF0aCBkPSJNMjAwIDQwMCBMMzAwIDMwMCBMNDAwIDQwMCBMNTAwIDMwMCBMNjAwIDQwMCIgc3Ryb2tlPSIjMUQ0RTg5IiBzdHJva2Utd2lkdGg9IjQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPjwvc3ZnPg==" alt="<?php esc_attr_e('Manufacturing Facility', 'tqb'); ?>" id="lightboxImage">
            <div class="lightbox-caption">
                <h3 id="lightboxTitle"><?php esc_html_e('Manufacturing Facility', 'tqb'); ?></h3>
                <p id="lightboxDescription"><?php esc_html_e('State-of-the-art 50,000 sq ft manufacturing facility', 'tqb'); ?></p>
            </div>
        </div>
        <div class="lightbox-counter" id="lightboxCounter">1 / 24</div>
    </div>



<?php get_footer();