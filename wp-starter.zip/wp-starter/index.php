<?php
/**
 * The main template file.
 *
 * @package WP_Starter
 */

get_header();

?>

<!-- Hero Slider -->111
    <section class="hero-slider" id="heroSlider">
        <div class="slider-track">
            <a href="#contact" class="slide active">
                <div class="slide-background"
                    style="background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9IiMxRDRFODkiLz48L3N2Zz4=');">
                </div>
            </a>
            <a href="#trust" class="slide">
                <div class="slide-background"
                    style="background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9IiMzMzMzMzMiLz48L3N2Zz4=');">
                </div>
            </a>
            <a href="#contact" class="slide">
                <div class="slide-background"
                    style="background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9IiMyYTVmOWUiLz48L3N2Zz4=');">
                </div>
            </a>
        </div>
        <div class="slider-controls">
            <button class="slider-arrow slider-arrow-prev" aria-label="Previous slide">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
            </button>
            <button class="slider-arrow slider-arrow-next" aria-label="Next slide">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
            </button>
        </div>
        <div class="slider-dots">
            <button class="slider-dot active" data-slide="0" aria-label="Go to slide 1"></button>
            <button class="slider-dot" data-slide="1" aria-label="Go to slide 2"></button>
            <button class="slider-dot" data-slide="2" aria-label="Go to slide 3"></button>
        </div>
    </section>


    <!-- Navigation -->
    <nav class="nav" id="mainNav">
        <div class="container nav-container">
            <div class="nav-logo">
                <span class="logo-text">PRECISION<strong>HUB</strong></span>
            </div>
            <ul class="nav-menu" id="navMenu">
                <li class="nav-item has-dropdown">
                    <a href="#products" class="nav-link">
                        Products
                        <svg class="dropdown-icon" width="12" height="12" viewBox="0 0 12 12" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="#products" class="dropdown-link">All Products</a></li>
                        <li><a href="#products" class="dropdown-link">Gen3 Compact Hub</a></li>
                        <li><a href="#products" class="dropdown-link">Heavy Duty Series</a></li>
                        <li><a href="#products" class="dropdown-link">EV-Optimized E-Drive</a></li>
                        <li><a href="#products" class="dropdown-link">Custom Solutions</a></li>
                    </ul>
                </li>
                <li class="nav-item has-dropdown">
                    <a href="#features" class="nav-link">
                        Technology
                        <svg class="dropdown-icon" width="12" height="12" viewBox="0 0 12 12" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="#features" class="dropdown-link">Engineering Excellence</a></li>
                        <li><a href="#features" class="dropdown-link">Precision Manufacturing</a></li>
                        <li><a href="#features" class="dropdown-link">Quality Control</a></li>
                        <li><a href="#features" class="dropdown-link">R&D Capabilities</a></li>
                    </ul>
                </li>
                <li class="nav-item has-dropdown">
                    <a href="#applications" class="nav-link">
                        Applications
                        <svg class="dropdown-icon" width="12" height="12" viewBox="0 0 12 12" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="#applications" class="dropdown-link">Passenger Vehicles</a></li>
                        <li><a href="#applications" class="dropdown-link">Commercial Vehicles</a></li>
                        <li><a href="#applications" class="dropdown-link">Off-Highway & Agriculture</a></li>
                        <li><a href="#applications" class="dropdown-link">Electric & Hybrid Vehicles</a></li>
                    </ul>
                </li>
                <li class="nav-item has-dropdown">
                    <a href="#" class="nav-link">
                        Company
                        <svg class="dropdown-icon" width="12" height="12" viewBox="0 0 12 12" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a href="#trust" class="dropdown-link">About Us</a></li>
                        <li><a href="#trust" class="dropdown-link">Certifications</a></li>
                        <li><a href="#" class="dropdown-link">Facilities</a></li>
                        <li><a href="#" class="dropdown-link">News & Events</a></li>
                        <li><a href="#" class="dropdown-link">Careers</a></li>
                    </ul>
                </li>
                <li class="nav-item"><a href="#contact" class="nav-link">Contact</a></li>
                <li class="nav-item"><a href="#contact" class="nav-cta">Request Quote</a></li>
            </ul>
            <button class="search-toggle" id="searchToggle" aria-label="Toggle search">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="8.5" cy="8.5" r="6" stroke="currentColor" stroke-width="2" />
                    <path d="M13 13L17 17" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                </svg>
            </button>
            <button class="nav-toggle" id="navToggle" aria-label="Toggle navigation">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </nav>

    <!-- Search Bar -->
    <div class="search-bar" id="searchBar">
        <div class="container search-container">
            <form class="search-form" id="searchForm">
                <input type="search" class="search-input"
                    placeholder="Search products, applications, or documentation..." aria-label="Search">
                <button type="submit" class="search-submit">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="2" />
                        <path d="M15 15L20 20" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                    </svg>
                </button>
            </form>
            <button class="search-close" id="searchClose" aria-label="Close search">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                </svg>
            </button>
        </div>
    </div>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-background"></div>
        <div class="container hero-container">
            <div class="hero-content">
                <h1 class="hero-title">
                    Precision-Engineered<br>
                    <span class="hero-title-accent">Wheel Hub Bearings</span>
                </h1>
                <p class="hero-subtitle">
                    Advanced manufacturing technology delivering uncompromising reliability for automotive and
                    industrial applications. Engineered to exceed ISO 9001:2015 standards.
                </p>
                <div class="hero-cta-group">
                    <a href="#contact" class="btn btn-primary">
                        Request Custom Quote
                        <svg class="btn-icon" width="20" height="20" viewBox="0 0 20 20" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </a>
                    <a href="#features" class="btn btn-secondary">
                        Explore Technology
                    </a>
                </div>
                <div class="hero-stats">
                    <div class="stat-item">
                        <div class="stat-number">25+</div>
                        <div class="stat-label">Years Engineering Excellence</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">50M+</div>
                        <div class="stat-label">Units Delivered Globally</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">99.8%</div>
                        <div class="stat-label">Quality Pass Rate</div>
                    </div>
                </div>
            </div>
            <div class="hero-visual">
                <?php
if (function_exists('ws_get_option')) {
    $profile_image = ws_get_option('company_profile_image');
    if ($profile_image): ?>
                        <img src="<?php echo esc_url($profile_image); ?>" alt="Company Profile" class="bearing-showcase">
                    <?php
    else: ?>
                        <div class="bearing-showcase-placeholder">
                            <div class="bearing-circle bearing-circle-1"></div>
                            <div class="bearing-circle bearing-circle-2"></div>
                            <div class="bearing-circle bearing-circle-3"></div>
                        </div>
                    <?php
    endif;
}
else { ?>
                    <div class="bearing-showcase-placeholder">
                        <div class="bearing-circle bearing-circle-1"></div>
                        <div class="bearing-circle bearing-circle-2"></div>
                        <div class="bearing-circle bearing-circle-3"></div>
                    </div>
                <?php
}?>
            </div>
        </div>
        <div class="scroll-indicator">
            <div class="scroll-line"></div>
        </div>
    </section>

    <!-- Trust Section -->
    <section class="trust" id="trust">
        <div class="container">
            <div class="trust-header">
                <p class="section-label">Trusted By Industry Leaders</p>
            </div>
            <div class="trust-logos">
                <div class="trust-logo-item">
                    <div class="trust-logo-placeholder">ISO 9001:2015</div>
                </div>
                <div class="trust-logo-item">
                    <div class="trust-logo-placeholder">ISO/TS 16949</div>
                </div>
                <div class="trust-logo-item">
                    <div class="trust-logo-placeholder">IATF 16949</div>
                </div>
                <div class="trust-logo-item">
                    <div class="trust-logo-placeholder">CE Certified</div>
                </div>
            </div>
            <div class="trust-testimonials">
                <div class="testimonial-card">
                    <div class="testimonial-quote">
                        "Exceptional bearing performance under extreme load conditions. The precision tolerances have
                        significantly reduced our warranty claims."
                    </div>
                    <div class="testimonial-author">
                        <div class="author-name">Michael Chen</div>
                        <div class="author-title">Chief Engineer, Commercial Vehicle Division</div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-quote">
                        "Their technical support and custom engineering capabilities set them apart. True manufacturing
                        partnership."
                    </div>
                    <div class="testimonial-author">
                        <div class="author-name">Sarah Williams</div>
                        <div class="author-title">Procurement Director, Automotive OEM</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Products Section -->
    <section class="featured-products" id="products">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Product Portfolio</p>
                <h2 class="section-title">Featured Wheel Hub Bearings</h2>
                <p class="section-description">
                    Precision-engineered bearing solutions for diverse applications. Each product designed for optimal
                    performance, durability, and reliability.
                </p>
            </div>
            <div class="products-grid">
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-badge">Best Seller</div>
                        <div class="product-image-placeholder">
                            <svg width="80" height="80" viewBox="0 0 80 80" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="8" fill="#1D4E89" />
                            </svg>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3 class="product-name">Gen3 Compact Hub Bearing</h3>
                        <p class="product-code">Model: WHB-C3-2550</p>
                        <p class="product-description">High-performance bearing for passenger vehicles. Optimized for
                            comfort and quiet operation.</p>
                        <div class="product-specs">
                            <span class="spec-tag">Ø25-50mm</span>
                            <span class="spec-tag">35kN Load</span>
                            <span class="spec-tag">150°C</span>
                        </div>
                        <a href="#contact" class="product-link">Request Quote →</a>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-image-placeholder">
                            <svg width="80" height="80" viewBox="0 0 80 80" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="3" />
                                <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="8" fill="#1D4E89" />
                            </svg>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3 class="product-name">Heavy Duty HD-Series</h3>
                        <p class="product-code">Model: WHB-HD-5080</p>
                        <p class="product-description">Industrial-grade bearing for commercial vehicles and heavy
                            machinery applications.</p>
                        <div class="product-specs">
                            <span class="spec-tag">Ø50-80mm</span>
                            <span class="spec-tag">65kN Load</span>
                            <span class="spec-tag">180°C</span>
                        </div>
                        <a href="#contact" class="product-link">Request Quote →</a>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-badge new">New</div>
                        <div class="product-image-placeholder">
                            <svg width="80" height="80" viewBox="0 0 80 80" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="3" />
                                <circle cx="40" cy="40" r="8" fill="#1D4E89" />
                                <path d="M40 10 L40 20 M40 60 L40 70 M10 40 L20 40 M60 40 L70 40" stroke="#1D4E89"
                                    stroke-width="2" />
                            </svg>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3 class="product-name">EV-Optimized E-Drive Hub</h3>
                        <p class="product-code">Model: WHB-EV-3060</p>
                        <p class="product-description">Next-generation bearing designed for electric vehicle e-axle
                            systems with reduced friction.</p>
                        <div class="product-specs">
                            <span class="spec-tag">Ø30-60mm</span>
                            <span class="spec-tag">40kN Load</span>
                            <span class="spec-tag">-40 to 160°C</span>
                        </div>
                        <a href="#contact" class="product-link">Request Quote →</a>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-image-placeholder">
                            <svg width="80" height="80" viewBox="0 0 80 80" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="15" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="8" fill="#1D4E89" />
                            </svg>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3 class="product-name">Precision Tapered Roller</h3>
                        <p class="product-code">Model: WHB-TR-3555</p>
                        <p class="product-description">Classic tapered roller design for combined radial and axial load
                            applications.</p>
                        <div class="product-specs">
                            <span class="spec-tag">Ø35-55mm</span>
                            <span class="spec-tag">45kN Load</span>
                            <span class="spec-tag">140°C</span>
                        </div>
                        <a href="#contact" class="product-link">Request Quote →</a>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-image-placeholder">
                            <svg width="80" height="80" viewBox="0 0 80 80" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="3" />
                                <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="3" />
                                <circle cx="40" cy="40" r="8" fill="#1D4E89" />
                                <rect x="35" y="8" width="10" height="12" fill="#1D4E89" />
                                <rect x="35" y="60" width="10" height="12" fill="#1D4E89" />
                            </svg>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3 class="product-name">Off-Road Sealed Bearing</h3>
                        <p class="product-code">Model: WHB-OR-4070</p>
                        <p class="product-description">Ruggedized bearing with enhanced sealing for agricultural and
                            construction equipment.</p>
                        <div class="product-specs">
                            <span class="spec-tag">Ø40-70mm</span>
                            <span class="spec-tag">55kN Load</span>
                            <span class="spec-tag">IP67</span>
                        </div>
                        <a href="#contact" class="product-link">Request Quote →</a>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-image-placeholder">
                            <svg width="80" height="80" viewBox="0 0 80 80" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="15" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="8" fill="#1D4E89" />
                                <line x1="40" y1="5" x2="40" y2="15" stroke="#1D4E89" stroke-width="2" />
                                <line x1="40" y1="65" x2="40" y2="75" stroke="#1D4E89" stroke-width="2" />
                            </svg>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3 class="product-name">Ultra-Precision Spindle</h3>
                        <p class="product-code">Model: WHB-UP-2040</p>
                        <p class="product-description">High-precision bearing for performance vehicles with sub-micron
                            tolerances.</p>
                        <div class="product-specs">
                            <span class="spec-tag">Ø20-40mm</span>
                            <span class="spec-tag">30kN Load</span>
                            <span class="spec-tag">±0.001mm</span>
                        </div>
                        <a href="#contact" class="product-link">Request Quote →</a>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-image-placeholder">
                            <svg width="80" height="80" viewBox="0 0 80 80" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="2" />
                                <circle cx="40" cy="40" r="8" fill="#1D4E89" />
                                <path d="M25 25 L55 55 M25 55 L55 25" stroke="#1D4E89" stroke-width="2" />
                            </svg>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3 class="product-name">High-Speed Performance</h3>
                        <p class="product-code">Model: WHB-HS-3050</p>
                        <p class="product-description">Engineered for high-speed applications with advanced cage design
                            and lubrication.</p>
                        <div class="product-specs">
                            <span class="spec-tag">Ø30-50mm</span>
                            <span class="spec-tag">38kN Load</span>
                            <span class="spec-tag">15,000 RPM</span>
                        </div>
                        <a href="#contact" class="product-link">Request Quote →</a>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-badge">Custom</div>
                        <div class="product-image-placeholder">
                            <svg width="80" height="80" viewBox="0 0 80 80" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="2"
                                    stroke-dasharray="5,5" />
                                <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="2"
                                    stroke-dasharray="5,5" />
                                <circle cx="40" cy="40" r="8" fill="#1D4E89" />
                                <text x="40" y="45" font-size="12" fill="#1D4E89" text-anchor="middle">?</text>
                            </svg>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3 class="product-name">Custom Engineered Solution</h3>
                        <p class="product-code">Model: WHB-CUSTOM</p>
                        <p class="product-description">Tailored bearing design to your exact specifications. Full
                            engineering support included.</p>
                        <div class="product-specs">
                            <span class="spec-tag">Custom Size</span>
                            <span class="spec-tag">Custom Load</span>
                            <span class="spec-tag">Custom Spec</span>
                        </div>
                        <a href="#contact" class="product-link">Request Quote →</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="features">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Engineering Excellence</p>
                <h2 class="section-title">Advanced Bearing Technology</h2>
                <p class="section-description">
                    Every component engineered with precision manufacturing processes and rigorous quality control to
                    deliver unmatched reliability in demanding applications.
                </p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="24" cy="24" r="20" stroke="currentColor" stroke-width="2" />
                            <circle cx="24" cy="24" r="12" stroke="currentColor" stroke-width="2" />
                            <circle cx="24" cy="24" r="4" fill="currentColor" />
                            <line x1="24" y1="4" x2="24" y2="12" stroke="currentColor" stroke-width="2" />
                            <line x1="24" y1="36" x2="24" y2="44" stroke="currentColor" stroke-width="2" />
                            <line x1="4" y1="24" x2="12" y2="24" stroke="currentColor" stroke-width="2" />
                            <line x1="36" y1="24" x2="44" y2="24" stroke="currentColor" stroke-width="2" />
                        </svg>
                    </div>
                    <h3 class="feature-title">Precision Tolerance Engineering</h3>
                    <p class="feature-description">
                        Sub-micron precision manufacturing with advanced CNC machining and grinding processes. Tolerance
                        levels to ±0.001mm ensure perfect fitment and optimal load distribution.
                    </p>
                    <ul class="feature-specs">
                        <li>Advanced metallurgy analysis</li>
                        <li>Heat treatment optimization</li>
                        <li>Surface finish Ra 0.2μm</li>
                    </ul>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 24L16 16L24 24L32 16L40 24" stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round" />
                            <path d="M8 32L16 24L24 32L32 24L40 32" stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round" />
                            <rect x="6" y="8" width="36" height="32" stroke="currentColor" stroke-width="2" rx="2" />
                        </svg>
                    </div>
                    <h3 class="feature-title">Extended Service Life</h3>
                    <p class="feature-description">
                        Engineered for 500,000+ km operational life through optimized raceway geometry, premium bearing
                        steel, and advanced sealing technology that prevents contamination.
                    </p>
                    <ul class="feature-specs">
                        <li>High-grade chromium steel (GCr15)</li>
                        <li>Multi-lip seal design</li>
                        <li>Fatigue testing to 10M cycles</li>
                    </ul>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="8" y="12" width="32" height="24" stroke="currentColor" stroke-width="2" rx="2" />
                            <path d="M16 12V8C16 6.89543 16.8954 6 18 6H30C31.1046 6 32 6.89543 32 8V12"
                                stroke="currentColor" stroke-width="2" />
                            <circle cx="24" cy="24" r="4" stroke="currentColor" stroke-width="2" />
                            <path d="M24 28V32" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                        </svg>
                    </div>
                    <h3 class="feature-title">Load Capacity Optimization</h3>
                    <p class="feature-description">
                        High static and dynamic load ratings through optimized internal geometry. Engineered to handle
                        radial, axial, and moment loads simultaneously in heavy-duty applications.
                    </p>
                    <ul class="feature-specs">
                        <li>FEA-validated load distribution</li>
                        <li>Dynamic load rating to 50kN</li>
                        <li>Thermal stability to 150°C</li>
                    </ul>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="24" cy="24" r="18" stroke="currentColor" stroke-width="2" />
                            <path d="M24 12V24L32 28" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                        </svg>
                    </div>
                    <h3 class="feature-title">Rapid Prototyping & Custom Engineering</h3>
                    <p class="feature-description">
                        In-house design capabilities with CAD/CAM integration. Develop custom bearing solutions tailored
                        to your exact specifications with rapid prototype delivery.
                    </p>
                    <ul class="feature-specs">
                        <li>3-week prototype delivery</li>
                        <li>Full technical documentation</li>
                        <li>Application-specific optimization</li>
                    </ul>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M24 8L32 16L24 24L16 16L24 8Z" stroke="currentColor" stroke-width="2"
                                stroke-linejoin="round" />
                            <path d="M24 24L32 32L24 40L16 32L24 24Z" stroke="currentColor" stroke-width="2"
                                stroke-linejoin="round" />
                            <path d="M8 24L16 16V32L8 24Z" stroke="currentColor" stroke-width="2"
                                stroke-linejoin="round" />
                            <path d="M40 24L32 16V32L40 24Z" stroke="currentColor" stroke-width="2"
                                stroke-linejoin="round" />
                        </svg>
                    </div>
                    <h3 class="feature-title">Comprehensive Quality Assurance</h3>
                    <p class="feature-description">
                        100% inspection protocol with automated CMM measurement, acoustic testing, and vibration
                        analysis. Full traceability from raw material to final assembly.
                    </p>
                    <ul class="feature-specs">
                        <li>Automated optical inspection</li>
                        <li>Statistical process control</li>
                        <li>Complete batch traceability</li>
                    </ul>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M24 4L8 12V24C8 34 16 42 24 44C32 42 40 34 40 24V12L24 4Z" stroke="currentColor"
                                stroke-width="2" stroke-linejoin="round" />
                            <path d="M18 24L22 28L30 20" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </div>
                    <h3 class="feature-title">Environmental Resistance</h3>
                    <p class="feature-description">
                        Advanced sealing and corrosion-resistant coatings for operation in harsh environments. Salt
                        spray testing and IP67 ingress protection as standard.
                    </p>
                    <ul class="feature-specs">
                        <li>1000h salt spray resistance</li>
                        <li>IP67 sealed configuration</li>
                        <li>Wide temperature range</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Choose Us Section -->
    <?php
$blocks = parse_blocks(get_the_content());
$wcu_rendered = false;
foreach ($blocks as $block) {
    if (isset($block['blockName']) && $block['blockName'] === 'custom/why-choose-us') {
        echo render_block($block);
        $wcu_rendered = true;
        break;
    }
}

if (!$wcu_rendered): ?>
    <section class="why-choose-us" id="why-choose-us">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Why Choose Us</p>
                <h2 class="section-title">Your Trusted Manufacturing Partner</h2>
                <p class="section-description">
                    Discover the advantages that set us apart in precision bearing manufacturing and engineering
                    excellence.
                </p>
            </div>

            <!-- Feature Item 1 - Text Left, Image Right -->
            <div class="choice-item">
                <div class="choice-content">
                    <div class="choice-number">01</div>
                    <h3 class="choice-title">Unmatched Quality Standards</h3>
                    <p class="choice-description">
                        Our commitment to quality goes beyond certifications. Every bearing undergoes rigorous testing
                        protocols including dimensional inspection, acoustic analysis, and performance validation. With
                        ISO 9001:2015 and IATF 16949 certifications, we maintain the highest industry standards while
                        continuously improving our processes through advanced statistical quality control methods.
                    </p>
                    <ul class="choice-highlights">
                        <li>100% automated inspection system</li>
                        <li>Real-time quality monitoring</li>
                        <li>Zero-defect manufacturing philosophy</li>
                        <li>Full traceability from raw material to delivery</li>
                    </ul>
                </div>
                <div class="choice-image">
                    <div class="choice-image-placeholder">
                        <svg width="100%" height="100%" viewBox="0 0 400 300" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect width="400" height="300" fill="url(#gradient1)" />
                            <circle cx="200" cy="150" r="80" stroke="#ffffff" stroke-width="3" opacity="0.3" />
                            <circle cx="200" cy="150" r="60" stroke="#ffffff" stroke-width="3" opacity="0.5" />
                            <circle cx="200" cy="150" r="40" stroke="#ffffff" stroke-width="3" opacity="0.7" />
                            <circle cx="200" cy="150" r="20" fill="#ffffff" opacity="0.9" />
                            <path d="M160 150 L190 180 L240 130" stroke="#1D4E89" stroke-width="6"
                                stroke-linecap="round" stroke-linejoin="round" />
                            <defs>
                                <linearGradient id="gradient1" x1="0" y1="0" x2="400" y2="300">
                                    <stop offset="0%" stop-color="#1D4E89" />
                                    <stop offset="100%" stop-color="#2a5f9e" />
                                </linearGradient>
                            </defs>
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Feature Item 2 - Image Left, Text Right -->
            <div class="choice-item choice-item-reverse">
                <div class="choice-image">
                    <div class="choice-image-placeholder">
                        <svg width="100%" height="100%" viewBox="0 0 400 300" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect width="400" height="300" fill="url(#gradient2)" />
                            <circle cx="200" cy="150" r="100" stroke="#ffffff" stroke-width="2" opacity="0.2" />
                            <circle cx="200" cy="150" r="80" stroke="#ffffff" stroke-width="2" opacity="0.3" />
                            <circle cx="200" cy="150" r="60" stroke="#ffffff" stroke-width="2" opacity="0.4" />
                            <circle cx="200" cy="150" r="40" stroke="#ffffff" stroke-width="2" opacity="0.5" />
                            <circle cx="200" cy="150" r="20" fill="#ffffff" opacity="0.8" />
                            <line x1="200" y1="50" x2="200" y2="90" stroke="#ffffff" stroke-width="3" opacity="0.7" />
                            <line x1="200" y1="210" x2="200" y2="250" stroke="#ffffff" stroke-width="3" opacity="0.7" />
                            <line x1="100" y1="150" x2="140" y2="150" stroke="#ffffff" stroke-width="3" opacity="0.7" />
                            <line x1="260" y1="150" x2="300" y2="150" stroke="#ffffff" stroke-width="3" opacity="0.7" />
                            <defs>
                                <linearGradient id="gradient2" x1="0" y1="0" x2="400" y2="300">
                                    <stop offset="0%" stop-color="#2a5f9e" />
                                    <stop offset="100%" stop-color="#1D4E89" />
                                </linearGradient>
                            </defs>
                        </svg>
                    </div>
                </div>
                <div class="choice-content">
                    <div class="choice-number">02</div>
                    <h3 class="choice-title">Advanced Engineering Capabilities</h3>
                    <p class="choice-description">
                        Our in-house engineering team combines decades of experience with cutting-edge technology. From
                        initial concept to final production, we provide comprehensive support including CAD design, FEA
                        simulation, and rapid prototyping. Our state-of-the-art facilities enable us to develop custom
                        solutions that perfectly match your application requirements.
                    </p>
                    <ul class="choice-highlights">
                        <li>Expert engineering team with 25+ years experience</li>
                        <li>Advanced CAD/CAM/FEA capabilities</li>
                        <li>Rapid prototyping in 3 weeks</li>
                        <li>Full technical documentation and support</li>
                    </ul>
                </div>
            </div>

            <!-- Feature Item 3 - Text Left, Image Right -->
            <div class="choice-item">
                <div class="choice-content">
                    <div class="choice-number">03</div>
                    <h3 class="choice-title">Global Supply Chain Reliability</h3>
                    <p class="choice-description">
                        Count on us for consistent, on-time delivery worldwide. Our strategic inventory management and
                        efficient logistics network ensure your production never stops. We maintain safety stock levels,
                        offer flexible delivery schedules, and provide real-time shipment tracking. With distribution
                        centers across major markets, we deliver where you need it, when you need it.
                    </p>
                    <ul class="choice-highlights">
                        <li>99.5% on-time delivery rate</li>
                        <li>Global distribution network</li>
                        <li>24/7 customer support</li>
                        <li>Emergency expedited shipping available</li>
                    </ul>
                </div>
                <div class="choice-image">
                    <div class="choice-image-placeholder">
                        <svg width="100%" height="100%" viewBox="0 0 400 300" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect width="400" height="300" fill="url(#gradient3)" />
                            <circle cx="100" cy="100" r="30" fill="#ffffff" opacity="0.3" />
                            <circle cx="300" cy="100" r="30" fill="#ffffff" opacity="0.3" />
                            <circle cx="200" cy="200" r="30" fill="#ffffff" opacity="0.3" />
                            <circle cx="100" cy="100" r="15" fill="#ffffff" opacity="0.6" />
                            <circle cx="300" cy="100" r="15" fill="#ffffff" opacity="0.6" />
                            <circle cx="200" cy="200" r="15" fill="#ffffff" opacity="0.6" />
                            <line x1="100" y1="100" x2="300" y2="100" stroke="#ffffff" stroke-width="2" opacity="0.5"
                                stroke-dasharray="5,5" />
                            <line x1="100" y1="100" x2="200" y2="200" stroke="#ffffff" stroke-width="2" opacity="0.5"
                                stroke-dasharray="5,5" />
                            <line x1="300" y1="100" x2="200" y2="200" stroke="#ffffff" stroke-width="2" opacity="0.5"
                                stroke-dasharray="5,5" />
                            <path d="M180 200 L200 180 L220 200" stroke="#ffffff" stroke-width="4"
                                stroke-linecap="round" stroke-linejoin="round" />
                            <defs>
                                <linearGradient id="gradient3" x1="0" y1="0" x2="400" y2="300">
                                    <stop offset="0%" stop-color="#1D4E89" />
                                    <stop offset="100%" stop-color="#2a5f9e" />
                                </linearGradient>
                            </defs>
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Feature Item 4 - Image Left, Text Right -->
            <div class="choice-item choice-item-reverse">
                <div class="choice-image">
                    <div class="choice-image-placeholder">
                        <svg width="100%" height="100%" viewBox="0 0 400 300" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect width="400" height="300" fill="url(#gradient4)" />
                            <rect x="100" y="80" width="200" height="140" rx="8" stroke="#ffffff" stroke-width="3"
                                opacity="0.4" />
                            <circle cx="200" cy="150" r="40" stroke="#ffffff" stroke-width="3" opacity="0.6" />
                            <path d="M200 130 L200 150 L215 165" stroke="#ffffff" stroke-width="4"
                                stroke-linecap="round" stroke-linejoin="round" />
                            <rect x="130" y="100" width="30" height="8" rx="2" fill="#ffffff" opacity="0.5" />
                            <rect x="130" y="120" width="50" height="8" rx="2" fill="#ffffff" opacity="0.5" />
                            <rect x="130" y="180" width="40" height="8" rx="2" fill="#ffffff" opacity="0.5" />
                            <rect x="130" y="200" width="35" height="8" rx="2" fill="#ffffff" opacity="0.5" />
                            <defs>
                                <linearGradient id="gradient4" x1="0" y1="0" x2="400" y2="300">
                                    <stop offset="0%" stop-color="#2a5f9e" />
                                    <stop offset="100%" stop-color="#1D4E89" />
                                </linearGradient>
                            </defs>
                        </svg>
                    </div>
                </div>
                <div class="choice-content">
                    <div class="choice-number">04</div>
                    <h3 class="choice-title">Cost-Effective Solutions</h3>
                    <p class="choice-description">
                        Superior quality doesn't have to mean premium pricing. Through efficient manufacturing
                        processes, strategic sourcing, and economies of scale, we deliver exceptional value. Our
                        transparent pricing structure, volume discounts, and long-term partnership programs help reduce
                        your total cost of ownership while maintaining the highest quality standards.
                    </p>
                    <ul class="choice-highlights">
                        <li>Competitive pricing without compromising quality</li>
                        <li>Volume discount programs</li>
                        <li>Extended warranty options</li>
                        <li>Total cost of ownership optimization</li>
                    </ul>
                </div>
            </div>

            <!-- Feature Item 5 - Text Left, Image Right -->
            <div class="choice-item">
                <div class="choice-content">
                    <div class="choice-number">05</div>
                    <h3 class="choice-title">Sustainable Manufacturing Practices</h3>
                    <p class="choice-description">
                        Environmental responsibility is at the core of our operations. We've invested in
                        energy-efficient manufacturing equipment, implemented comprehensive recycling programs, and
                        optimized our processes to minimize waste. Our commitment to sustainability extends throughout
                        the supply chain, ensuring that choosing us means choosing a greener future for the industry.
                    </p>
                    <ul class="choice-highlights">
                        <li>40% reduction in energy consumption</li>
                        <li>95% material recycling rate</li>
                        <li>Carbon-neutral facility operations</li>
                        <li>Eco-friendly packaging solutions</li>
                    </ul>
                </div>
                <div class="choice-image">
                    <div class="choice-image-placeholder">
                        <svg width="100%" height="100%" viewBox="0 0 400 300" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect width="400" height="300" fill="url(#gradient5)" />
                            <circle cx="200" cy="150" r="70" stroke="#ffffff" stroke-width="3" opacity="0.3" />
                            <path d="M200 80 Q180 100 200 120 Q220 100 200 80" fill="#ffffff" opacity="0.6" />
                            <path d="M200 120 L200 180" stroke="#ffffff" stroke-width="4" stroke-linecap="round" />
                            <path d="M180 140 Q170 150 180 160" stroke="#ffffff" stroke-width="3" stroke-linecap="round"
                                fill="none" />
                            <path d="M220 140 Q230 150 220 160" stroke="#ffffff" stroke-width="3" stroke-linecap="round"
                                fill="none" />
                            <ellipse cx="200" cy="190" rx="25" ry="8" fill="#ffffff" opacity="0.4" />
                            <defs>
                                <linearGradient id="gradient5" x1="0" y1="0" x2="400" y2="300">
                                    <stop offset="0%" stop-color="#1D4E89" />
                                    <stop offset="100%" stop-color="#2a5f9e" />
                                </linearGradient>
                            </defs>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
endif; ?>

    <!-- Deep Value Section -->
    <section class="value">
        <div class="container">
            <div class="value-content">
                <div class="value-image">
                    <div class="value-image-placeholder">
                        <div class="technical-diagram">
                            <div class="diagram-layer"></div>
                            <div class="diagram-layer"></div>
                            <div class="diagram-layer"></div>
                        </div>
                    </div>
                </div>
                <div class="value-text">
                    <p class="section-label">Manufacturing Excellence</p>
                    <h2 class="section-title">Engineered From First Principles</h2>
                    <p class="value-description">
                        Our bearing design begins with fundamental physics and material science. Using finite element
                        analysis and computational fluid dynamics, we optimize every aspect of bearing performance
                        before production.
                    </p>
                    <div class="value-features">
                        <div class="value-feature-item">
                            <div class="value-feature-number">01</div>
                            <div class="value-feature-content">
                                <h4>Advanced Material Selection</h4>
                                <p>Premium bearing steel with controlled alloy composition. Heat treatment processes
                                    developed through decades of metallurgical research.</p>
                            </div>
                        </div>
                        <div class="value-feature-item">
                            <div class="value-feature-number">02</div>
                            <div class="value-feature-content">
                                <h4>Precision Manufacturing</h4>
                                <p>State-of-the-art CNC grinding centers with sub-micron accuracy. Automated inspection
                                    ensures every bearing meets exact specifications.</p>
                            </div>
                        </div>
                        <div class="value-feature-item">
                            <div class="value-feature-number">03</div>
                            <div class="value-feature-content">
                                <h4>Rigorous Validation</h4>
                                <p>Full lifecycle testing including thermal cycling, contamination resistance, and
                                    accelerated fatigue testing under real-world load conditions.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Applications Section -->
    <section class="applications" id="applications">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Application Engineering</p>
                <h2 class="section-title">Tailored Solutions For Every Industry</h2>
            </div>
            <div class="applications-grid">
                <div class="application-card">
                    <div class="application-icon-wrap">
                        <svg class="application-icon" width="40" height="40" viewBox="0 0 40 40" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect x="4" y="20" width="32" height="12" rx="2" stroke="currentColor" stroke-width="2" />
                            <circle cx="12" cy="32" r="4" stroke="currentColor" stroke-width="2" />
                            <circle cx="28" cy="32" r="4" stroke="currentColor" stroke-width="2" />
                            <path d="M4 20L8 12H20L24 20" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </div>
                    <h3 class="application-title">Passenger Vehicles</h3>
                    <p class="application-description">
                        Optimized for comfort, efficiency, and quiet operation. Meeting OEM specifications for sedans,
                        SUVs, and electric vehicles with advanced NVH characteristics.
                    </p>
                </div>
                <div class="application-card">
                    <div class="application-icon-wrap">
                        <svg class="application-icon" width="40" height="40" viewBox="0 0 40 40" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect x="2" y="16" width="36" height="16" rx="2" stroke="currentColor" stroke-width="2" />
                            <circle cx="10" cy="32" r="4" stroke="currentColor" stroke-width="2" />
                            <circle cx="30" cy="32" r="4" stroke="currentColor" stroke-width="2" />
                            <path d="M2 16L6 8H16L20 16" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                            <rect x="24" y="10" width="8" height="6" stroke="currentColor" stroke-width="2" />
                        </svg>
                    </div>
                    <h3 class="application-title">Commercial Vehicles</h3>
                    <p class="application-description">
                        Heavy-duty bearings engineered for extreme loads and continuous operation. Proven reliability in
                        trucks, buses, and fleet applications with extended service intervals.
                    </p>
                </div>
                <div class="application-card">
                    <div class="application-icon-wrap">
                        <svg class="application-icon" width="40" height="40" viewBox="0 0 40 40" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 28L12 20H20L16 28H8Z" stroke="currentColor" stroke-width="2"
                                stroke-linejoin="round" />
                            <circle cx="12" cy="28" r="3" stroke="currentColor" stroke-width="2" />
                            <path d="M20 28L24 20H32L28 28H20Z" stroke="currentColor" stroke-width="2"
                                stroke-linejoin="round" />
                            <circle cx="24" cy="28" r="3" stroke="currentColor" stroke-width="2" />
                            <path d="M16 12L20 8L24 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </div>
                    <h3 class="application-title">Off-Highway & Agriculture</h3>
                    <p class="application-description">
                        Ruggedized designs for construction equipment, agricultural machinery, and mining vehicles.
                        Enhanced sealing for operation in contaminated environments.
                    </p>
                </div>
                <div class="application-card">
                    <div class="application-icon-wrap">
                        <svg class="application-icon" width="40" height="40" viewBox="0 0 40 40" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <circle cx="20" cy="20" r="12" stroke="currentColor" stroke-width="2" />
                            <path d="M20 8V12M20 28V32M8 20H12M28 20H32" stroke="currentColor" stroke-width="2"
                                stroke-linecap="round" />
                            <circle cx="20" cy="20" r="4" fill="currentColor" />
                            <path d="M14 14L16 16M26 14L24 16M14 26L16 24M26 26L24 24" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" />
                        </svg>
                    </div>
                    <h3 class="application-title">Electric & Hybrid Vehicles</h3>
                    <p class="application-description">
                        Specialized bearings for e-axle systems with reduced friction and enhanced thermal management.
                        Compatible with high-speed electric motor integration.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Image Showcase Carousel -->
    <section class="showcase-carousel">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Manufacturing Excellence</p>
                <h2 class="section-title">Inside Our Facilities</h2>
                <p class="section-description">
                    State-of-the-art manufacturing equipment and quality control processes that ensure every bearing
                    meets our exacting standards.
                </p>
            </div>
        </div>
        <div class="carousel-wrapper">
            <div class="carousel-container">
                <div class="carousel-track" id="showcaseTrack">
                    <div class="carousel-item">
                        <div class="carousel-image">
                            <div class="carousel-image-placeholder"
                                style="background: linear-gradient(135deg, #1D4E89 0%, #2a5f9e 100%);">
                                <svg width="120" height="120" viewBox="0 0 120 120" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect x="20" y="30" width="80" height="60" rx="4" stroke="white" stroke-width="2" />
                                    <circle cx="60" cy="60" r="20" stroke="white" stroke-width="2" />
                                    <circle cx="60" cy="60" r="8" fill="white" />
                                    <path d="M30 40 L50 50 M70 50 L90 40" stroke="white" stroke-width="2" />
                                </svg>
                            </div>
                        </div>
                        <div class="carousel-caption">
                            <h3>CNC Precision Machining</h3>
                            <p>Advanced 5-axis CNC grinding centers achieving sub-micron tolerances</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="carousel-image">
                            <div class="carousel-image-placeholder"
                                style="background: linear-gradient(135deg, #333333 0%, #555555 100%);">
                                <svg width="120" height="120" viewBox="0 0 120 120" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M40 30 L60 50 L80 30" stroke="white" stroke-width="2" fill="none" />
                                    <rect x="30" y="50" width="60" height="40" rx="4" stroke="white" stroke-width="2" />
                                    <circle cx="45" cy="70" r="8" stroke="white" stroke-width="2" />
                                    <circle cx="75" cy="70" r="8" stroke="white" stroke-width="2" />
                                </svg>
                            </div>
                        </div>
                        <div class="carousel-caption">
                            <h3>Automated Assembly Line</h3>
                            <p>Robotic assembly ensuring consistent quality and precision in every unit</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="carousel-image">
                            <div class="carousel-image-placeholder"
                                style="background: linear-gradient(135deg, #2a5f9e 0%, #1D4E89 100%);">
                                <svg width="120" height="120" viewBox="0 0 120 120" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect x="40" y="30" width="40" height="50" rx="4" stroke="white" stroke-width="2" />
                                    <circle cx="60" cy="55" r="15" stroke="white" stroke-width="2" />
                                    <path d="M60 40 L60 50 M60 60 L60 70" stroke="white" stroke-width="2" />
                                    <path d="M45 55 L55 55 M65 55 L75 55" stroke="white" stroke-width="2" />
                                </svg>
                            </div>
                        </div>
                        <div class="carousel-caption">
                            <h3>Quality Control Laboratory</h3>
                            <p>100% inspection using CMM, acoustic testing, and vibration analysis</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="carousel-image">
                            <div class="carousel-image-placeholder"
                                style="background: linear-gradient(135deg, #1D4E89 0%, #333333 100%);">
                                <svg width="120" height="120" viewBox="0 0 120 120" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M30 70 Q60 40 90 70" stroke="white" stroke-width="2" fill="none" />
                                    <circle cx="30" cy="70" r="4" fill="white" />
                                    <circle cx="60" cy="50" r="4" fill="white" />
                                    <circle cx="90" cy="70" r="4" fill="white" />
                                    <rect x="25" y="75" width="70" height="20" stroke="white" stroke-width="2" />
                                </svg>
                            </div>
                        </div>
                        <div class="carousel-caption">
                            <h3>Heat Treatment Facility</h3>
                            <p>Controlled atmosphere furnaces for optimal material properties</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="carousel-image">
                            <div class="carousel-image-placeholder"
                                style="background: linear-gradient(135deg, #555555 0%, #2a5f9e 100%);">
                                <svg width="120" height="120" viewBox="0 0 120 120" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect x="30" y="40" width="60" height="40" rx="4" stroke="white" stroke-width="2" />
                                    <path d="M45 50 L50 60 L55 50" stroke="white" stroke-width="2" fill="none" />
                                    <path d="M65 50 L70 60 L75 50" stroke="white" stroke-width="2" fill="none" />
                                    <line x1="40" y1="70" x2="80" y2="70" stroke="white" stroke-width="2" />
                                </svg>
                            </div>
                        </div>
                        <div class="carousel-caption">
                            <h3>R&D Engineering Center</h3>
                            <p>Advanced simulation and prototyping for custom bearing solutions</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="carousel-image">
                            <div class="carousel-image-placeholder"
                                style="background: linear-gradient(135deg, #1D4E89 0%, #2a5f9e 100%);">
                                <svg width="120" height="120" viewBox="0 0 120 120" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect x="25" y="35" width="70" height="50" rx="4" stroke="white" stroke-width="2" />
                                    <rect x="35" y="45" width="20" height="15" stroke="white" stroke-width="2" />
                                    <rect x="65" y="45" width="20" height="15" stroke="white" stroke-width="2" />
                                    <rect x="35" y="65" width="50" height="15" stroke="white" stroke-width="2" />
                                </svg>
                            </div>
                        </div>
                        <div class="carousel-caption">
                            <h3>Logistics & Distribution</h3>
                            <p>Global shipping network ensuring timely delivery worldwide</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-nav">
                <button class="carousel-btn carousel-btn-prev" id="showcasePrev" aria-label="Previous images">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" />
                    </svg>
                </button>
                <button class="carousel-btn carousel-btn-next" id="showcaseNext" aria-label="Next images">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" />
                    </svg>
                </button>
            </div>
            <div class="carousel-indicators" id="showcaseIndicators"></div>
        </div>
    </section>

    <!-- News Section -->
    <section class="news-section">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Latest Updates</p>
                <h2 class="section-title">Industry News & Insights</h2>
                <p class="section-description">
                    Stay informed about our latest innovations, industry developments, and technical insights from our
                    engineering team.
                </p>
            </div>
            <div class="news-grid">
                <div class="news-card featured">
                    <div class="news-image">
                        <div class="news-image-placeholder"
                            style="background: linear-gradient(135deg, #1D4E89 0%, #2a5f9e 100%);">
                            <svg width="80" height="80" viewBox="0 0 80 80" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect x="15" y="20" width="50" height="40" rx="4" stroke="white" stroke-width="2" />
                                <circle cx="40" cy="40" r="12" stroke="white" stroke-width="2" />
                                <circle cx="40" cy="40" r="4" fill="white" />
                                <path d="M28 52 L40 40 L52 52" stroke="white" stroke-width="2" />
                            </svg>
                        </div>
                        <span class="news-badge featured-badge">Featured</span>
                    </div>
                    <div class="news-content">
                        <div class="news-meta">
                            <span class="news-category">Innovation</span>
                            <span class="news-date">January 2, 2026</span>
                        </div>
                        <h3 class="news-title">Next-Gen EV Bearing Technology Reduces Friction by 30%</h3>
                        <p class="news-excerpt">
                            Our engineering team has developed a breakthrough bearing design specifically optimized for
                            electric vehicle e-axle systems. The new EV-Optimized E-Drive Hub features advanced surface
                            treatments and innovative sealing technology that significantly reduces energy loss.
                        </p>
                        <a href="#" class="news-link">Read Full Article →</a>
                    </div>
                </div>
                <div class="news-card">
                    <div class="news-image">
                        <div class="news-image-placeholder"
                            style="background: linear-gradient(135deg, #333333 0%, #555555 100%);">
                            <svg width="60" height="60" viewBox="0 0 60 60" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M20 15 L30 25 L40 15" stroke="white" stroke-width="2" />
                                <rect x="15" y="25" width="30" height="20" stroke="white" stroke-width="2" />
                                <path d="M30 35 L30 45 M25 40 L35 40" stroke="white" stroke-width="2" />
                            </svg>
                        </div>
                        <span class="news-badge">Press Release</span>
                    </div>
                    <div class="news-content">
                        <div class="news-meta">
                            <span class="news-category">Company News</span>
                            <span class="news-date">December 28, 2025</span>
                        </div>
                        <h3 class="news-title">ISO/TS 16949 Certification Renewed for 2026</h3>
                        <p class="news-excerpt">
                            We're proud to announce the successful renewal of our ISO/TS 16949 certification,
                            demonstrating our continued commitment to automotive quality management excellence.
                        </p>
                        <a href="#" class="news-link">Read More →</a>
                    </div>
                </div>
                <div class="news-card">
                    <div class="news-image">
                        <div class="news-image-placeholder"
                            style="background: linear-gradient(135deg, #2a5f9e 0%, #1D4E89 100%);">
                            <svg width="60" height="60" viewBox="0 0 60 60" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect x="20" y="15" width="20" height="30" rx="2" stroke="white" stroke-width="2" />
                                <path d="M25 20 L35 20 M25 25 L35 25 M25 30 L32 30" stroke="white" stroke-width="2" />
                            </svg>
                        </div>
                        <span class="news-badge">Technical</span>
                    </div>
                    <div class="news-content">
                        <div class="news-meta">
                            <span class="news-category">White Paper</span>
                            <span class="news-date">December 20, 2025</span>
                        </div>
                        <h3 class="news-title">Understanding Load Distribution in Gen3 Hub Bearings</h3>
                        <p class="news-excerpt">
                            A comprehensive technical guide exploring how optimized internal geometry improves load
                            distribution and extends service life in modern wheel hub bearings.
                        </p>
                        <a href="#" class="news-link">Download PDF →</a>
                    </div>
                </div>
                <div class="news-card">
                    <div class="news-image">
                        <div class="news-image-placeholder"
                            style="background: linear-gradient(135deg, #555555 0%, #333333 100%);">
                            <svg width="60" height="60" viewBox="0 0 60 60" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <circle cx="30" cy="30" r="15" stroke="white" stroke-width="2" />
                                <path d="M30 20 L30 30 L37 33" stroke="white" stroke-width="2" />
                            </svg>
                        </div>
                        <span class="news-badge">Event</span>
                    </div>
                    <div class="news-content">
                        <div class="news-meta">
                            <span class="news-category">Trade Show</span>
                            <span class="news-date">December 15, 2025</span>
                        </div>
                        <h3 class="news-title">Visit Us at Automotive Manufacturing Expo 2026</h3>
                        <p class="news-excerpt">
                            Join us at booth A-247 to see live demonstrations of our latest bearing technology and meet
                            our engineering team. March 15-18, Detroit, MI.
                        </p>
                        <a href="#" class="news-link">Event Details →</a>
                    </div>
                </div>
                <div class="news-card">
                    <div class="news-image">
                        <div class="news-image-placeholder"
                            style="background: linear-gradient(135deg, #1D4E89 0%, #333333 100%);">
                            <svg width="60" height="60" viewBox="0 0 60 60" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M20 25 L25 30 L35 20" stroke="white" stroke-width="2" stroke-linecap="round" />
                                <circle cx="30" cy="30" r="15" stroke="white" stroke-width="2" />
                            </svg>
                        </div>
                        <span class="news-badge">Achievement</span>
                    </div>
                    <div class="news-content">
                        <div class="news-meta">
                            <span class="news-category">Milestone</span>
                            <span class="news-date">December 10, 2025</span>
                        </div>
                        <h3 class="news-title">50 Million Units Milestone Reached</h3>
                        <p class="news-excerpt">
                            A testament to quality and reliability - we've successfully delivered over 50 million wheel
                            hub bearings to customers worldwide since our founding.
                        </p>
                        <a href="#" class="news-link">Read Story →</a>
                    </div>
                </div>
                <div class="news-card">
                    <div class="news-image">
                        <div class="news-image-placeholder"
                            style="background: linear-gradient(135deg, #2a5f9e 0%, #555555 100%);">
                            <svg width="60" height="60" viewBox="0 0 60 60" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect x="15" y="20" width="30" height="25" rx="2" stroke="white" stroke-width="2" />
                                <path d="M20 28 L25 33 L35 23" stroke="white" stroke-width="2" stroke-linecap="round" />
                            </svg>
                        </div>
                        <span class="news-badge">Case Study</span>
                    </div>
                    <div class="news-content">
                        <div class="news-meta">
                            <span class="news-category">Success Story</span>
                            <span class="news-date">December 5, 2025</span>
                        </div>
                        <h3 class="news-title">Heavy Duty Fleet Reduces Maintenance Costs by 40%</h3>
                        <p class="news-excerpt">
                            Learn how a major commercial vehicle fleet operator achieved significant cost savings by
                            switching to our HD-Series bearings with extended service intervals.
                        </p>
                        <a href="#" class="news-link">View Case Study →</a>
                    </div>
                </div>
            </div>
            <div class="news-cta">
                <a href="#" class="btn btn-secondary">View All News & Updates</a>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta" id="contact">
        <div class="container">
            <div class="cta-content">
                <div class="cta-text">
                    <h2 class="cta-title">Ready To Engineer Your Solution?</h2>
                    <p class="cta-description">
                        Our technical team is ready to discuss your bearing requirements and develop custom solutions
                        for your specific application. Request a quote or technical consultation today.
                    </p>
                    <div class="cta-features">
                        <div class="cta-feature">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            <span>24-48h Quote Turnaround</span>
                        </div>
                        <div class="cta-feature">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            <span>Expert Engineering Support</span>
                        </div>
                        <div class="cta-feature">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            <span>Custom Design Capabilities</span>
                        </div>
                    </div>
                </div>
                <div class="cta-form-wrap">
                    <form class="cta-form" id="contactForm">
                        <div class="form-group">
                            <label for="name" class="form-label">Full Name *</label>
                            <input type="text" id="name" name="name" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label for="email" class="form-label">Email Address *</label>
                            <input type="email" id="email" name="email" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label for="company" class="form-label">Company Name *</label>
                            <input type="text" id="company" name="company" class="form-input" required>
                        </div>
                        <div class="form-group">
                            <label for="application" class="form-label">Application Type</label>
                            <select id="application" name="application" class="form-input">
                                <option value="">Select application</option>
                                <option value="passenger">Passenger Vehicles</option>
                                <option value="commercial">Commercial Vehicles</option>
                                <option value="offhighway">Off-Highway & Agriculture</option>
                                <option value="electric">Electric & Hybrid Vehicles</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="message" class="form-label">Project Details</label>
                            <textarea id="message" name="message" class="form-input form-textarea" rows="4"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-full">
                            Submit Request
                            <svg class="btn-icon" width="20" height="20" viewBox="0 0 20 20" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

<?php

get_footer();
