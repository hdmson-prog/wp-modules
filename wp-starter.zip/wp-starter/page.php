<?php
/**
 * The template for displaying all pages.
 *
 * @package WP_Starter
 */

get_header();
tqb_page_banner();

// Check if the page has any custom (non-core) blocks
$has_custom_blocks = false;
$blocks = parse_blocks(get_the_content());
foreach ($blocks as $block) {
    // Skip null/empty block names (whitespace between blocks)
    if (empty($block['blockName'])) {
        continue;
    }
    // If any block is NOT a core block, it's a custom layout
    if (strpos($block['blockName'], 'core/') !== 0) {
        $has_custom_blocks = true;
        break;
    }
}
?>

<?php if ($has_custom_blocks): ?>
    
        <?php the_content(); ?>
    
<?php
else: ?>
    <main class="page-content">
        <div class="container">
            <div class="content-wrapper">
                <?php the_content(); ?>
            </div>
        </div>
    </main>
<?php
endif; ?>



<?php get_footer();
