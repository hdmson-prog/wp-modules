<?php
/**
 * Template Name: Custom Login Page
 *
 * @package WP_Starter
 */

get_header();

?>

<div class="login-page-container" style="margin-top: 100px;">
    <div class="login-card">
        <div class="login-header">
            <?php if (ws_get_option('site_logo')) { ?>
                <img src="<?php echo ws_get_option('site_logo'); ?>" alt="<?php bloginfo('name'); ?>" class="login-logo" style="max-height: 80px; margin-bottom: 2rem;">
            <?php
}
else { ?>
                <h1 class="logo-text"><strong><?php esc_html_e('TQB', 'tqb'); ?></strong><?php esc_html_e('BEARINGS', 'tqb'); ?></h1>
            <?php
}?>
            <h2><?php esc_html_e('Welcome Back', 'tqb'); ?></h2>
            <p><?php esc_html_e('Please enter your credentials to log in.', 'tqb'); ?></p>
        </div>

        <div class="login-form-wrapper">
            <?php
if (!is_user_logged_in()) {
    $args = array(
        'echo' => true,
        'redirect' => home_url(),
        'form_id' => 'loginform',
        'label_username' => __('Username or Email Address', 'tqb'),
        'label_password' => __('Password', 'tqb'),
        'label_remember' => __('Remember Me', 'tqb'),
        'label_log_in' => __('Log In', 'tqb'),
        'id_username' => 'user_login',
        'id_password' => 'user_pass',
        'id_remember' => 'rememberme',
        'id_submit' => 'wp-submit',
        'remember' => true,
        'value_username' => '',
        'value_remember' => false
    );
    wp_login_form($args);
}
else {
?>
                <div class="logged-in-message" style="text-align: center;">
                    <p><?php esc_html_e('You are already logged in.', 'tqb'); ?></p>
                    <a href="<?php echo home_url(); ?>" class="btn-primary" style="display: inline-block; padding: 10px 20px; background: #007bff; color: #fff; border-radius: 5px; text-decoration: none; margin-top: 1rem;"><?php esc_html_e('Back to Home', 'tqb'); ?></a>
                </div>
                <?php
}
?>
        </div>

        <div class="login-footer-links">
            <a href="<?php echo wp_lostpassword_url(); ?>"><?php esc_html_e('Lost your password?', 'tqb'); ?></a>
            <?php if (get_option('users_can_register')): ?>
                <a href="<?php echo wp_registration_url(); ?>"><?php esc_html_e('Register', 'tqb'); ?></a>
            <?php
endif; ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>
