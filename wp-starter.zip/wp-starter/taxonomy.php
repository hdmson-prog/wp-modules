<?php

get_header();
tqb_page_banner(); ?>

<section class="products-archive">
        <div class="container">
            <div class="archive-layout">
                <!-- Sidebar -->
                <?php get_sidebar('product'); ?>

                <!-- Main Content -->
                <main class="archive-main">
                    <!-- Filters & Sorting -->
                    <div class="archive-toolbar">
                        <div class="toolbar-left">
                            <?php theme_results_count(); ?>
                        </div>
                        
                       <!--  <div class="toolbar-right">
                            <label for="sortBy" class="sort-label">Sort by:</label>
                            <select id="sortBy" class="sort-select">
                                <option value="default">Default</option>
                                <option value="name-asc">Name (A-Z)</option>
                                <option value="name-desc">Name (Z-A)</option>
                                <option value="newest">Newest First</option>
                            </select>
                        </div> -->
                    </div>

                    <!-- Product Grid -->
                    <div class="archive-grid">

                        <?php while (have_posts()) {
    the_post();
    get_template_part('template-parts/content', 'product');
}?>

                        

                        
                    </div>

                    <!-- Pagination -->
                    <?php theme_pagination(); ?>
                </main>
            </div>
        </div>
    </section>

<?php get_footer(); ?>