# WP Starter Theme

A lightweight WordPress starter theme scaffold.

## Included

- Core templates: `index.php`, `single.php`, `page.php`, `archive.php`, `search.php`, `404.php`
- Layout templates: `header.php`, `footer.php`, `sidebar.php`, `comments.php`
- Template parts in `template-parts/`
- Theme setup and enqueue logic in `inc/`
- Starter assets in `assets/css/main.css` and `assets/js/main.js`

## Usage

1. Copy this folder into `wp-content/themes/wp-starter`.
2. Activate **WP Starter** in the WordPress admin.
3. Create menus and assign them to the `Primary` and `Footer` locations.
4. Customize styles and templates for your project.

