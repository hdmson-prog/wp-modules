<?php
/**
 * The template for displaying search results pages.
 *
 * @package WP_Starter
 */

get_header();
tqb_page_banner();

global $wp_query;
?>

<!-- Search Header -->
    <section class="search-header">
        <div class="container">
            <div class="search-header-content">
                <h1><?php esc_html_e('Search Results', 'tqb'); ?></h1>
                <div class="search-box-wrapper">
                    <?php get_search_form(); ?>
                </div>
            </div>
        </div>
    </section>

	<!-- Search Results Section -->
    <section class="search-results-section">
        <div class="container">
            <!-- Search Info Bar -->
            <div class="search-info">
                <div class="results-count">
                    <?php
printf(
    /* translators: 1: number of results, 2: search query */
    esc_html(_n(
    '%1$s result found for "%2$s"',
    '%1$s results found for "%2$s"',
    $wp_query->found_posts,
    'tqb'
)),
    '<span>' . (int)$wp_query->found_posts . '</span>',
    '<span>' . esc_html(get_search_query()) . '</span>'
);
?>
                </div>
            </div>

            <?php if (have_posts()): ?>

            <!-- Results Container -->
            <div class="results-container" id="resultsContainer">
                <?php while (have_posts()):
        the_post(); ?>

                <article id="post-<?php the_ID(); ?>" <?php post_class('search-result-item'); ?>>
                    <?php if (has_post_thumbnail()): ?>
                    <div class="result-thumbnail">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail('medium'); ?>
                        </a>
                    </div>
                    <?php
        endif; ?>

                    <div class="result-content">
                        <span class="result-type"><?php echo esc_html(get_post_type_object(get_post_type())->labels->singular_name); ?></span>
                        <h2 class="result-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        <div class="result-excerpt">
                            <?php the_excerpt(); ?>
                        </div>
                        <div class="result-meta">
                            <span class="result-date"><?php echo get_the_date(); ?></span>
                            <?php if (get_post_type() === 'post'): ?>
                                <?php
            $categories = get_the_category();
            if (!empty($categories)):
?>
                                <span class="result-category"><?php echo esc_html($categories[0]->name); ?></span>
                                <?php
            endif; ?>
                            <?php
        endif; ?>
                        </div>
                    </div>
                </article>

                <?php
    endwhile; ?>
            </div>

            <!-- Pagination -->
            <div class="pagination" id="pagination">
                <?php
    the_posts_pagination(array(
        'mid_size' => 2,
        'prev_text' => '&larr; ' . esc_html__('Previous', 'tqb'),
        'next_text' => esc_html__('Next', 'tqb') . ' &rarr;',
    ));
?>
            </div>

            <?php
else: ?>

            <!-- No Results Message -->
            <div class="no-results" id="noResults">
                <div class="no-results-icon">🔍</div>
                <h2><?php esc_html_e('No Results Found', 'tqb'); ?></h2>
                <p>
                    <?php
    printf(
        /* translators: %s: search query */
        esc_html__('We couldn\'t find any results for "%s"', 'tqb'),
        esc_html(get_search_query())
    );
?>
                </p>
                <div class="search-suggestions">
                    <h3><?php esc_html_e('Search Suggestions:', 'tqb'); ?></h3>
                    <ul>
                        <li><?php esc_html_e('Check your spelling', 'tqb'); ?></li>
                        <li><?php esc_html_e('Try more general keywords', 'tqb'); ?></li>
                        <li><?php esc_html_e('Try different keywords', 'tqb'); ?></li>
                        <li><?php esc_html_e('Use fewer keywords', 'tqb'); ?></li>
                    </ul>
                </div>
                <div class="quick-links">
                    <h3><?php esc_html_e('Popular Pages:', 'tqb'); ?></h3>
                    <div class="quick-links-grid">
                        <?php
    // Dynamic quick links from a menu or fallback to key pages
    $quick_links = array(
            array(
            'icon' => '📦',
            'label' => __('Products', 'tqb'),
            'url' => get_post_type_archive_link('product'),
        ),
            array(
            'icon' => 'ℹ️',
            'label' => __('About Us', 'tqb'),
            'url' => get_permalink(get_page_by_path('about')),
        ),
            array(
            'icon' => '✓',
            'label' => __('Quality Control', 'tqb'),
            'url' => get_permalink(get_page_by_path('quality-control')),
        ),
            array(
            'icon' => '✉️',
            'label' => __('Contact', 'tqb'),
            'url' => get_permalink(get_page_by_path('contact')),
        ),
    );

    foreach ($quick_links as $link):
        if (!empty($link['url'])):
?>
                        <a href="<?php echo esc_url($link['url']); ?>" class="quick-link-card">
                            <span class="quick-link-icon"><?php echo $link['icon']; ?></span>
                            <span><?php echo esc_html($link['label']); ?></span>
                        </a>
                        <?php
        endif;
    endforeach;
?>
                    </div>
                </div>
            </div>

            <?php
endif; ?>
        </div>
    </section>

	<!-- Popular Searches Section -->
    <section class="popular-searches">
        <div class="container">
            <h2><?php esc_html_e('Popular Searches', 'tqb'); ?></h2>
            <div class="popular-tags">
                <?php
$popular_terms = array(
    'products' => __('Products', 'tqb'),
    'quality control' => __('Quality Control', 'tqb'),
    'manufacturing' => __('Manufacturing', 'tqb'),
    'certifications' => __('Certifications', 'tqb'),
    'innovation' => __('Innovation', 'tqb'),
    'sustainability' => __('Sustainability', 'tqb'),
    'technology' => __('Technology', 'tqb'),
    'contact' => __('Contact', 'tqb'),
);

foreach ($popular_terms as $search_term => $label):
?>
                <a href="<?php echo esc_url(home_url('/?s=' . urlencode($search_term))); ?>" class="tag">
                    <?php echo esc_html($label); ?>
                </a>
                <?php
endforeach; ?>
            </div>
        </div>
    </section>


<?php
get_footer();
