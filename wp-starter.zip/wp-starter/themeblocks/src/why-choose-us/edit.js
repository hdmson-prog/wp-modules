import { __ } from '@wordpress/i18n';
import {
	useBlockProps,
	RichText,
	MediaUpload,
	MediaUploadCheck,
} from '@wordpress/block-editor';
import { Button, PanelBody } from '@wordpress/components';

const PlaceholderSVG = ({ index }) => {
	const colors =
		index % 2 === 0
			? { from: '#1D4E89', to: '#2a5f9e' }
			: { from: '#2a5f9e', to: '#1D4E89' };
	return (
		<svg
			width="100%"
			height="100%"
			viewBox="0 0 400 300"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
		>
			<defs>
				<linearGradient
					id={`grad-${index}`}
					x1="0"
					y1="0"
					x2="400"
					y2="300"
				>
					<stop offset="0%" stopColor={colors.from} />
					<stop offset="100%" stopColor={colors.to} />
				</linearGradient>
			</defs>
			<rect
				width="400"
				height="300"
				fill={`url(#grad-${index})`}
			/>
			<circle
				cx="200"
				cy="150"
				r="80"
				stroke="#ffffff"
				strokeWidth="3"
				opacity="0.3"
			/>
			<circle
				cx="200"
				cy="150"
				r="55"
				stroke="#ffffff"
				strokeWidth="3"
				opacity="0.5"
			/>
			<circle
				cx="200"
				cy="150"
				r="30"
				stroke="#ffffff"
				strokeWidth="3"
				opacity="0.7"
			/>
			<circle cx="200" cy="150" r="12" fill="#ffffff" opacity="0.9" />
			<text
				x="200"
				y="240"
				textAnchor="middle"
				fill="#ffffff"
				opacity="0.7"
				fontSize="14"
				fontFamily="sans-serif"
			>
				{__('Click to upload image', 'why-choose-us')}
			</text>
		</svg>
	);
};

const Edit = ({ attributes, setAttributes }) => {
	const { sectionLabel, sectionTitle, sectionDescription, items } =
		attributes;

	const blockProps = useBlockProps({
		className: 'why-choose-us',
	});

	const updateItem = (index, updates) => {
		const newItems = [...items];
		newItems[index] = { ...newItems[index], ...updates };
		setAttributes({ items: newItems });
	};

	const updateHighlight = (itemIndex, hlIndex, value) => {
		const newItems = [...items];
		const newHighlights = [...newItems[itemIndex].highlights];
		newHighlights[hlIndex] = value;
		newItems[itemIndex] = {
			...newItems[itemIndex],
			highlights: newHighlights,
		};
		setAttributes({ items: newItems });
	};

	const addHighlight = (itemIndex) => {
		const newItems = [...items];
		newItems[itemIndex] = {
			...newItems[itemIndex],
			highlights: [
				...newItems[itemIndex].highlights,
				__('New highlight point', 'why-choose-us'),
			],
		};
		setAttributes({ items: newItems });
	};

	const removeHighlight = (itemIndex, hlIndex) => {
		const newItems = [...items];
		const newHighlights = newItems[itemIndex].highlights.filter(
			(_, i) => i !== hlIndex
		);
		newItems[itemIndex] = {
			...newItems[itemIndex],
			highlights: newHighlights,
		};
		setAttributes({ items: newItems });
	};

	const addItem = () => {
		const newId = items.length + 1;
		const num = String(newId).padStart(2, '0');
		setAttributes({
			items: [
				...items,
				{
					id: newId,
					number: num,
					title: __('New Feature Title', 'why-choose-us'),
					description: __(
						'Describe this feature in detail.',
						'why-choose-us'
					),
					highlights: [
						__('Highlight point one', 'why-choose-us'),
					],
					imageUrl: '',
					imageId: 0,
					imageAlt: '',
				},
			],
		});
	};

	const removeItem = (index) => {
		const newItems = items.filter((_, i) => i !== index);
		setAttributes({ items: newItems });
	};

	return (
		<section {...blockProps}>
			<div className="wcu-editor__container">
				{/* Section Header */}
				<div className="wcu-editor__section-header">
					<RichText
						tagName="p"
						className="wcu-section-label"
						value={sectionLabel}
						onChange={(val) =>
							setAttributes({ sectionLabel: val })
						}
						placeholder={__('Section label…', 'why-choose-us')}
						allowedFormats={[]}
					/>
					<RichText
						tagName="h2"
						className="wcu-section-title"
						value={sectionTitle}
						onChange={(val) =>
							setAttributes({ sectionTitle: val })
						}
						placeholder={__(
							'Section title…',
							'why-choose-us'
						)}
						allowedFormats={['core/bold', 'core/italic']}
					/>
					<RichText
						tagName="p"
						className="wcu-section-description"
						value={sectionDescription}
						onChange={(val) =>
							setAttributes({ sectionDescription: val })
						}
						placeholder={__(
							'Section description…',
							'why-choose-us'
						)}
						allowedFormats={['core/bold', 'core/italic']}
					/>
				</div>

				{/* Feature Items */}
				{items.map((item, itemIndex) => {
					const isReverse = itemIndex % 2 !== 0;
					return (
						<div
							key={item.id}
							className={`wcu-editor__choice-item${isReverse
								? ' wcu-editor__choice-item--reverse'
								: ''
								}`}
						>
							{/* Remove Item Button */}
							<div className="wcu-editor__item-controls">
								<button
									className="wcu-editor__remove-item"
									onClick={() => removeItem(itemIndex)}
									title={__(
										'Remove item',
										'why-choose-us'
									)}
								>
									✕
								</button>
							</div>

							{/* Content */}
							<div className="wcu-editor__choice-content">
								<RichText
									tagName="div"
									className="wcu-choice-number"
									value={item.number}
									onChange={(val) =>
										updateItem(itemIndex, { number: val })
									}
									placeholder="01"
									allowedFormats={[]}
								/>
								<RichText
									tagName="h3"
									className="wcu-choice-title"
									value={item.title}
									onChange={(val) =>
										updateItem(itemIndex, { title: val })
									}
									placeholder={__(
										'Feature title…',
										'why-choose-us'
									)}
									allowedFormats={[
										'core/bold',
										'core/italic',
									]}
								/>
								<RichText
									tagName="p"
									className="wcu-choice-description"
									value={item.description}
									onChange={(val) =>
										updateItem(
											itemIndex,
											{ description: val }
										)
									}
									placeholder={__(
										'Feature description…',
										'why-choose-us'
									)}
									allowedFormats={[
										'core/bold',
										'core/italic',
										'core/link',
									]}
								/>

								{/* Highlights */}
								<ul className="wcu-choice-highlights">
									{item.highlights.map(
										(hl, hlIndex) => (
											<li
												key={hlIndex}
												className="wcu-editor__highlight-item"
											>
												<RichText
													tagName="span"
													value={hl}
													onChange={(val) =>
														updateHighlight(
															itemIndex,
															hlIndex,
															val
														)
													}
													placeholder={__(
														'Highlight…',
														'why-choose-us'
													)}
													allowedFormats={[
														'core/bold',
													]}
												/>
												<button
													className="wcu-editor__remove-highlight"
													onClick={() =>
														removeHighlight(
															itemIndex,
															hlIndex
														)
													}
													title={__(
														'Remove',
														'why-choose-us'
													)}
												>
													✕
												</button>
											</li>
										)
									)}
								</ul>
								<Button
									variant="tertiary"
									className="wcu-editor__add-highlight"
									onClick={() => addHighlight(itemIndex)}
									icon="plus"
								>
									{__(
										'Add highlight',
										'why-choose-us'
									)}
								</Button>
							</div>

							{/* Image */}
							<div className="wcu-editor__choice-image">
								<MediaUploadCheck>
									<MediaUpload
										onSelect={(media) => {
											updateItem(itemIndex, {
												imageUrl: media.url,
												imageId: media.id,
												imageAlt: media.alt || item.title,
											});
										}}
										allowedTypes={['image']}
										value={item.imageId}
										render={({ open }) => (
											<div
												className="wcu-editor__image-wrapper"
												onClick={open}
											>
												{item.imageUrl ? (
													<>
														<img
															src={item.imageUrl}
															alt={item.imageAlt}
															className="wcu-editor__image"
														/>
														<div className="wcu-editor__image-overlay">
															<span>
																{__(
																	'Change image',
																	'why-choose-us'
																)}
															</span>
														</div>
													</>
												) : (
													<PlaceholderSVG
														index={itemIndex}
													/>
												)}
											</div>
										)}
									/>
								</MediaUploadCheck>
								{item.imageUrl && (
									<Button
										variant="tertiary"
										isDestructive
										className="wcu-editor__remove-image"
										onClick={() => {
											updateItem(itemIndex, {
												imageUrl: '',
												imageId: 0,
											});
										}}
									>
										{__(
											'Remove image',
											'why-choose-us'
										)}
									</Button>
								)}
							</div>
						</div>
					);
				})}

				{/* Add Item Button */}
				<div className="wcu-editor__add-item-wrapper">
					<Button
						variant="secondary"
						className="wcu-editor__add-item"
						onClick={addItem}
						icon="plus"
					>
						{__('Add Feature Item', 'why-choose-us')}
					</Button>
				</div>
			</div>
		</section>
	);
};

export default Edit;
