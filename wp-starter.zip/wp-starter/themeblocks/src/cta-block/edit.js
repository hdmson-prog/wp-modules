import {
	RichText,
	useBlockProps,
} from '@wordpress/block-editor';
import { Button, TextControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

const CheckIcon = () => (
	<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
		<path d="M20 6L9 17L4 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
	</svg>
);

export default function Edit({ attributes, setAttributes }) {
	const { title, description, features, formShortcode, anchorId } = attributes;

	const blockProps = useBlockProps({
		className: 'cta',
		id: anchorId,
	});

	const updateFeature = (index, value) => {
		const updated = features.map((feature, i) =>
			i === index ? { text: value } : feature
		);
		setAttributes({ features: updated });
	};

	const addFeature = () => {
		setAttributes({ features: [...features, { text: __('New Feature', 'cta-block') }] });
	};

	const removeFeature = (index) => {
		setAttributes({ features: features.filter((_, i) => i !== index) });
	};

	return (
		<section {...blockProps}>
			<div className="container">
				<div className="cta-content">
					<div className="cta-text">
						<RichText
							tagName="h2"
							className="cta-title"
							value={title}
							onChange={(value) => setAttributes({ title: value })}
							placeholder={__('Enter CTA title…', 'cta-block')}
							allowedFormats={['core/bold', 'core/italic']}
						/>

						<RichText
							tagName="p"
							className="cta-description"
							value={description}
							onChange={(value) => setAttributes({ description: value })}
							placeholder={__('Enter description…', 'cta-block')}
							allowedFormats={['core/bold', 'core/italic']}
						/>

						<div className="cta-features">
							{features.map((feature, index) => (
								<div className="cta-feature cta-feature--editable" key={index}>
									<CheckIcon />
									<RichText
										tagName="span"
										value={feature.text}
										onChange={(value) => updateFeature(index, value)}
										placeholder={__('Feature text…', 'cta-block')}
										allowedFormats={[]}
									/>
									<button
										className="cta-feature__remove"
										onClick={() => removeFeature(index)}
										aria-label={__('Remove feature', 'cta-block')}
									>
										&times;
									</button>
								</div>
							))}
							<Button
								className="cta-feature__add"
								variant="secondary"
								onClick={addFeature}
							>
								{__('+ Add Feature', 'cta-block')}
							</Button>
						</div>
					</div>

					<div className="cta-form-area">
						<div className="cta-shortcode-label">
							{__('Form Shortcode', 'cta-block')}
						</div>
						<TextControl
							className="cta-shortcode-input"
							value={formShortcode}
							onChange={(value) => setAttributes({ formShortcode: value })}
							placeholder={__('[contact-form-7 id="123"]', 'cta-block')}
							help={__('Paste your form shortcode here. It will render on the front end.', 'cta-block')}
						/>
						{formShortcode && (
							<div className="cta-shortcode-preview">
								<code>{formShortcode}</code>
							</div>
						)}
					</div>
				</div>
			</div>
		</section>
	);
}
