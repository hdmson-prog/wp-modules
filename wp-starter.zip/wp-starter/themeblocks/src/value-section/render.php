<?php
/**
 * Render template for the Value Section block.
 *
 * @param array    $attributes Block attributes.
 * @param string   $content    Block content.
 * @param WP_Block $block      Block instance.
 */

$section_label = $attributes['sectionLabel'] ?? 'Manufacturing Excellence';
$section_title = $attributes['sectionTitle'] ?? 'Engineered From First Principles';
$value_description = $attributes['valueDescription'] ?? '';
$image_id = $attributes['imageId'] ?? 0;
$image_url = $attributes['imageUrl'] ?? '';
$image_alt = $attributes['imageAlt'] ?? '';
$features = $attributes['features'] ?? [];
?>
<section class="value">
	<div class="container">
		<div class="value-content">
			<div class="value-image">
				<?php if ($image_url): ?>
					<img
						src="<?php echo esc_url($image_url); ?>"
						alt="<?php echo esc_attr($image_alt); ?>"
					/>
				<?php
else: ?>
					<div class="value-image-placeholder">
						<div class="technical-diagram">
							<div class="diagram-layer"></div>
							<div class="diagram-layer"></div>
							<div class="diagram-layer"></div>
						</div>
					</div>
				<?php
endif; ?>
			</div>
			<div class="value-text">
				<?php if ($section_label): ?>
					<p class="section-label"><?php echo esc_html($section_label); ?></p>
				<?php
endif; ?>
				<?php if ($section_title): ?>
					<h2 class="section-title"><?php echo esc_html($section_title); ?></h2>
				<?php
endif; ?>
				<?php if ($value_description): ?>
					<p class="value-description"><?php echo esc_html($value_description); ?></p>
				<?php
endif; ?>
				<?php if (!empty($features)): ?>
					<div class="value-features">
						<?php foreach ($features as $feature): ?>
							<div class="value-feature-item">
								<div class="value-feature-number"><?php echo esc_html($feature['number']); ?></div>
								<div class="value-feature-content">
									<h4><?php echo esc_html($feature['title']); ?></h4>
									<p><?php echo esc_html($feature['description']); ?></p>
								</div>
							</div>
						<?php
	endforeach; ?>
					</div>
				<?php
endif; ?>
			</div>
		</div>
	</div>
</section>