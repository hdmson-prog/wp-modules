<?php
/**
 * @var array    $attributes Block attributes.
 * @var string   $content    Block default content.
 * @var WP_Block $block      Block instance.
 */

$wrapper_attributes = get_block_wrapper_attributes(['class' => 'about-intro']);
?>

<section <?php echo $wrapper_attributes; ?>>
    <div class="container">
        <div class="about-intro-content">
            <div class="about-intro-text">
                <p class="section-label"><?php echo wp_kses_post($attributes['label']); ?></p>
                <h2 class="section-title"><?php echo wp_kses_post($attributes['title']); ?></h2>
                <p class="intro-paragraph"><?php echo wp_kses_post($attributes['description1']); ?></p>
                <p class="intro-paragraph"><?php echo wp_kses_post($attributes['description2']); ?></p>
            </div>
            <div class="about-intro-stats">
                <?php foreach ($attributes['stats'] as $stat) : ?>
                    <div class="stat-box">
                        <div class="stat-number-large"><?php echo wp_kses_post($stat['number']); ?></div>
                        <div class="stat-label-large"><?php echo wp_kses_post($stat['label']); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
