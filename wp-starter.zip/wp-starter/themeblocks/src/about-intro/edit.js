import { __ } from '@wordpress/i18n';
import { useBlockProps, RichText } from '@wordpress/block-editor';
import './editor.scss';

export default function Edit({ attributes, setAttributes }) {
	const { label, title, description1, description2, stats } = attributes;

	/**
	 * Updates a specific field within a stat object.
	 * We create a new array and a new object to ensure
	 * WordPress detects the change and triggers a save.
	 */
	const updateStat = (index, key, value) => {
		const newStats = stats.map((stat, i) => {
			if (i === index) {
				return { ...stat, [key]: value };
			}
			return stat;
		});
		setAttributes({ stats: newStats });
	};

	return (
		<section {...useBlockProps({ className: 'about-intro' })}>
			<div className="container">
				<div className="about-intro-content">
					<div className="about-intro-text">
						<RichText
							tagName="p"
							className="section-label"
							value={label}
							onChange={(val) => setAttributes({ label: val })}
							placeholder={__('Enter Label...', 'about-intro')}
						/>
						<RichText
							tagName="h2"
							className="section-title"
							value={title}
							onChange={(val) => setAttributes({ title: val })}
							placeholder={__('Enter Title...', 'about-intro')}
						/>
						<RichText
							tagName="p"
							className="intro-paragraph"
							value={description1}
							onChange={(val) => setAttributes({ description1: val })}
							placeholder={__('Enter first paragraph...', 'about-intro')}
						/>
						<RichText
							tagName="p"
							className="intro-paragraph"
							value={description2}
							onChange={(val) => setAttributes({ description2: val })}
							placeholder={__('Enter second paragraph...', 'about-intro')}
						/>
					</div>
					<div className="about-intro-stats">
						{stats.map((stat, index) => (
							<div className="stat-box" key={index}>
								<RichText
									tagName="div"
									className="stat-number-large"
									value={stat.number}
									onChange={(val) => updateStat(index, 'number', val)}
									placeholder="0"
								/>
								<RichText
									tagName="div"
									className="stat-label-large"
									value={stat.label}
									onChange={(val) => updateStat(index, 'label', val)}
									placeholder="Label"
								/>
							</div>
						))}
					</div>
				</div>
			</div>
		</section>
	);
}
