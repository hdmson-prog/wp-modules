<?php
/**
 * Dynamic rendering for SVG icons.
 * We use wp_kses to allow SVG tags while keeping it secure.
 */

$cards = $attributes['cards'] ?? [];

// Helper to sanitize SVG
$allowed_svg = [
    'svg' => [
        'xmlns'       => true,
        'fill'        => true,
        'viewbox'     => true,
        'role'        => true,
        'aria-hidden' => true,
        'width'       => true,
        'height'      => true,
    ],
    'path' => [
        'd'           => true,
        'fill'        => true,
        'stroke'      => true,
        'stroke-width' => true,
        'stroke-linecap' => true,
        'stroke-linejoin' => true,
    ],
    'circle' => [
        'cx' => true,
        'cy' => true,
        'r'  => true,
        'stroke' => true,
        'stroke-width' => true,
        'fill' => true,
    ],
    'rect' => [
        'x' => true,
        'y' => true,
        'width' => true,
        'height' => true,
        'rx' => true,
        'stroke' => true,
        'stroke-width' => true,
        'fill' => true,
    ],
];

?>
<section <?php echo get_block_wrapper_attributes(['class' => 'mission-vision']); ?>>
    <div class="container">
        <div class="mvv-grid">
            <?php foreach ($cards as $card) : ?>
                <div class="mvv-card">
                    <div class="mvv-icon">
                        <?php
                        // Output the raw SVG code
                        echo wp_kses($card['svgCode'], $allowed_svg);
                        ?>
                    </div>
                    <h3 class="mvv-title"><?php echo wp_kses_post($card['title']); ?></h3>
                    <p class="mvv-description"><?php echo wp_kses_post($card['description']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
