import { __ } from '@wordpress/i18n';
import { useBlockProps, RichText } from '@wordpress/block-editor';
import { TextareaControl } from '@wordpress/components';
import './editor.scss';

export default function Edit({ attributes, setAttributes }) {
	const { cards } = attributes;

	const updateCard = (index, key, value) => {
		const newCards = [...cards];
		newCards[index] = { ...newCards[index], [key]: value };
		setAttributes({ cards: newCards });
	};

	return (
		<section {...useBlockProps({ className: 'mission-vision' })}>
			<div className="container">
				<div className="mvv-grid">
					{cards.map((card, index) => (
						<div className="mvv-card" key={index}>
							<div className="mvv-icon">
								{/* Visual Preview of SVG */}
								<div
									className="svg-preview"
									dangerouslySetInnerHTML={{ __html: card.svgCode }}
								/>

								{/* Paste area for SVG code */}
								<TextareaControl
									label={__('Paste SVG Code', 'mission-vision')}
									value={card.svgCode}
									onChange={(val) => updateCard(index, 'svgCode', val)}
									rows={3}
									className="svg-input-field"
								/>
							</div>

							<RichText
								tagName="h3"
								className="mvv-title"
								value={card.title}
								onChange={(val) => updateCard(index, 'title', val)}
								placeholder={__('Enter Title...', 'mission-vision')}
							/>

							<RichText
								tagName="p"
								className="mvv-description"
								value={card.description}
								onChange={(val) => updateCard(index, 'description', val)}
								placeholder={__('Enter description...', 'mission-vision')}
							/>
						</div>
					))}
				</div>
			</div>
		</section>
	);
}
