import { __ } from '@wordpress/i18n';
import { useBlockProps, RichText, PlainText } from '@wordpress/block-editor';
import './editor.scss';

export default function Edit({ attributes, setAttributes }) {
	const {
		formHeading, formSubheading, formShortcode, infoTitle, infoDesc,
		contactItems, addressLabel, addressLine1, addressLine2,
		hoursTitle, businessHours
	} = attributes;

	const updateItem = (index, key, value) => {
		const newItems = [...contactItems];
		newItems[index] = { ...newItems[index], [key]: value };
		setAttributes({ contactItems: newItems });
	};

	const addItem = () => {
		setAttributes({
			contactItems: [
				...contactItems,
				{ label: __('New Label'), value1: __('Value 1'), value2: __('Value 2'), type: 'phone' }
			]
		});
	};

	const deleteItem = (index) => {
		const newItems = contactItems.filter((_, i) => i !== index);
		setAttributes({ contactItems: newItems });
	};

	const updateHour = (index, key, value) => {
		const newHours = [...businessHours];
		newHours[index] = { ...newHours[index], [key]: value };
		setAttributes({ businessHours: newHours });
	};

	const addHour = () => {
		setAttributes({
			businessHours: [
				...businessHours,
				{ day: __('New Day'), time: __('Time Range') }
			]
		});
	};

	const deleteHour = (index) => {
		const newHours = businessHours.filter((_, i) => i !== index);
		setAttributes({ businessHours: newHours });
	};

	return (
		<section {...useBlockProps({ className: 'contact-section' })}>
			<div className="container">
				<div className="contact-layout">
					{/* Contact Form Side */}
					<div className="contact-form-wrapper">
						<RichText
							tagName="h2"
							className="form-heading"
							value={formHeading}
							onChange={(val) => setAttributes({ formHeading: val })}
							placeholder={__('Enter heading...')}
						/>
						<RichText
							tagName="p"
							className="form-subheading"
							value={formSubheading}
							onChange={(val) => setAttributes({ formSubheading: val })}
							placeholder={__('Enter subheading...')}
						/>
						<div className="shortcode-placeholder-admin">
							<p><small>{__('Paste Form Shortcode Below:')}</small></p>
							<PlainText
								value={formShortcode}
								onChange={(val) => setAttributes({ formShortcode: val })}
								placeholder="[your-form-shortcode]"
							/>
						</div>
					</div>

					{/* Contact Info Side */}
					<div className="contact-info-wrapper">
						<div className="contact-info-card">
							<RichText tagName="h3" value={infoTitle} onChange={(val) => setAttributes({ infoTitle: val })} />
							<RichText tagName="p" value={infoDesc} onChange={(val) => setAttributes({ infoDesc: val })} />

							<div className="contact-info-list">
								{contactItems.map((item, index) => (
									<div key={index} className="contact-info-item admin-item">
										<div className="contact-info-details">
											<RichText
												tagName="h4"
												value={item.label}
												onChange={(val) => updateItem(index, 'label', val)}
												placeholder={__('Label')}
											/>
											<RichText
												tagName="p"
												value={item.value1}
												onChange={(val) => updateItem(index, 'value1', val)}
												placeholder={__('Value 1')}
											/>
											<RichText
												tagName="p"
												className="contact-hours"
												value={item.value2}
												onChange={(val) => updateItem(index, 'value2', val)}
												placeholder={__('Value 2')}
											/>
											<div className="item-controls">
												<button
													className="button button-link-delete"
													onClick={() => deleteItem(index)}
												>
													{__('Remove Item')}
												</button>
											</div>
										</div>
									</div>
								))}
								<div className="admin-controls">
									<button className="button button-large" onClick={addItem}>
										{__('Add Contact Item')}
									</button>
								</div>
							</div>
						</div>

						{/* Business Hours */}
						<div className="contact-info-card">
							<RichText tagName="h3" value={hoursTitle} onChange={(val) => setAttributes({ hoursTitle: val })} />
							<div className="business-hours">
								{businessHours.map((hour, index) => (
									<div key={index} className="hours-row admin-item">
										<RichText
											tagName="span"
											className="hours-day"
											value={hour.day}
											onChange={(val) => updateHour(index, 'day', val)}
											placeholder={__('Day')}
										/>
										<RichText
											tagName="span"
											className="hours-time"
											value={hour.time}
											onChange={(val) => updateHour(index, 'time', val)}
											placeholder={__('Time')}
										/>
										<div className="item-controls">
											<button
												className="button button-link-delete"
												onClick={() => deleteHour(index)}
											>
												{__('Remove')}
											</button>
										</div>
									</div>
								))}
								<div className="admin-controls">
									<button className="button button-large" onClick={addHour}>
										{__('Add Hours Row')}
									</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	);
}
