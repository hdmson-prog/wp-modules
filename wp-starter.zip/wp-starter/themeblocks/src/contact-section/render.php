<?php
/**
 * @var array    $attributes Block attributes.
 * @var string   $content    Block default content.
 * @var WP_Block $block      Block instance.
 */

$wrapper_attributes = get_block_wrapper_attributes(['class' => 'contact-section']);
?>

<section <?php echo $wrapper_attributes; ?>>
    <div class="container">
        <div class="contact-layout">
            <div class="contact-form-wrapper">
                <h2 class="form-heading"><?php echo wp_kses_post($attributes['formHeading']); ?></h2>
                <p class="form-subheading"><?php echo wp_kses_post($attributes['formSubheading']); ?></p>

                <div class="form-container">
                    <?php echo do_shortcode($attributes['formShortcode']); ?>
                </div>
            </div>

            <div class="contact-info-wrapper">
                <div class="contact-info-card">
                    <h3><?php echo wp_kses_post($attributes['infoTitle']); ?></h3>
                    <p><?php echo wp_kses_post($attributes['infoDesc']); ?></p>

                    <div class="contact-info-list">
                        <?php if (!empty($attributes['contactItems'])): ?>
                            <?php foreach ($attributes['contactItems'] as $item): ?>
                                <div class="contact-info-item">
                                    <div class="contact-info-details">
                                        <h4><?php echo wp_kses_post($item['label']); ?></h4>
                                        <?php if (isset($item['type']) && $item['type'] === 'email' || strpos($item['value1'], '@') !== false): ?>
                                            <p><a href="mailto:<?php echo esc_attr($item['value1']); ?>"><?php echo esc_html($item['value1']); ?></a></p>
                                            <?php if (!empty($item['value2'])): ?>
                                                <p><a href="mailto:<?php echo esc_attr($item['value2']); ?>"><?php echo esc_html($item['value2']); ?></a></p>
                                            <?php
            endif; ?>
                                        <?php
        else: ?>
                                            <p><?php echo wp_kses_post($item['value1']); ?></p>
                                            <?php if (!empty($item['value2'])): ?>
                                                <p class="contact-hours"><?php echo wp_kses_post($item['value2']); ?></p>
                                            <?php
            endif; ?>
                                        <?php
        endif; ?>
                                    </div>
                                </div>
                            <?php
    endforeach; ?>
                        <?php
endif; ?>
                    </div>
                </div>

                <div class="contact-info-card">
                    <h3><?php echo wp_kses_post($attributes['hoursTitle']); ?></h3>
                    <div class="business-hours">
                        <?php if (!empty($attributes['businessHours'])): ?>
                            <?php foreach ($attributes['businessHours'] as $hour): ?>
                                <div class="hours-row">
                                    <span class="hours-day"><?php echo wp_kses_post($hour['day']); ?></span>
                                    <span class="hours-time"><?php echo wp_kses_post($hour['time']); ?></span>
                                </div>
                            <?php
    endforeach; ?>
                        <?php
endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
