import { __ } from '@wordpress/i18n';
import {
	useBlockProps,
	RichText,
	MediaUpload,
	MediaUploadCheck
} from '@wordpress/block-editor';
import { Button, Dashicon } from '@wordpress/components';
import './editor.scss';

export default function Edit({ attributes, setAttributes }) {
	const { mainTitle, timelineItems } = attributes;

	const updateItem = (index, key, value) => {
		const newItems = [...timelineItems];
		newItems[index][key] = value;
		setAttributes({ timelineItems: newItems });
	};

	const addItem = () => {
		setAttributes({
			timelineItems: [
				...timelineItems,
				{ year: '2024', heading: 'New Milestone', description: '', imageId: null, imageUrl: '' }
			]
		});
	};

	const removeItem = (index) => {
		const newItems = timelineItems.filter((_, i) => i !== index);
		setAttributes({ timelineItems: newItems });
	};

	return (
		<section {...useBlockProps({ className: 'timeline-section' })}>
			<div className="container">
				<RichText
					tagName="h2"
					className="section-title text-center"
					value={mainTitle}
					onChange={(val) => setAttributes({ mainTitle: val })}
					placeholder={__('Enter Title...', 'timeline')}
				/>

				<div className="timeline">
					{timelineItems.map((item, index) => (
						<div className="timeline-item" key={index}>
							<div className="timeline-controls">
								<Button isDestructive onClick={() => removeItem(index)}>
									<Dashicon icon="no-alt" />
								</Button>
							</div>

							<RichText
								tagName="div"
								className="timeline-year"
								value={item.year}
								onChange={(val) => updateItem(index, 'year', val)}
								placeholder="1998"
							/>

							<div className="timeline-content">
								<MediaUploadCheck>
									<MediaUpload
										onSelect={(media) => updateItem(index, 'imageUrl', media.url)}
										allowedTypes={['image']}
										value={item.imageId}
										render={({ open }) => (
											<div className="timeline-image-wrapper" onClick={open}>
												{item.imageUrl ? (
													<img src={item.imageUrl} alt="Timeline" />
												) : (
													<div className="placeholder-image">Add Image</div>
												)}
											</div>
										)}
									/>
								</MediaUploadCheck>

								<RichText
									tagName="h3"
									value={item.heading}
									onChange={(val) => updateItem(index, 'heading', val)}
									placeholder="Heading"
								/>
								<RichText
									tagName="p"
									value={item.description}
									onChange={(val) => updateItem(index, 'description', val)}
									placeholder="Describe the milestone..."
								/>
							</div>
						</div>
					))}
				</div>

				<div className="add-item-container">
					<Button isPrimary onClick={addItem}>Add Milestone</Button>
				</div>
			</div>
		</section>
	);
}
