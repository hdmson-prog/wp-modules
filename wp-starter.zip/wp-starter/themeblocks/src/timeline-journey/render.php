<?php
/**
 * Timeline Block Renderer
 */
$mainTitle = $attributes['mainTitle'] ?? '';
$timelineItems = $attributes['timelineItems'] ?? [];
?>

<section class="timeline-section">
	<div class="container">
		<?php if ( ! empty( $mainTitle ) ) : ?>
			<h2 class="section-title text-center"><?php echo wp_kses_post( $mainTitle ); ?></h2>
		<?php endif; ?>

		<div class="timeline">
			<?php foreach ( $timelineItems as $item ) : ?>
				<div class="timeline-item">
					<div class="timeline-year"><?php echo esc_html( $item['year'] ); ?></div>
					<div class="timeline-content">
						<?php if ( ! empty( $item['imageUrl'] ) ) : ?>
							<img src="<?php echo esc_url( $item['imageUrl'] ); ?>" alt="" class="timeline-img">
						<?php endif; ?>

						<h3><?php echo wp_kses_post( $item['heading'] ); ?></h3>
						<p><?php echo wp_kses_post( $item['description'] ); ?></p>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
