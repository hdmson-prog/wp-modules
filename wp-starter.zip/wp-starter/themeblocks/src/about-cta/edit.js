import { __ } from '@wordpress/i18n';
import {
	useBlockProps,
	RichText,
	MediaPlaceholder,
	URLInput
} from '@wordpress/block-editor';
import { useState } from '@wordpress/element';
import './editor.scss';

export default function Edit({ attributes, setAttributes }) {
	const { title, description, btn1Text, btn1Url, btn2Text, btn2Url, bgImageUrl } = attributes;

	// States to toggle visibility of URL inputs
	const [ showUrl1, setShowUrl1 ] = useState(false);
	const [ showUrl2, setShowUrl2 ] = useState(false);

	return (
		<div { ...useBlockProps({
			className: 'about-cta-editor',
			style: { backgroundImage: bgImageUrl ? `url(${bgImageUrl})` : 'none' }
		}) }>
			<div className="container">
				<div className="cta-content-centered">
					<RichText
						tagName="h2"
						value={ title }
						onChange={ (val) => setAttributes({ title: val }) }
						placeholder={ __( 'Enter Heading...', 'custom' ) }
					/>
					<RichText
						tagName="p"
						value={ description }
						onChange={ (val) => setAttributes({ description: val }) }
						placeholder={ __( 'Enter description text...', 'custom' ) }
					/>

					<div className="cta-buttons">
						<div className="button-wrapper">
							<RichText
								tagName="span"
								className="btn btn-primary btn-large"
								value={ btn1Text }
								onChange={ (val) => setAttributes({ btn1Text: val }) }
								placeholder={ __( 'Button 1 Text', 'custom' ) }
								onClickCapture={ () => setShowUrl1(!showUrl1) }
							/>
							{ showUrl1 && (
								<div className="inline-url-popover">
									<URLInput
										value={ btn1Url }
										onChange={ (val) => setAttributes({ btn1Url: val }) }
									/>
								</div>
							) }
						</div>

						<div className="button-wrapper">
							<RichText
								tagName="span"
								className="btn btn-secondary btn-large"
								value={ btn2Text }
								onChange={ (val) => setAttributes({ btn2Text: val }) }
								placeholder={ __( 'Button 2 Text', 'custom' ) }
								onClickCapture={ () => setShowUrl2(!showUrl2) }
							/>
							{ showUrl2 && (
								<div className="inline-url-popover">
									<URLInput
										value={ btn2Url }
										onChange={ (val) => setAttributes({ btn2Url: val }) }
									/>
								</div>
							) }
						</div>
					</div>

					{ ! bgImageUrl && (
						<MediaPlaceholder
							onSelect={ (media) => setAttributes({ bgImageUrl: media.url }) }
							allowedTypes={ [ 'image' ] }
							multiple={ false }
							labels={ { title: 'Add Background' } }
						/>
					) }
				</div>
			</div>
		</div>
	);
}
