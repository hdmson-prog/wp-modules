<?php
/**
 * @var array    $attributes Block attributes.
 * @var string   $content    Block default content.
 * @var WP_Block $block      Block instance.
 */

$wrapper_attributes = get_block_wrapper_attributes([
	'class' => 'about-cta',
	'style' => !empty($attributes['bgImageUrl']) ? 'background-image: url(' . esc_url($attributes['bgImageUrl']) . ');' : ''
]);
?>

<section <?php echo $wrapper_attributes; ?>>
	<div class="container">
		<div class="cta-content-centered">
			<h2><?php echo wp_kses_post($attributes['title']); ?></h2>
			<p><?php echo wp_kses_post($attributes['description']); ?></p>
			<div class="cta-buttons">
				<a href="<?php echo esc_url($attributes['btn1Url']); ?>" class="btn btn-primary btn-large">
					<?php echo esc_html($attributes['btn1Text']); ?>
				</a>
				<a href="<?php echo esc_url($attributes['btn2Url']); ?>" class="btn btn-secondary btn-large">
					<?php echo esc_html($attributes['btn2Text']); ?>
				</a>
			</div>
		</div>
	</div>
</section>
