import { __ } from '@wordpress/i18n';
import {
	useBlockProps,
	RichText,
} from '@wordpress/block-editor';
import { Button, Tooltip } from '@wordpress/components';
import { plus, trash } from '@wordpress/icons';
import { useDispatch } from '@wordpress/data';
import './editor.scss';

const ICONS = {
	precision: (
		<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
			<circle cx="24" cy="24" r="20" stroke="currentColor" strokeWidth="2" />
			<circle cx="24" cy="24" r="12" stroke="currentColor" strokeWidth="2" />
			<circle cx="24" cy="24" r="4" fill="currentColor" />
			<line x1="24" y1="4" x2="24" y2="12" stroke="currentColor" strokeWidth="2" />
			<line x1="24" y1="36" x2="24" y2="44" stroke="currentColor" strokeWidth="2" />
			<line x1="4" y1="24" x2="12" y2="24" stroke="currentColor" strokeWidth="2" />
			<line x1="36" y1="24" x2="44" y2="24" stroke="currentColor" strokeWidth="2" />
		</svg>
	),
	lifespan: (
		<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M8 24L16 16L24 24L32 16L40 24" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
			<path d="M8 32L16 24L24 32L32 24L40 32" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
			<rect x="6" y="8" width="36" height="32" stroke="currentColor" strokeWidth="2" rx="2" />
		</svg>
	),
	load: (
		<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
			<rect x="8" y="12" width="32" height="24" stroke="currentColor" strokeWidth="2" rx="2" />
			<path d="M16 12V8C16 6.89543 16.8954 6 18 6H30C31.1046 6 32 6.89543 32 8V12" stroke="currentColor" strokeWidth="2" />
			<circle cx="24" cy="24" r="4" stroke="currentColor" strokeWidth="2" />
			<path d="M24 28V32" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
		</svg>
	),
	prototype: (
		<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
			<circle cx="24" cy="24" r="18" stroke="currentColor" strokeWidth="2" />
			<path d="M24 12V24L32 28" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
		</svg>
	),
	quality: (
		<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M24 8L32 16L24 24L16 16L24 8Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
			<path d="M24 24L32 32L24 40L16 32L24 24Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
			<path d="M8 24L16 16V32L8 24Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
			<path d="M40 24L32 16V32L40 24Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
		</svg>
	),
	environment: (
		<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M24 4L8 12V24C8 34 16 42 24 44C32 42 40 34 40 24V12L24 4Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
			<path d="M18 24L22 28L30 20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
		</svg>
	),
};

const ICON_KEYS = Object.keys(ICONS);

function generateId() {
	return 'card-' + Math.random().toString(36).substr(2, 9);
}

export default function Edit({ attributes, setAttributes }) {
	const { sectionLabel, sectionTitle, sectionDescription, cards } = attributes;
	const blockProps = useBlockProps({ className: 'features-section-block' });

	const updateCard = (index, field, value) => {
		const newCards = [...cards];
		newCards[index] = { ...newCards[index], [field]: value };
		setAttributes({ cards: newCards });
	};

	const updateSpec = (cardIndex, specIndex, value) => {
		const newCards = [...cards];
		const newSpecs = [...newCards[cardIndex].specs];
		newSpecs[specIndex] = value;
		newCards[cardIndex] = { ...newCards[cardIndex], specs: newSpecs };
		setAttributes({ cards: newCards });
	};

	const addSpec = (cardIndex) => {
		const newCards = [...cards];
		const newSpecs = [...newCards[cardIndex].specs, __('New specification', 'features-section')];
		newCards[cardIndex] = { ...newCards[cardIndex], specs: newSpecs };
		setAttributes({ cards: newCards });
	};

	const removeSpec = (cardIndex, specIndex) => {
		const newCards = [...cards];
		const newSpecs = newCards[cardIndex].specs.filter((_, i) => i !== specIndex);
		newCards[cardIndex] = { ...newCards[cardIndex], specs: newSpecs };
		setAttributes({ cards: newCards });
	};

	const addCard = () => {
		const iconKey = ICON_KEYS[cards.length % ICON_KEYS.length];
		const newCard = {
			id: generateId(),
			icon: iconKey,
			title: __('New Feature', 'features-section'),
			description: __('Describe this feature here.', 'features-section'),
			specs: [__('Specification one', 'features-section')],
		};
		setAttributes({ cards: [...cards, newCard] });
	};

	const removeCard = (index) => {
		const newCards = cards.filter((_, i) => i !== index);
		setAttributes({ cards: newCards });
	};

	const cycleIcon = (index) => {
		const currentIcon = cards[index].icon;
		const currentIdx = ICON_KEYS.indexOf(currentIcon);
		const nextIdx = (currentIdx + 1) % ICON_KEYS.length;
		updateCard(index, 'icon', ICON_KEYS[nextIdx]);
	};

	return (
		<section { ...blockProps }>
			<div className="features-block__container">
				<div className="features-block__header">
					<RichText
						tagName="p"
						className="features-block__label"
						value={ sectionLabel }
						onChange={ (val) => setAttributes({ sectionLabel: val }) }
						placeholder={ __('Section label…', 'features-section') }
						allowedFormats={ [] }
					/>
					<RichText
						tagName="h2"
						className="features-block__title"
						value={ sectionTitle }
						onChange={ (val) => setAttributes({ sectionTitle: val }) }
						placeholder={ __('Section title…', 'features-section') }
						allowedFormats={ ['core/bold', 'core/italic'] }
					/>
					<RichText
						tagName="p"
						className="features-block__description"
						value={ sectionDescription }
						onChange={ (val) => setAttributes({ sectionDescription: val }) }
						placeholder={ __('Section description…', 'features-section') }
						allowedFormats={ ['core/bold', 'core/italic'] }
					/>
				</div>

				<div className="features-block__grid">
					{ cards.map((card, cardIndex) => (
						<div key={ card.id } className="features-block__card">
							<div className="features-block__card-toolbar">
								<Tooltip text={ __('Click icon to cycle through icon styles', 'features-section') }>
									<button
										className="features-block__icon-btn"
										onClick={ () => cycleIcon(cardIndex) }
										aria-label={ __('Change icon', 'features-section') }
									>
										{ ICONS[card.icon] || ICONS.precision }
									</button>
								</Tooltip>
								<Tooltip text={ __('Remove card', 'features-section') }>
									<Button
										className="features-block__remove-card"
										icon={ trash }
										isDestructive
										onClick={ () => removeCard(cardIndex) }
										aria-label={ __('Remove card', 'features-section') }
									/>
								</Tooltip>
							</div>

							<RichText
								tagName="h3"
								className="features-block__card-title"
								value={ card.title }
								onChange={ (val) => updateCard(cardIndex, 'title', val) }
								placeholder={ __('Feature title…', 'features-section') }
								allowedFormats={ ['core/bold', 'core/italic'] }
							/>

							<RichText
								tagName="p"
								className="features-block__card-desc"
								value={ card.description }
								onChange={ (val) => updateCard(cardIndex, 'description', val) }
								placeholder={ __('Feature description…', 'features-section') }
								allowedFormats={ ['core/bold', 'core/italic'] }
							/>

							<ul className="features-block__specs">
								{ card.specs.map((spec, specIndex) => (
									<li key={ specIndex } className="features-block__spec-item">
										<RichText
											tagName="span"
											value={ spec }
											onChange={ (val) => updateSpec(cardIndex, specIndex, val) }
											placeholder={ __('Spec item…', 'features-section') }
											allowedFormats={ [] }
										/>
										<Tooltip text={ __('Remove spec', 'features-section') }>
											<Button
												className="features-block__remove-spec"
												icon={ trash }
												isSmall
												isDestructive
												onClick={ () => removeSpec(cardIndex, specIndex) }
												aria-label={ __('Remove spec', 'features-section') }
											/>
										</Tooltip>
									</li>
								)) }
							</ul>

							<Button
								className="features-block__add-spec"
								icon={ plus }
								isSmall
								variant="tertiary"
								onClick={ () => addSpec(cardIndex) }
							>
								{ __('Add spec', 'features-section') }
							</Button>
						</div>
					)) }
				</div>

				<div className="features-block__add-card-wrap">
					<Button
						className="features-block__add-card"
						icon={ plus }
						variant="primary"
						onClick={ addCard }
					>
						{ __('Add Feature Card', 'features-section') }
					</Button>
				</div>
			</div>
		</section>
	);
}
