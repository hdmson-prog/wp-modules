<?php
/**
 * Features Section Block — render.php
 *
 * @param array    $attributes Block attributes saved in the editor.
 * @param string   $content    Inner blocks content (unused for this block).
 * @param WP_Block $block      Block instance.
 */

$section_label      = isset( $attributes['sectionLabel'] )      ? $attributes['sectionLabel']      : '';
$section_title      = isset( $attributes['sectionTitle'] )      ? $attributes['sectionTitle']      : '';
$section_description = isset( $attributes['sectionDescription'] ) ? $attributes['sectionDescription'] : '';
$cards              = isset( $attributes['cards'] )             ? $attributes['cards']             : [];

// Map icon keys to inline SVG markup.
$icons = [
	'precision' => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
		<circle cx="24" cy="24" r="20" stroke="currentColor" stroke-width="2"/>
		<circle cx="24" cy="24" r="12" stroke="currentColor" stroke-width="2"/>
		<circle cx="24" cy="24" r="4" fill="currentColor"/>
		<line x1="24" y1="4" x2="24" y2="12" stroke="currentColor" stroke-width="2"/>
		<line x1="24" y1="36" x2="24" y2="44" stroke="currentColor" stroke-width="2"/>
		<line x1="4" y1="24" x2="12" y2="24" stroke="currentColor" stroke-width="2"/>
		<line x1="36" y1="24" x2="44" y2="24" stroke="currentColor" stroke-width="2"/>
	</svg>',
	'lifespan'  => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
		<path d="M8 24L16 16L24 24L32 16L40 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
		<path d="M8 32L16 24L24 32L32 24L40 32" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
		<rect x="6" y="8" width="36" height="32" stroke="currentColor" stroke-width="2" rx="2"/>
	</svg>',
	'load'      => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
		<rect x="8" y="12" width="32" height="24" stroke="currentColor" stroke-width="2" rx="2"/>
		<path d="M16 12V8C16 6.89543 16.8954 6 18 6H30C31.1046 6 32 6.89543 32 8V12" stroke="currentColor" stroke-width="2"/>
		<circle cx="24" cy="24" r="4" stroke="currentColor" stroke-width="2"/>
		<path d="M24 28V32" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
	</svg>',
	'prototype' => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
		<circle cx="24" cy="24" r="18" stroke="currentColor" stroke-width="2"/>
		<path d="M24 12V24L32 28" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
	</svg>',
	'quality'   => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
		<path d="M24 8L32 16L24 24L16 16L24 8Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
		<path d="M24 24L32 32L24 40L16 32L24 24Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
		<path d="M8 24L16 16V32L8 24Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
		<path d="M40 24L32 16V32L40 24Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
	</svg>',
	'environment' => '<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
		<path d="M24 4L8 12V24C8 34 16 42 24 44C32 42 40 34 40 24V12L24 4Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
		<path d="M18 24L22 28L30 20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
	</svg>',
];

$wrapper_attributes = get_block_wrapper_attributes( [ 'class' => 'features-section' ] );
?>

<section <?php echo $wrapper_attributes; ?>>
	<div class="container">

		<div class="section-header">
			<?php if ( $section_label ) : ?>
				<p class="section-label"><?php echo wp_kses_post( $section_label ); ?></p>
			<?php endif; ?>

			<?php if ( $section_title ) : ?>
				<h2 class="section-title"><?php echo wp_kses_post( $section_title ); ?></h2>
			<?php endif; ?>

			<?php if ( $section_description ) : ?>
				<p class="section-description"><?php echo wp_kses_post( $section_description ); ?></p>
			<?php endif; ?>
		</div>

		<?php if ( ! empty( $cards ) ) : ?>
			<div class="features-grid">
				<?php foreach ( $cards as $card ) :
					$icon_key   = isset( $card['icon'] )        ? $card['icon']        : 'precision';
					$title      = isset( $card['title'] )       ? $card['title']       : '';
					$description = isset( $card['description'] ) ? $card['description'] : '';
					$specs      = isset( $card['specs'] )       ? $card['specs']       : [];
					$icon_svg   = isset( $icons[ $icon_key ] )  ? $icons[ $icon_key ]  : $icons['precision'];
				?>
					<div class="feature-card">
						<div class="feature-icon">
							<?php echo $icon_svg; // Already sanitised — no user input ?>
						</div>

						<?php if ( $title ) : ?>
							<h3 class="feature-title"><?php echo wp_kses_post( $title ); ?></h3>
						<?php endif; ?>

						<?php if ( $description ) : ?>
							<p class="feature-description"><?php echo wp_kses_post( $description ); ?></p>
						<?php endif; ?>

						<?php if ( ! empty( $specs ) ) : ?>
							<ul class="feature-specs">
								<?php foreach ( $specs as $spec ) : ?>
									<li><?php echo esc_html( $spec ); ?></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

	</div>
</section>
