<?php
/**
 * Enqueue scripts and styles.
 *
 * @package WP_Starter
 */


/**
 * Enqueue frontend assets.
 */
function wp_starter_scripts()
{
	// Enqueue Google Fonts
	wp_enqueue_style('wp-starter-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Montserrat:wght@400;500;600;700&display=swap', array(), null);

	wp_enqueue_style('wp-starter-style', get_stylesheet_uri(), array(), WP_STARTER_VERSION);
	wp_enqueue_style('wp-starter-styles', get_template_directory_uri() . '/assets/css/styles.css', array(), WP_STARTER_VERSION);

	wp_enqueue_style('product-page-style', get_template_directory_uri() . '/assets/css/products-page.css');

	wp_enqueue_script('wp-starter-script', get_template_directory_uri() . '/assets/js/script.js', array(), WP_STARTER_VERSION, true);

	// Cookie Consent
	wp_enqueue_style('cookie-consent-style', get_template_directory_uri() . '/assets/css/cookie-consent.css', array(), WP_STARTER_VERSION);
	wp_enqueue_script('cookie-consent-script', get_template_directory_uri() . '/assets/js/cookie-consent.js', array(), WP_STARTER_VERSION, true);

	if (is_singular('product')) {

		wp_enqueue_style('single-product-style', get_template_directory_uri() . '/assets/css/product-detail.css', array(), WP_STARTER_VERSION);

		wp_enqueue_script('tqb-single-product-script', get_template_directory_uri() . '/assets/js/product-detail.js', array(), WP_STARTER_VERSION, true);
	}

	if (is_page('about') || is_page('关于我们')) {

		wp_enqueue_style('about-style', get_template_directory_uri() . '/assets/css/about.css');


	}

	if (is_page('contact') || is_page('联系我们')) {

		wp_enqueue_style('contact-styles', get_template_directory_uri() . '/assets/css/contact.css');

	}

	if (is_page_template('gallery.php')) {

		wp_enqueue_style('gallery-styles', get_template_directory_uri() . '/assets/css/gallery.css');

		wp_enqueue_script('gallery-script', get_template_directory_uri() . '/assets/js/gallery.js', array(), WP_STARTER_VERSION, true);

	}

	if (is_home() || is_archive()) {
		wp_enqueue_style('news-layout-styles', get_template_directory_uri() . '/assets/css/news.css');

		if (is_home()) {
			wp_enqueue_script('news-list-js', get_template_directory_uri() . '/assets/js/news.js', array(), WP_STARTER_VERSION, true);
		}
	}

	if (is_single()) {
		wp_enqueue_style('single-news-layout-styles', get_template_directory_uri() . '/assets/css/news-single.css');

	}
	if (is_page_template('template-login.php')) {
		wp_enqueue_style('login-styles', get_template_directory_uri() . '/assets/css/login.css');
	}

	if (is_404()) {
		wp_enqueue_style('404-styles', get_template_directory_uri() . '/assets/css/404.css');
	}
	if (is_search()) {
		wp_enqueue_style('search-styles', get_template_directory_uri() . '/assets/css/search-results.css');
		wp_enqueue_script('search-js', get_template_directory_uri() . '/assets/js/search-results.js', array(), WP_STARTER_VERSION, true);
	}


}
add_action('wp_enqueue_scripts', 'wp_starter_scripts');
