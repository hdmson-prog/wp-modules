<?php
/**
 * Theme setup.
 *
 * @package WP_Starter
 */


/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function wp_starter_setup()
{
	load_theme_textdomain('tqb', get_template_directory() . '/languages');

	add_theme_support('automatic-feed-links');
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
	add_theme_support('customize-selective-refresh-widgets');

	// Enqueue editor stylesheet so block editor inherits theme base styles

	register_nav_menus(
		array(
		'primary' => esc_html__('Primary Menu', 'tqb'),
		'footer' => esc_html__('Footer Menu', 'tqb'),
		'legal' => esc_html__('Legal', 'tqb')
	)
	);
}

add_action('after_setup_theme', 'wp_starter_setup');

/**
 * Ensure core post types always keep featured image support.
 */

function wp_starter_content_width()
{
	$GLOBALS['content_width'] = apply_filters('wp_starter_content_width', 800);
}
add_action('after_setup_theme', 'wp_starter_content_width', 0);
