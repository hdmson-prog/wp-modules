<?php
/**
 * The template for displaying all single posts.
 *
 * @package WP_Starter
 */

get_header();
tqb_page_banner();
?>

<article class="news-article">
        <div class="container">


            <header class="article-header">
                <div class="article-meta">
                    <span class="article-category" id="categoryBadge"><?php echo get_the_category_list(', '); ?></span>
                    <span class="article-date" id="articleDate"><?php echo get_the_time(get_option('date_format')); ?></span>
                    <!-- <span class="article-read-time">5 min read</span> -->
                </div>
                <h1 class="article-title" id="articleTitle"><?php echo get_the_title(); ?></h1>
                <p class="article-excerpt" id="articleExcerpt"><?php echo mb_strimwidth(strip_tags(get_the_content()), 0, 150, '...'); ?></p>
            </header>

            <div class="article-layout">

                <aside class="article-sidebar">
                   
                    <div class="sidebar-widget">
                        <h3><?php esc_html_e('Share This Article', 'tqb'); ?></h3>
                        <div class="share-buttons">
                            <?php
$share_url = rawurlencode(get_permalink());
$share_title = rawurlencode(get_the_title());
?>
                            <a href="<?php echo esc_url('https://www.linkedin.com/shareArticle?mini=true&url=' . $share_url . '&title=' . $share_title); ?>" class="share-btn" aria-label="<?php esc_attr_e('Share on LinkedIn', 'tqb'); ?>">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6 8H2V22H6V8Z" fill="currentColor"></path>
                                    <path d="M4 6C5.10457 6 6 5.10457 6 4C6 2.89543 5.10457 2 4 2C2.89543 2 2 2.89543 2 4C2 5.10457 2.89543 6 4 6Z" fill="currentColor"></path>
                                    <path d="M22 13C22 10 20 8 17 8C15 8 14 9 14 9V8H10V22H14V14C14 13 15 12 16 12C17 12 18 12.5 18 14V22H22V13Z" fill="currentColor"></path>
                                </svg>
                            </a>
                            <a href="<?php echo esc_url('https://twitter.com/share?url=' . $share_url . '&title=' . $share_title); ?>" class="share-btn" aria-label="<?php esc_attr_e('Share on Twitter', 'tqb'); ?>">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M19 3H21.75L15 11.5L24 21H17L11.5 14.5L5.25 21H2.5L9.75 11.875L1 3H8.25L13.25 8.91667L19 3ZM17.75 19H19.75L7.25 5H5.08333L17.75 19Z" fill="currentColor"></path>
                                </svg>
                            </a>
                            <a href="<?php echo esc_url('https://www.facebook.com/sharer/sharer.php?u=' . $share_url); ?>" class="share-btn" aria-label="<?php esc_attr_e('Share on Facebook', 'tqb'); ?>">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M24 12C24 5.37258 18.6274 0 12 0C5.37258 0 0 5.37258 0 12C0 17.9895 4.3882 22.954 10.125 23.8542V15.4688H7.07812V12H10.125V9.35625C10.125 6.34875 11.9166 4.6875 14.6576 4.6875C15.9701 4.6875 17.3438 4.92188 17.3438 4.92188V7.875H15.8306C14.34 7.875 13.875 8.80001 13.875 9.75V12H17.2031L16.6711 15.4688H13.875V23.8542C19.6118 22.954 24 17.9895 24 12Z" fill="currentColor"></path>
                                </svg>
                            </a>
                        </div>
                    </div>

                    <div class="sidebar-widget">
                        <h3><?php esc_html_e('Categories', 'tqb'); ?></h3>
                        <ul class="category-list">
                            <?php
$categories = get_the_category();
foreach ($categories as $category) {
    echo '<li><a href="' . esc_url(get_category_link($category->term_id)) . '">' . esc_html($category->name) . '</a></li>';
}
?>
                        </ul>
                    </div>
                </aside>

                <div class="article-content">
                    <div class="article-featured-image">
                        <?php the_post_thumbnail(); ?>
                    </div>

                    <div class="article-body">
                        <?php the_content(); ?>

                        <div class="article-cta">
                            <h3><?php esc_html_e('Learn More About Our Wheel Hub Bearings?', 'tqb'); ?></h3>
                            <p><?php esc_html_e('Contact us today to discuss how our bearing technology can benefit your electric vehicle program?', 'tqb'); ?></p>
                            <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary"><?php esc_html_e('Contact Us', 'tqb'); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </article>

<?php

get_footer();
