// News Data
const newsData = [
    {
        id: 1,
        category: 'innovation',
        title: 'Next-Gen EV Bearing Technology Reduces Friction by 30%',
        excerpt: 'Our engineering team has developed a breakthrough bearing design specifically optimized for electric vehicle e-axle systems. The new EV-Optimized E-Drive Hub features advanced surface treatments and innovative sealing technology that significantly reduces energy loss.',
        date: 'January 5, 2026',
        badge: 'featured',
        badgeText: 'Featured'
    },
    {
        id: 2,
        category: 'press',
        title: 'ISO/TS 16949 Certification Renewed for 2026',
        excerpt: 'We\'re proud to announce the successful renewal of our ISO/TS 16949 certification, demonstrating our continued commitment to automotive quality management excellence.',
        date: 'January 3, 2026',
        badge: '',
        badgeText: 'Press Release'
    },
    {
        id: 3,
        category: 'technical',
        title: 'Understanding Load Distribution in Gen3 Hub Bearings',
        excerpt: 'A comprehensive technical guide exploring how optimized internal geometry improves load distribution and extends service life in modern wheel hub bearings.',
        date: 'December 28, 2025',
        badge: '',
        badgeText: 'Technical'
    },
    {
        id: 4,
        category: 'events',
        title: 'Visit Us at Automotive Manufacturing Expo 2026',
        excerpt: 'Join us at booth A-247 to see live demonstrations of our latest bearing technology and meet our engineering team. March 15-18, Detroit, MI.',
        date: 'December 25, 2025',
        badge: '',
        badgeText: 'Event'
    },
    {
        id: 5,
        category: 'company',
        title: '50 Million Units Milestone Reached',
        excerpt: 'A testament to quality and reliability - we\'ve successfully delivered over 50 million wheel hub bearings to customers worldwide since our founding.',
        date: 'December 20, 2025',
        badge: '',
        badgeText: 'Company News'
    },
    {
        id: 6,
        category: 'innovation',
        title: 'New Manufacturing Process Increases Production Capacity by 40%',
        excerpt: 'Implementation of advanced automation and lean manufacturing principles has significantly increased our production capacity while maintaining our strict quality standards.',
        date: 'December 15, 2025',
        badge: '',
        badgeText: 'Innovation'
    },
    {
        id: 7,
        category: 'technical',
        title: 'White Paper: Bearing Performance in Extreme Temperatures',
        excerpt: 'New research document explores bearing performance characteristics under extreme temperature conditions from -40°C to +180°C.',
        date: 'December 10, 2025',
        badge: '',
        badgeText: 'Technical'
    },
    {
        id: 8,
        category: 'press',
        title: 'Partnership Announced with Leading EV Manufacturer',
        excerpt: 'Strategic partnership to develop next-generation bearing solutions for electric vehicle platforms, focusing on efficiency and durability.',
        date: 'December 5, 2025',
        badge: '',
        badgeText: 'Press Release'
    },
    {
        id: 9,
        category: 'company',
        title: 'Employee Recognition Program Celebrates Excellence',
        excerpt: 'Honoring team members who have demonstrated exceptional commitment to quality and innovation throughout 2025.',
        date: 'December 1, 2025',
        badge: '',
        badgeText: 'Company News'
    },
    {
        id: 10,
        category: 'events',
        title: 'Webinar: Future of Bearing Technology in EVs',
        excerpt: 'Join our CTO Dr. Sarah Williams for an exclusive online presentation about the future of bearing technology in electric vehicles. Free registration.',
        date: 'November 28, 2025',
        badge: '',
        badgeText: 'Event'
    }
];

// Pagination settings
const itemsPerPage = 6;
let currentPage = 1;
let currentCategory = 'all';
let filteredData = [...newsData];

// Initialize news list
function initNews() {
    renderNews();
    renderPagination();
    setupFilterButtons();
}

// Filter news
function filterNews(category) {
    currentCategory = category;
    currentPage = 1;
    
    if (category === 'all') {
        filteredData = [...newsData];
    } else {
        filteredData = newsData.filter(item => item.category === category);
    }
    
    renderNews();
    renderPagination();
}

// Render news items
function renderNews() {
    const newsList = document.getElementById('newsList');
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageItems = filteredData.slice(startIndex, endIndex);
    
    newsList.innerHTML = '';
    
    pageItems.forEach((item, index) => {
        const newsItem = document.createElement('div');
        newsItem.className = 'news-list-item';
        newsItem.style.animationDelay = `${index * 0.1}s`;
        
        newsItem.innerHTML = `
            <div class="news-list-image">
                ${item.badge === 'featured' ? '<span class="news-list-badge featured">Featured</span>' : ''}
                <svg width="120" height="120" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="20" y="30" width="80" height="60" rx="4" stroke="#1D4E89" stroke-width="2"/>
                    <path d="M30 40 L50 50 M70 40 L90 50" stroke="#1D4E89" stroke-width="2"/>
                    <path d="M30 55 L90 55 M30 65 L80 65 M30 75 L85 75" stroke="#1D4E89" stroke-width="2"/>
                </svg>
            </div>
            <div class="news-list-content">
                <div class="news-list-meta">
                    <span class="news-list-category">${item.category.charAt(0).toUpperCase() + item.category.slice(1)}</span>
                    <span class="news-list-date">${item.date}</span>
                </div>
                <h2 class="news-list-title">
                    <a href="news-single.html?id=${item.id}">${item.title}</a>
                </h2>
                <p class="news-list-excerpt">${item.excerpt}</p>
                <a href="news-single.html?id=${item.id}" class="news-list-link">Read Full Article →</a>
            </div>
        `;
        
        newsList.appendChild(newsItem);
    });
}

// Render pagination
function renderPagination() {
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    const paginationNumbers = document.getElementById('paginationNumbers');
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');
    
    // Update button states
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;
    
    // Render page numbers
    paginationNumbers.innerHTML = '';
    
    for (let i = 1; i <= totalPages; i++) {
        if (
            i === 1 ||
            i === totalPages ||
            (i >= currentPage - 1 && i <= currentPage + 1)
        ) {
            const pageBtn = document.createElement('button');
            pageBtn.className = 'pagination-number';
            pageBtn.textContent = i;
            if (i === currentPage) pageBtn.classList.add('active');
            
            pageBtn.addEventListener('click', () => {
                currentPage = i;
                renderNews();
                renderPagination();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
            
            paginationNumbers.appendChild(pageBtn);
        } else if (
            i === currentPage - 2 ||
            i === currentPage + 2
        ) {
            const dots = document.createElement('span');
            dots.textContent = '...';
            dots.style.padding = '0 0.5rem';
            dots.style.color = 'var(--color-text-light)';
            paginationNumbers.appendChild(dots);
        }
    }
    
    // Setup navigation
    prevBtn.onclick = () => {
        if (currentPage > 1) {
            currentPage--;
            renderNews();
            renderPagination();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };
    
    nextBtn.onclick = () => {
        if (currentPage < totalPages) {
            currentPage++;
            renderNews();
            renderPagination();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };
}

// Setup filter buttons
function setupFilterButtons() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterNews(btn.getAttribute('data-category'));
        });
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', initNews);
