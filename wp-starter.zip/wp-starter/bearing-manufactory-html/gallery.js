// Gallery Data
const galleryData = [
    { id: 1, category: 'facilities', title: 'Manufacturing Facility', description: 'State-of-the-art 50,000 sq ft manufacturing facility' },
    { id: 2, category: 'facilities', title: 'Production Floor', description: 'Automated production lines with advanced machinery' },
    { id: 3, category: 'products', title: 'Gen3 Compact Hub Bearing', description: 'High-performance passenger vehicle bearing' },
    { id: 4, category: 'products', title: 'Heavy Duty Series', description: 'Industrial-grade bearing for commercial vehicles' },
    { id: 5, category: 'manufacturing', title: 'CNC Machining Center', description: 'Precision 5-axis CNC grinding operations' },
    { id: 6, category: 'manufacturing', title: 'Assembly Line', description: 'Automated bearing assembly process' },
    { id: 7, category: 'quality', title: 'Quality Control Lab', description: 'CMM inspection and acoustic testing' },
    { id: 8, category: 'quality', title: 'Testing Equipment', description: 'Vibration analysis and fatigue testing' },
    { id: 9, category: 'team', title: 'Engineering Team', description: 'Dedicated R&D and product development team' },
    { id: 10, category: 'team', title: 'Quality Assurance', description: '100% inspection protocol team' },
    { id: 11, category: 'facilities', title: 'R&D Center', description: 'Advanced research and development facility' },
    { id: 12, category: 'facilities', title: 'Warehouse', description: 'Temperature-controlled storage facility' },
    { id: 13, category: 'products', title: 'EV-Optimized E-Drive', description: 'Next-generation electric vehicle bearing' },
    { id: 14, category: 'products', title: 'Precision Tapered Roller', description: 'Classic tapered roller design' },
    { id: 15, category: 'manufacturing', title: 'Heat Treatment', description: 'Controlled atmosphere furnaces' },
    { id: 16, category: 'manufacturing', title: 'Surface Grinding', description: 'Sub-micron precision grinding' },
    { id: 17, category: 'quality', title: 'Dimensional Inspection', description: 'Automated optical inspection system' },
    { id: 18, category: 'quality', title: 'Material Testing', description: 'Metallurgical analysis laboratory' },
    { id: 19, category: 'team', title: 'Production Staff', description: 'Skilled manufacturing technicians' },
    { id: 20, category: 'team', title: 'Leadership Team', description: 'Executive management and department heads' },
    { id: 21, category: 'facilities', title: 'Office Building', description: 'Administrative and engineering offices' },
    { id: 22, category: 'products', title: 'Off-Road Sealed Bearing', description: 'Ruggedized bearing for harsh environments' },
    { id: 23, category: 'manufacturing', title: 'Packaging Line', description: 'Automated packaging and labeling' },
    { id: 24, category: 'quality', title: 'ISO Certification', description: 'ISO 9001:2015 compliance documentation' },
];

// Pagination settings
const itemsPerPage = 12;
let currentPage = 1;
let currentCategory = 'all';
let filteredData = [...galleryData];

// Initialize gallery
function initGallery() {
    renderGallery();
    renderPagination();
    setupFilterButtons();
    setupLightbox();
}

// Filter gallery
function filterGallery(category) {
    currentCategory = category;
    currentPage = 1;
    
    if (category === 'all') {
        filteredData = [...galleryData];
    } else {
        filteredData = galleryData.filter(item => item.category === category);
    }
    
    renderGallery();
    renderPagination();
}

// Render gallery items
function renderGallery() {
    const galleryGrid = document.getElementById('galleryGrid');
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageItems = filteredData.slice(startIndex, endIndex);
    
    galleryGrid.innerHTML = '';
    
    pageItems.forEach((item, index) => {
        const galleryItem = document.createElement('div');
        galleryItem.className = 'gallery-item';
        galleryItem.style.animationDelay = `${index * 0.05}s`;
        galleryItem.setAttribute('data-index', startIndex + index);
        
        galleryItem.innerHTML = `
            <div class="gallery-item-image">
                <svg width="120" height="120" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="20" y="20" width="80" height="60" rx="4" stroke="#1D4E89" stroke-width="2"/>
                    <circle cx="40" cy="40" r="8" fill="#1D4E89"/>
                    <path d="M20 70 L40 50 L60 70 L80 50 L100 70" stroke="#1D4E89" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            <div class="gallery-item-overlay">
                <div class="gallery-item-title">${item.title}</div>
                <div class="gallery-item-category">${item.category}</div>
            </div>
        `;
        
        galleryItem.addEventListener('click', () => openLightbox(startIndex + index));
        galleryGrid.appendChild(galleryItem);
    });
}

// Render pagination
function renderPagination() {
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    const paginationNumbers = document.getElementById('paginationNumbers');
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');
    
    // Update button states
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;
    
    // Render page numbers
    paginationNumbers.innerHTML = '';
    
    for (let i = 1; i <= totalPages; i++) {
        if (
            i === 1 ||
            i === totalPages ||
            (i >= currentPage - 1 && i <= currentPage + 1)
        ) {
            const pageBtn = document.createElement('button');
            pageBtn.className = 'pagination-number';
            pageBtn.textContent = i;
            if (i === currentPage) pageBtn.classList.add('active');
            
            pageBtn.addEventListener('click', () => {
                currentPage = i;
                renderGallery();
                renderPagination();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
            
            paginationNumbers.appendChild(pageBtn);
        } else if (
            i === currentPage - 2 ||
            i === currentPage + 2
        ) {
            const dots = document.createElement('span');
            dots.textContent = '...';
            dots.style.padding = '0 0.5rem';
            dots.style.color = 'var(--color-text-light)';
            paginationNumbers.appendChild(dots);
        }
    }
    
    // Setup navigation
    prevBtn.onclick = () => {
        if (currentPage > 1) {
            currentPage--;
            renderGallery();
            renderPagination();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };
    
    nextBtn.onclick = () => {
        if (currentPage < totalPages) {
            currentPage++;
            renderGallery();
            renderPagination();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };
}

// Setup filter buttons
function setupFilterButtons() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterGallery(btn.getAttribute('data-category'));
        });
    });
}

// Lightbox functionality
let currentLightboxIndex = 0;

function setupLightbox() {
    const lightbox = document.getElementById('lightbox');
    const lightboxClose = document.getElementById('lightboxClose');
    const lightboxPrev = document.getElementById('lightboxPrev');
    const lightboxNext = document.getElementById('lightboxNext');
    
    lightboxClose.addEventListener('click', closeLightbox);
    lightboxPrev.addEventListener('click', () => navigateLightbox(-1));
    lightboxNext.addEventListener('click', () => navigateLightbox(1));
    
    // Close on overlay click
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox) {
            closeLightbox();
        }
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (!lightbox.classList.contains('active')) return;
        
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') navigateLightbox(-1);
        if (e.key === 'ArrowRight') navigateLightbox(1);
    });
}

function openLightbox(index) {
    currentLightboxIndex = index;
    const lightbox = document.getElementById('lightbox');
    const item = filteredData[index];
    
    document.getElementById('lightboxTitle').textContent = item.title;
    document.getElementById('lightboxDescription').textContent = item.description;
    document.getElementById('lightboxCounter').textContent = `${index + 1} / ${filteredData.length}`;
    
    // In production, this would load the actual image
    const lightboxImage = document.getElementById('lightboxImage');
    lightboxImage.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAwIiBoZWlnaHQ9IjYwMCIgdmlld0JveD0iMCAwIDgwMCA2MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjgwMCIgaGVpZ2h0PSI2MDAiIGZpbGw9IiNlOWVjZWYiLz48cmVjdCB4PSIyMDAiIHk9IjE1MCIgd2lkdGg9IjQwMCIgaGVpZ2h0PSIzMDAiIHJ4PSI4IiBzdHJva2U9IiMxRDRFODkiIHN0cm9rZS13aWR0aD0iNCIvPjxjaXJjbGUgY3g9IjMwMCIgY3k9IjI1MCIgcj0iNDAiIGZpbGw9IiMxRDRFODkiLz48cGF0aCBkPSJNMjAwIDQwMCBMMzAwIDMwMCBMNDAwIDQwMCBMNTAwIDMwMCBMNjAwIDQwMCIgc3Ryb2tlPSIjMUQ0RTg5IiBzdHJva2Utd2lkdGg9IjQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPjwvc3ZnPg==';
    lightboxImage.alt = item.title;
    
    lightbox.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    lightbox.classList.remove('active');
    document.body.style.overflow = '';
}

function navigateLightbox(direction) {
    currentLightboxIndex += direction;
    
    if (currentLightboxIndex < 0) {
        currentLightboxIndex = filteredData.length - 1;
    } else if (currentLightboxIndex >= filteredData.length) {
        currentLightboxIndex = 0;
    }
    
    openLightbox(currentLightboxIndex);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', initGallery);
