// Product Detail Page JavaScript

// Thumbnail Gallery
const thumbnails = document.querySelectorAll('.thumbnail');
const mainImage = document.querySelector('.main-image-placeholder');

if (thumbnails.length > 0 && mainImage) {
    thumbnails.forEach((thumb, index) => {
        thumb.addEventListener('click', () => {
            // Remove active class from all thumbnails
            thumbnails.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked thumbnail
            thumb.classList.add('active');
            
            // Update main image (in real implementation, you'd swap actual images)
            mainImage.style.opacity = '0';
            setTimeout(() => {
                mainImage.innerHTML = thumb.innerHTML;
                mainImage.querySelector('svg').setAttribute('width', '400');
                mainImage.querySelector('svg').setAttribute('height', '400');
                mainImage.style.opacity = '1';
            }, 200);
        });
    });
}

// Product Tabs
const tabBtns = document.querySelectorAll('.tab-btn');
const tabPanes = document.querySelectorAll('.tab-pane');

if (tabBtns.length > 0) {
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetTab = btn.getAttribute('data-tab');
            
            // Remove active class from all buttons and panes
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            
            // Add active class to clicked button and corresponding pane
            btn.classList.add('active');
            const targetPane = document.getElementById(targetTab);
            if (targetPane) {
                targetPane.classList.add('active');
            }
        });
    });
}
