<?php

/**
 * Enable SVG Uploads
 */
function wps_enable_svg_upload($mimes)
{
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'wps_enable_svg_upload');

/**
 * Fix SVG display in WordPress Media Library
 */
function wps_fix_svg_thumb_display()
{
    echo '<style>
		td.media-icon img[src$=".svg"], img[src$=".svg"].attachment-post-thumbnail {
			width: 100% !important;
			height: auto !important;
		}
	</style>';
}
add_action('admin_head', 'wps_fix_svg_thumb_display');

/**
 * Get theme option using WP Rapid Fields framework.
 *
 * @param string $option_name
 * @param mixed $default
 * @return mixed
 */

function ws_get_option($option_name, $default = '')
{
    // Determine the language-aware option key
    $suffix = '';
    if (function_exists('pll_current_language')) {
        $lang = pll_current_language('slug');
        if ($lang) {
            $suffix = '_' . $lang;
        }
    }

    // Try language-specific option first
    if ($suffix) {
        $options = get_option('tqb_options_opts' . $suffix, []);
        if (is_array($options) && isset($options[$option_name]) && $options[$option_name] !== '') {
            return $options[$option_name];
        }
    }

    // Fallback to default (no language suffix) for backward compatibility
    $options = get_option('tqb_options_opts', []);
    if (is_array($options) && isset($options[$option_name]) && $options[$option_name] !== '') {
        return $options[$option_name];
    }

    return $default;
}

/**
 * Get Polylang-aware post meta value.
 * Tries language-specific meta key first, falls back to base key.
 *
 * @param int    $post_id   Post ID
 * @param string $meta_key  Base meta key (without language suffix)
 * @param bool   $single    Whether to return a single value
 * @return mixed
 */
function ws_get_post_meta($post_id, $meta_key, $single = true)
{
    $suffix = '';
    if (function_exists('pll_current_language')) {
        $lang = pll_current_language('slug');
        if ($lang) {
            $suffix = '_' . $lang;
        }
    }

    // Try language-specific meta first
    if ($suffix) {
        $lang_key = $meta_key . $suffix;
        if (metadata_exists('post', $post_id, $lang_key)) {
            $val = get_post_meta($post_id, $lang_key, $single);
            if (!empty($val)) {
                return $val;
            }
        }
    }

    // Fallback to base meta key
    return get_post_meta($post_id, $meta_key, $single);
}

/**
 * Get Polylang-aware term meta value.
 * Tries language-specific meta key first, falls back to base key.
 *
 * @param int    $term_id   Term ID
 * @param string $meta_key  Base meta key (without language suffix)
 * @param bool   $single    Whether to return a single value
 * @return mixed
 */
function ws_get_term_meta($term_id, $meta_key, $single = true)
{
    $suffix = '';
    if (function_exists('pll_current_language')) {
        $lang = pll_current_language('slug');
        if ($lang) {
            $suffix = '_' . $lang;
        }
    }

    // Try language-specific meta first
    if ($suffix) {
        $lang_key = $meta_key . $suffix;
        if (metadata_exists('term', $term_id, $lang_key)) {
            $val = get_term_meta($term_id, $lang_key, $single);
            if (!empty($val)) {
                return $val;
            }
        }
    }

    // Fallback to base meta key
    return get_term_meta($term_id, $meta_key, $single);
}

/**
 * Get Polylang-aware user meta value.
 * Tries language-specific meta key first, falls back to base key.
 *
 * @param int    $user_id   User ID
 * @param string $meta_key  Base meta key (without language suffix)
 * @param bool   $single    Whether to return a single value
 * @return mixed
 */
function ws_get_user_meta($user_id, $meta_key, $single = true)
{
    $suffix = '';
    if (function_exists('pll_current_language')) {
        $lang = pll_current_language('slug');
        if ($lang) {
            $suffix = '_' . $lang;
        }
    }

    // Try language-specific meta first
    if ($suffix) {
        $lang_key = $meta_key . $suffix;
        if (metadata_exists('user', $user_id, $lang_key)) {
            $val = get_user_meta($user_id, $lang_key, $single);
            if (!empty($val)) {
                return $val;
            }
        }
    }

    // Fallback to base meta key
    return get_user_meta($user_id, $meta_key, $single);
}

//adjust the queries
add_action('pre_get_posts', 'adjust_product_query');

function adjust_product_query($query)
{

    if ($query->is_main_query() && !is_admin() && (is_post_type_archive('product') || is_tax('product_category'))) {

        $query->set('posts_per_page', '9');

    }

}

/**
 * Dynamic WordPress Pagination
 * Can be used with main query or any custom WP_Query
 *
 * @param WP_Query|null $custom_query  Pass a custom WP_Query object or null for main query
 * @param int           $range         Number of page numbers to show around current page
 */
function theme_pagination($custom_query = null, $range = 2)
{

    // Use custom query or fall back to main global query
    global $wp_query;
    $query = $custom_query ? $custom_query : $wp_query;

    $total_pages = (int)$query->max_num_pages;
    $current_page = $custom_query
        ? (int)$query->get('paged') ?: 1
        : max(1, get_query_var('paged'));

    // Don't render if only one page
    if ($total_pages <= 1) {
        return;
    }

    // Prev button
    $prev_disabled = $current_page <= 1 ? 'disabled' : '';
    $prev_url = $current_page > 1 ? get_pagenum_link($current_page - 1) : '#';

    // Next button
    $next_disabled = $current_page >= $total_pages ? 'disabled' : '';
    $next_url = $current_page < $total_pages ? get_pagenum_link($current_page + 1) : '#';

    // Build page number range
    $start = max(1, $current_page - $range);
    $end = min($total_pages, $current_page + $range);

?>
    <div class="archive-pagination">

        <!-- {{-- Prev Button --}} -->
        <button
            class="pagination-btn pagination-prev"
            <?php echo esc_attr($prev_disabled); ?>
            <?php if (!$prev_disabled): ?>
                onclick="window.location.href='<?php echo esc_url($prev_url); ?>'"
            <?php
    endif; ?>
        >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12.5 15L7.5 10L12.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <?php esc_html_e('Previous', 'tqb'); ?>
        </button>

        <!-- {{-- Page Numbers --}} -->
        <div class="pagination-numbers">

            <?php if ($start > 1): ?>
                <button
                    class="pagination-number"
                    onclick="window.location.href='<?php echo esc_url(get_pagenum_link(1)); ?>'"
                >1</button>

                <?php if ($start > 2): ?>
                    <span class="pagination-dots">...</span>
                <?php
        endif; ?>
            <?php
    endif; ?>

            <?php for ($i = $start; $i <= $end; $i++): ?>
                <button
                    class="pagination-number <?php echo $i === $current_page ? 'active' : ''; ?>"
                    <?php if ($i === $current_page): ?>
                        disabled
                    <?php
        else: ?>
                        onclick="window.location.href='<?php echo esc_url(get_pagenum_link($i)); ?>'"
                    <?php
        endif; ?>
                >
                    <?php echo esc_html($i); ?>
                </button>
            <?php
    endfor; ?>

            <?php if ($end < $total_pages): ?>
                <?php if ($end < $total_pages - 1): ?>
                    <span class="pagination-dots">...</span>
                <?php
        endif; ?>

                <button
                    class="pagination-number"
                    onclick="window.location.href='<?php echo esc_url(get_pagenum_link($total_pages)); ?>'"
                >
                    <?php echo esc_html($total_pages); ?>
                </button>
            <?php
    endif; ?>

        </div>

        <!-- {{-- Next Button --}} -->
        <button
            class="pagination-btn pagination-next"
            <?php echo esc_attr($next_disabled); ?>
            <?php if (!$next_disabled): ?>
                onclick="window.location.href='<?php echo esc_url($next_url); ?>'"
            <?php
    endif; ?>
        >
            <?php esc_html_e('Next', 'tqb'); ?>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>

    </div>
    <?php
}

/**
 * Dynamic Results Count
 * Can be used with main query or any custom WP_Query
 *
 * @param WP_Query|null $custom_query  Pass a custom WP_Query object or null for main query
 */
function theme_results_count($custom_query = null)
{

    global $wp_query;
    $query = $custom_query ? $custom_query : $wp_query;

    $total_posts = (int)$query->found_posts;
    $posts_per_page = (int)$query->get('posts_per_page');
    $current_page = $custom_query
        ? (int)$query->get('paged') ?: 1
        : max(1, get_query_var('paged'));

    // Calculate from/to range
    $from = (($current_page - 1) * $posts_per_page) + 1;
    $to = min($current_page * $posts_per_page, $total_posts);

    // Don't render if no results
    if ($total_posts <= 0) {
        return;
    }

?>
    <p class="results-count">
        <?php printf(
        esc_html__('Showing %s of %s results', 'tqb'),
        '<strong>' . esc_html($from . '-' . $to) . '</strong>',
        '<strong>' . esc_html($total_posts) . '</strong>'
    ); ?>
    </p>
    <?php
}