<?php

function tqb_widgets_init()
{
    register_sidebar(array(
        'name' => esc_html__('Primary Sidebar', 'tqb'),
        'id' => 'sidebar-1',
        'description' => esc_html__('Add widgets here.', 'tqb'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => esc_html__('Product Sidebar', 'tqb'),
        'id' => 'product-sidebar',
        'description' => esc_html__('Add widgets for the product archive here.', 'tqb'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => esc_html__('Footer Sidebar', 'tqb'),
        'id' => 'footer-sidebar',
        'description' => esc_html__('Footer Sidebar', 'tqb'),
        'before_widget' => '<div class="footer-column">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="footer-heading">',
        'after_title' => '</h4>'
    ));



}
add_action('widgets_init', 'tqb_widgets_init');

// Load widget class files (must be loaded before register_widget is called)
locate_template('/framework/widgets/class-footer-brand-widget.php', true, true);
locate_template('/framework/widgets/class-footer-nav-widget.php', true, true);
locate_template('/framework/widgets/class_footer_contact_widget.php', true, true);
locate_template('/framework/widgets/class-product-categories-widget.php', true, true);
locate_template('/framework/widgets/class_contact_assistance_widget.php', true, true);