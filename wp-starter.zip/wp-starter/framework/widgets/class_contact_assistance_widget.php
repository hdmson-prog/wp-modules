<?php
/**
 * Plugin Name: Contact Assistance Widget
 * Description: A dynamic "Need Assistance?" sidebar widget with editable contact info and SVG icons.
 * Version: 1.0.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) {
    exit;
}

class Contact_Assistance_Widget extends WP_Widget
{

    public function __construct()
    {
        parent::__construct(
            'contact_assistance_widget',
            __('Contact Assistance Widget', 'tqb'),
            array('description' => __('Displays contact info: email, phone, location and a CTA button.', 'tqb'))
        );
    }

    /**
     * Allowed SVG tags & attributes — used for both saving and outputting.
     */
    private function allowed_svg_tags()
    {
        return array(
            'svg' => array(
                'width' => true,
                'height' => true,
                'viewbox' => true, // wp_kses lowercases all attribute keys
                'fill' => true,
                'xmlns' => true,
                'class' => true,
                'aria-hidden' => true,
                'role' => true,
            ),
            'path' => array(
                'd' => true,
                'stroke' => true,
                'stroke-width' => true,
                'stroke-linecap' => true,
                'stroke-linejoin' => true,
                'fill' => true,
            ),
            'circle' => array(
                'cx' => true,
                'cy' => true,
                'r' => true,
                'stroke' => true,
                'stroke-width' => true,
                'fill' => true,
            ),
            'rect' => array(
                'x' => true,
                'y' => true,
                'width' => true,
                'height' => true,
                'rx' => true,
                'fill' => true,
                'stroke' => true,
                'stroke-width' => true,
            ),
            'line' => array(
                'x1' => true,
                'y1' => true,
                'x2' => true,
                'y2' => true,
                'stroke' => true,
                'stroke-width' => true,
            ),
            'polyline' => array(
                'points' => true,
                'stroke' => true,
                'stroke-width' => true,
                'fill' => true,
            ),
            'polygon' => array(
                'points' => true,
                'stroke' => true,
                'stroke-width' => true,
                'fill' => true,
            ),
        );
    }

    /**
     * Safely output an SVG string.
     * wp_kses lowercases attribute names, so we fix viewbox → viewBox after sanitising.
     */
    private function render_svg($svg)
    {
        $clean = wp_kses($svg, $this->allowed_svg_tags());
        // Restore the camelCase attribute that browsers require.
        $clean = str_replace(' viewbox=', ' viewBox=', $clean);
        echo $clean; // already sanitised — no further escaping needed
    }

    /**
     * Front-end display of widget.
     */
    public function widget($args, $instance)
    {
        $title = !empty($instance['title']) ? $instance['title'] : __('Need Assistance?', 'tqb');
        $email = !empty($instance['email']) ? $instance['email'] : '';
        $email_label = !empty($instance['email_label']) ? $instance['email_label'] : __('Email', 'tqb');
        $email_icon = !empty($instance['email_icon']) ? $instance['email_icon'] : $this->default_email_icon();
        $phone = !empty($instance['phone']) ? $instance['phone'] : '';
        $phone_label = !empty($instance['phone_label']) ? $instance['phone_label'] : __('Phone', 'tqb');
        $phone_icon = !empty($instance['phone_icon']) ? $instance['phone_icon'] : $this->default_phone_icon();
        $location = !empty($instance['location']) ? $instance['location'] : '';
        $location_label = !empty($instance['location_label']) ? $instance['location_label'] : __('Location', 'tqb');
        $location_icon = !empty($instance['location_icon']) ? $instance['location_icon'] : $this->default_location_icon();
        $cta_text = !empty($instance['cta_text']) ? $instance['cta_text'] : __('Request Quote', 'tqb');
        $cta_url = !empty($instance['cta_url']) ? $instance['cta_url'] : '#contact';




?>
        <div class="widget widget-contact">
            <h3 class="widget-title"><?php echo esc_html($title); ?></h3>
            <div class="contact-info">

                <?php if ($email): ?>
                <div class="contact-item">
                    <div class="contact-icon">
                        <?php $this->render_svg($email_icon); ?>
                    </div>
                    <div class="contact-details">
                        <span class="contact-label"><?php echo esc_html($email_label); ?></span>
                        <a href="mailto:<?php echo esc_attr($email); ?>" class="contact-value"><?php echo esc_html($email); ?></a>
                    </div>
                </div>
                <?php
        endif; ?>

                <?php if ($phone): ?>
                <div class="contact-item">
                    <div class="contact-icon">
                        <?php $this->render_svg($phone_icon); ?>
                    </div>
                    <div class="contact-details">
                        <span class="contact-label"><?php echo esc_html($phone_label); ?></span>
                        <a href="tel:<?php echo esc_attr(preg_replace('/[^+\d]/', '', $phone)); ?>" class="contact-value"><?php echo esc_html($phone); ?></a>
                    </div>
                </div>
                <?php
        endif; ?>

                <?php if ($location): ?>
                <div class="contact-item">
                    <div class="contact-icon">
                        <?php $this->render_svg($location_icon); ?>
                    </div>
                    <div class="contact-details">
                        <span class="contact-label"><?php echo esc_html($location_label); ?></span>
                        <span class="contact-value"><?php echo esc_html($location); ?></span>
                    </div>
                </div>
                <?php
        endif; ?>

            </div>

            <?php if ($cta_text && $cta_url): ?>
            <a href="<?php echo esc_url($cta_url); ?>" class="widget-cta"><?php echo esc_html($cta_text); ?></a>
            <?php
        endif; ?>
        </div>
        <?php



    }

    /**
     * Back-end widget form.
     */
    public function form($instance)
    {
        $fields = array(
            'title' => array('label' => __('Widget Title', 'tqb'), 'default' => __('Need Assistance?', 'tqb')),
            'email' => array('label' => __('Email Address', 'tqb'), 'default' => 'sales@precisionhub.com'),
            'email_label' => array('label' => __('Email Label', 'tqb'), 'default' => __('Email', 'tqb')),
            'email_icon' => array('label' => __('Email SVG Icon', 'tqb'), 'default' => $this->default_email_icon(), 'type' => 'textarea'),
            'phone' => array('label' => __('Phone Number', 'tqb'), 'default' => '+1 (555) 123-4567'),
            'phone_label' => array('label' => __('Phone Label', 'tqb'), 'default' => __('Phone', 'tqb')),
            'phone_icon' => array('label' => __('Phone SVG Icon', 'tqb'), 'default' => $this->default_phone_icon(), 'type' => 'textarea'),
            'location' => array('label' => __('Location Text', 'tqb'), 'default' => 'Detroit, Michigan, USA'),
            'location_label' => array('label' => __('Location Label', 'tqb'), 'default' => __('Location', 'tqb')),
            'location_icon' => array('label' => __('Location SVG Icon', 'tqb'), 'default' => $this->default_location_icon(), 'type' => 'textarea'),
            'cta_text' => array('label' => __('CTA Button Text', 'tqb'), 'default' => __('Request Quote', 'tqb')),
            'cta_url' => array('label' => __('CTA Button URL', 'tqb'), 'default' => '#contact'),
        );

        foreach ($fields as $key => $field) {
            $value = isset($instance[$key]) ? $instance[$key] : $field['default'];
            $id = $this->get_field_id($key);
            $name = $this->get_field_name($key);
            $type = isset($field['type']) ? $field['type'] : 'text';
?>
            <p>
                <label for="<?php echo esc_attr($id); ?>">
                    <?php echo esc_html($field['label']); ?>:
                </label>
                <?php if ($type === 'textarea'): ?>
                    <textarea
                        class="widefat"
                        id="<?php echo esc_attr($id); ?>"
                        name="<?php echo esc_attr($name); ?>"
                        rows="5"
                        style="font-family:monospace;font-size:11px;"
                    ><?php echo esc_textarea($value); ?></textarea>
                    <small style="color:#888;"><?php esc_html_e('Paste your custom SVG code here, or leave as default.', 'tqb'); ?></small>
                <?php
            else: ?>
                    <input
                        class="widefat"
                        type="text"
                        id="<?php echo esc_attr($id); ?>"
                        name="<?php echo esc_attr($name); ?>"
                        value="<?php echo esc_attr($value); ?>"
                    />
                <?php
            endif; ?>
            </p>
            <?php
        }
    }

    /**
     * Sanitize widget form values as they are saved.
     */
    public function update($new_instance, $old_instance)
    {
        $instance = array();

        $text_fields = array('title', 'email', 'email_label', 'phone', 'phone_label', 'location', 'location_label', 'cta_text', 'cta_url');
        foreach ($text_fields as $field) {
            $instance[$field] = sanitize_text_field($new_instance[$field] ?? '');
        }

        // SVG fields: sanitise with the shared allowed-tags list.
        $svg_fields = array('email_icon', 'phone_icon', 'location_icon');
        foreach ($svg_fields as $field) {
            $instance[$field] = wp_kses($new_instance[$field] ?? '', $this->allowed_svg_tags());
        }

        return $instance;
    }

    /* ---------------------------------------------------------------
     * Default SVG icon helpers
     * ------------------------------------------------------------- */

    private function default_email_icon()
    {
        return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3 8L10.89 13.26C11.5396 13.6778 12.4604 13.6778 13.11 13.26L21 8M5 19H19C20.1046 19 21 18.1046 21 17V7C21 5.89543 20.1046 5 19 5H5C3.89543 5 3 5.89543 3 7V17C3 18.1046 3.89543 19 5 19Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>';
    }

    private function default_phone_icon()
    {
        return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3 5C3 3.89543 3.89543 3 5 3H8.27924C8.70967 3 9.09181 3.27543 9.22792 3.68377L10.7257 8.17721C10.8831 8.64932 10.6694 9.16531 10.2243 9.38787L7.96701 10.5165C9.06925 12.9612 11.0388 14.9308 13.4835 16.033L14.6121 13.7757C14.8347 13.3306 15.3507 13.1169 15.8228 13.2743L20.3162 14.7721C20.7246 14.9082 21 15.2903 21 15.7208V19C21 20.1046 20.1046 21 19 21H18C9.71573 21 3 14.2843 3 6V5Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>';
    }

    private function default_location_icon()
    {
        return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2C8.13401 2 5 5.13401 5 9C5 14.25 12 22 12 22C12 22 19 14.25 19 9C19 5.13401 15.866 2 12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M12 11C13.1046 11 14 10.1046 14 9C14 7.89543 13.1046 7 12 7C10.8954 7 10 7.89543 10 9C10 10.1046 10.8954 11 12 11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>';
    }
}

/**
 * Register the widget.
 */
function register_contact_assistance_widget()
{
    register_widget('Contact_Assistance_Widget');
}
add_action('widgets_init', 'register_contact_assistance_widget');