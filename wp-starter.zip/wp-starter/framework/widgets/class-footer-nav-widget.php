<?php
/**
 * Plugin Name: Footer Navigation Widget
 * Description: A dynamic footer navigation widget with selectable WordPress menu.
 * Version: 1.0.0
 * Author: Your Name
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Footer_Nav_Widget Class
 */
class Footer_Nav_Widget extends WP_Widget
{

    public function __construct()
    {
        parent::__construct(
            'footer_nav_widget',
            __('Footer Navigation Column', 'tqb'),
            array(
            'description' => __('Displays a footer column with a heading and a selected navigation menu.', 'tqb'),
            'classname' => 'tqb',
        )
        );
    }

    /**
     * Front-end display of the widget.
     *
     * @param array $args     Widget display arguments.
     * @param array $instance Saved widget settings.
     */
    public function widget($args, $instance)
    {
        $heading = !empty($instance['heading']) ? $instance['heading'] : __('Company', 'tqb');
        $menu_id = !empty($instance['menu_id']) ? (int)$instance['menu_id'] : 0;

        echo $args['before_widget'];
?>
        <div class="footer-column">
            <h4 class="footer-heading"><?php echo esc_html($heading); ?></h4>

            <?php if ($menu_id): ?>
                <ul class="footer-links">
                    <?php
            $menu_items = wp_get_nav_menu_items($menu_id);

            if ($menu_items) {
                foreach ($menu_items as $item) {
                    // Only render top-level items (menu_item_parent == 0)
                    if (0 == $item->menu_item_parent) {
                        printf(
                            '<li><a href="%s"%s>%s</a></li>',
                            esc_url($item->url),
                            ($item->classes ? ' class="' . esc_attr(implode(' ', $item->classes)) . '"' : ''),
                            esc_html($item->title)
                        );
                    }
                }
            }
            else {
                echo '<li>' . esc_html__('No menu items found.', 'tqb') . '</li>';
            }
?>
                </ul>
            <?php
        else: ?>
                <p><?php esc_html_e('Please select a navigation menu in the widget settings.', 'tqb'); ?></p>
            <?php
        endif; ?>
        </div>
        <?php
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form in the WordPress admin.
     *
     * @param array $instance Previously saved widget settings.
     */
    public function form($instance)
    {
        $heading = !empty($instance['heading']) ? $instance['heading'] : __('Company', 'tqb');
        $menu_id = !empty($instance['menu_id']) ? (int)$instance['menu_id'] : 0;

        // Get all registered navigation menus
        $menus = wp_get_nav_menus();
?>

        <!-- Heading Field -->
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('heading')); ?>">
                <?php esc_html_e('Column Heading:', 'tqb'); ?>
            </label>
            <input
                class="widefat"
                id="<?php echo esc_attr($this->get_field_id('heading')); ?>"
                name="<?php echo esc_attr($this->get_field_name('heading')); ?>"
                type="text"
                value="<?php echo esc_attr($heading); ?>"
            />
        </p>

        <!-- Menu Selector Field -->
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('menu_id')); ?>">
                <?php esc_html_e('Select Navigation Menu:', 'tqb'); ?>
            </label>
            <select
                class="widefat"
                id="<?php echo esc_attr($this->get_field_id('menu_id')); ?>"
                name="<?php echo esc_attr($this->get_field_name('menu_id')); ?>"
            >
                <option value="0"><?php esc_html_e('— Select a Menu —', 'tqb'); ?></option>
                <?php if ($menus): ?>
                    <?php foreach ($menus as $menu): ?>
                        <option
                            value="<?php echo esc_attr($menu->term_id); ?>"
                            <?php selected($menu_id, $menu->term_id); ?>
                        >
                            <?php echo esc_html($menu->name); ?>
                        </option>
                    <?php
            endforeach; ?>
                <?php
        else: ?>
                    <option value="0" disabled><?php esc_html_e('No menus found. Please create one first.', 'tqb'); ?></option>
                <?php
        endif; ?>
            </select>
        </p>

        <?php if (!$menus): ?>
            <p>
                <a href="<?php echo esc_url(admin_url('nav-menus.php')); ?>" target="_blank">
                    <?php esc_html_e('+ Create a Navigation Menu', 'tqb'); ?>
                </a>
            </p>
        <?php
        endif; ?>

        <?php
    }

    /**
     * Sanitize and save widget settings.
     *
     * @param array $new_instance New widget settings.
     * @param array $old_instance Old widget settings.
     * @return array Updated settings.
     */
    public function update($new_instance, $old_instance)
    {
        $instance = array();
        $instance['heading'] = sanitize_text_field($new_instance['heading']);
        $instance['menu_id'] = (int)$new_instance['menu_id'];

        return $instance;
    }
}

/**
 * Register the widget.
 */
function register_footer_nav_widget()
{
    register_widget('Footer_Nav_Widget');
}
add_action('widgets_init', 'register_footer_nav_widget');