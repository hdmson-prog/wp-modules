<?php

/**
 * Adds Foo_Widget widget.
 */
class Ws_Product_Categories extends WP_Widget
{
	/**
	 * Register widget with WordPress.
	 */
	public function __construct()
	{
		parent::__construct(
			'ws_product_categories', // Base ID
			'Ws_Product_Categories', // Name
			array('description' => __('Product Categories Widget', 'tqb')) // Args
		);
	}
	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget($args, $instance)
	{
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		$count = isset($instance['count']) ? $instance['count'] : 0;


?>
		<div class="widget widget-categories">
                        <h3 class="widget-title"><?php echo $title; ?></h3>
                        <ul class="category-list">

                        	<?php

		$posttype = 'product_category';
		$product_categories = get_terms(array(
			'taxonomy' => $posttype,
			'hide_empty' => false,
		));		$active = '';
		foreach ($product_categories as $cat) {
			//在自定义分类页面
			if (is_tax()) {
				$active = get_queried_object_id() === $cat->term_id ? 'active' : '';
			}
			elseif (is_singular()) {
				//在single product 页面 
				$active = has_term($cat->name, $posttype, get_the_ID()) ? 'active' : '';
			}


?>
                        	<li class="category-item <?php echo $active; ?>">
                                <a href="<?php echo get_term_link($cat); ?>">
                                    <span class="category-name"><?php echo $cat->name; ?></span>
                                   <?php if ($count) { ?> <span class="category-count"><?php echo $cat->count; ?></span> <?php
			}?>
                                </a>
                            </li>
                        		
                        <?php
		}

?>
                           
                        </ul>
                    </div>
	<?php
	}
	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form($instance)
	{
		if (isset($instance['title'])) {
			$title = $instance['title'];
		}
		else {
			$title = __('Products', 'tqb');
		}

		$count = isset($instance['count']) ? (bool)$instance['count'] : false;
?>
		<p>
			<label for="<?php echo $this->get_field_name('title'); ?>"><?php _e('Title:', 'tqb'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
		 </p>

		 <p>
			<label for="<?php echo $this->get_field_name('count'); ?>"><?php _e('Show Posts Count:', 'tqb'); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>" type="checkbox" <?php checked($count); ?> value="1" />
		 </p>
		<?php
	}
	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update($new_instance, $old_instance)
	{
		$instance = array();
		$instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
		$instance['count'] = !empty($new_instance['count']) ? 1 : 0;
		return $instance;
	}
}



// Register Foo_Widget widget
add_action('widgets_init', 'register_product_categories_widget');
function register_product_categories_widget()
{
	register_widget('Ws_Product_Categories');
}