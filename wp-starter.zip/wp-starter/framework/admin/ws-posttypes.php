<?php
/**
 * Register Custom Post Type: Product
 * Register Custom Taxonomy: Product Category
 */

// -----------------------------------------------
// 1. Register Custom Post Type: product
// -----------------------------------------------
function register_product_post_type()
{
    $labels = [
        'name' => _x('Products', 'Post type general name', 'tqb'),
        'singular_name' => _x('Product', 'Post type singular name', 'tqb'),
        'menu_name' => _x('Products', 'Admin Menu text', 'tqb'),
        'name_admin_bar' => _x('Product', 'Add New on Toolbar', 'tqb'),
        'add_new' => __('Add New', 'tqb'),
        'add_new_item' => __('Add New Product', 'tqb'),
        'new_item' => __('New Product', 'tqb'),
        'edit_item' => __('Edit Product', 'tqb'),
        'view_item' => __('View Product', 'tqb'),
        'all_items' => __('All Products', 'tqb'),
        'search_items' => __('Search Products', 'tqb'),
        'not_found' => __('No products found.', 'tqb'),
        'not_found_in_trash' => __('No products found in Trash.', 'tqb'),
        'featured_image' => __('Product Image', 'tqb'),
        'set_featured_image' => __('Set product image', 'tqb'),
        'remove_featured_image' => __('Remove product image', 'tqb'),
        'use_featured_image' => __('Use as product image', 'tqb'),
        'archives' => __('Product Archives', 'tqb'),
        'insert_into_item' => __('Insert into product', 'tqb'),
        'uploaded_to_this_item' => __('Uploaded to this product', 'tqb'),
    ];

    $args = [
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_rest' => true, // Enables Gutenberg & REST API support
        'query_var' => true,
        'rewrite' => ['slug' => 'products'],
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-cart',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
        'taxonomies' => ['product_category', 'post_tag'],
    ];

    register_post_type('product', $args);

    $labels = [
        'name' => _x('Product Categories', 'Taxonomy general name', 'tqb'),
        'singular_name' => _x('Product Category', 'Taxonomy singular name', 'tqb'),
        'search_items' => __('Search Product Categories', 'tqb'),
        'all_items' => __('All Product Categories', 'tqb'),
        'parent_item' => __('Parent Product Category', 'tqb'),
        'parent_item_colon' => __('Parent Product Category:', 'tqb'),
        'edit_item' => __('Edit Product Category', 'tqb'),
        'update_item' => __('Update Product Category', 'tqb'),
        'add_new_item' => __('Add New Product Category', 'tqb'),
        'new_item_name' => __('New Product Category Name', 'tqb'),
        'menu_name' => __('Product Categories', 'tqb'),
        'not_found' => __('No product categories found.', 'tqb'),
        'back_to_items' => __('← Go to Product Categories', 'tqb'),
    ];

    $args = [
        'labels' => $labels,
        'hierarchical' => true, // true = like Categories; false = like Tags
        'public' => true,
        'show_ui' => true,
        'show_admin_column' => true, // Shows taxonomy column in post list
        'show_in_rest' => true, // Enables Gutenberg & REST API support
        'query_var' => true,
        'rewrite' => ['slug' => 'product-category'],
    ];

    register_taxonomy('product_category', ['product'], $args);

    $labels = [
        'name' => _x('Downloads', 'Post type general name', 'tqb'),
        'singular_name' => _x('Download', 'Post type singular name', 'tqb'),
        'menu_name' => _x('Downloads', 'Admin Menu text', 'tqb'),
        'name_admin_bar' => _x('Download', 'Add New on Toolbar', 'tqb'),
        'add_new' => __('Add New', 'tqb'),
        'add_new_item' => __('Add New Download', 'tqb'),
        'new_item' => __('New Download', 'tqb'),
        'edit_item' => __('Edit Download', 'tqb'),
        'view_item' => __('View Download', 'tqb'),
        'all_items' => __('All Downloads', 'tqb'),
        'search_items' => __('Search Downloads', 'tqb'),
        'not_found' => __('No downloads found.', 'tqb'),
        'not_found_in_trash' => __('No downloads found in Trash.', 'tqb'),
        'featured_image' => __('Download Image', 'tqb'),
        'set_featured_image' => __('Set download image', 'tqb'),
        'remove_featured_image' => __('Remove download image', 'tqb'),
        'use_featured_image' => __('Use as download image', 'tqb'),
        'archives' => __('Download Archives', 'tqb'),
        'insert_into_item' => __('Insert into download', 'tqb'),
        'uploaded_to_this_item' => __('Uploaded to this download', 'tqb'),
    ];

    $args = [
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_rest' => true,
        'query_var' => true,
        'rewrite' => ['slug' => 'downloads'],
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => 6,
        'menu_icon' => 'dashicons-download',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
    ];

    register_post_type('download', $args);




}
add_action('init', 'register_product_post_type');
