<?php
/**
 * Initialize WP Rapid Fields for Theme Options
 * /**
 * 添加了新的字段关联函数
 * 
 * Bidirectional Sync for Product and Download
 * When you link a Download to a Product, the Product is automatically added to the Download's list.
 
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (class_exists('WP_Rapid_Fields_Pro')) {

    // Configuration for the Options Page
    $config = [
        'id' => 'tqb_options', // Unique ID for the options page
        'title' => __('Theme Options', 'tqb'), // Page Title
        'context' => 'option', // Setting this to 'option' creates an Admin Page
    ];

    // Define Tabs and Fields
    $tabs = [
        'general' => [
            'label' => __('General Information', 'tqb'),
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => __('Brand Identity', 'tqb')
                ],
                [
                    'id' => 'site_logo',
                    'type' => 'image',
                    'label' => __('Main Logo', 'tqb'),
                    'desc' => __('Upload the main logo for the site.', 'tqb'),
                    'return' => 'url',
                ],
                [
                    'id' => 'footer_logo',
                    'type' => 'image',
                    'label' => __('Footer Logo', 'tqb'),
                    'desc' => __('Upload the footer logo for the site.', 'tqb'),
                    'return' => 'url',
                ],
                [
                    'id' => 'company_profile_image',
                    'type' => 'image',
                    'label' => __('Company Profile Image', 'tqb'),
                    'desc' => __('Upload a profile image for the company (shown on the hero section).', 'tqb'),
                    'return' => 'url',
                ],
                [
                    'id' => 'site_logo_sticky',
                    'type' => 'image',
                    'label' => __('Sticky Header Logo', 'tqb'),
                    'desc' => __('Upload a specific logo for sticky header if needed.', 'tqb'),
                    'return' => 'id',
                ],
                [
                    'id' => 'site_favicon',
                    'type' => 'image',
                    'label' => __('Favicon', 'tqb'),
                    'desc' => __('Upload a 512x512 icon.', 'tqb'),
                    'return' => 'id',
                ],
                [
                    'id' => 'product_feature',
                    'type' => 'set',
                    'label' => __('Product Feature', 'tqb'),
                ]
            ]
        ],
        'contact' => [
            'label' => __('Contact', 'tqb'),
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => __('Contact Information', 'tqb')
                ],
                [
                    'id' => 'company_phone',
                    'type' => 'text',
                    'label' => __('Phone Number', 'tqb'),
                    'placeholder' => '+1 234 567 890',
                ],
                [
                    'id' => 'company_email',
                    'type' => 'set',
                    'label' => __('Email Address', 'tqb'),
                    'placeholder' => 'info@example.com',
                ],
                [
                    'id' => 'company_address',
                    'type' => 'textarea',
                    'label' => __('Physical Address', 'tqb'),
                ],
                [
                    'id' => 'google_map_embed',
                    'type' => 'textarea',
                    'label' => __('Google Maps Embed Code', 'tqb'),
                    'desc' => __('Paste the iframe code from Google Maps here.', 'tqb'),
                ],
                [
                    'id' => 'whatsapp_qrcode',
                    'type' => 'image',
                    'label' => __('WhatsApp QR Code', 'tqb'),
                    'desc' => __('Upload the WhatsApp QR code for the site.', 'tqb'),
                    'return' => 'url',
                ],
                [
                    'id' => 'wechat_qrcode',
                    'type' => 'image',
                    'label' => __('WeChat QR Code', 'tqb'),
                    'desc' => __('Upload the WeChat QR code for the site.', 'tqb'),
                    'return' => 'url',
                ]
            ]
        ],
        'social' => [
            'label' => __('Social Links', 'tqb'),
            'fields' => [
                [
                    'id' => 'social_links',
                    'type' => 'group',
                    'label' => __('Social Links', 'tqb'),
                    'desc' => __('Add your social media profiles. You can paste SVG code directly for the icons.', 'tqb'),
                    'button' => __('Add Social Link', 'tqb'),
                    'sub_fields' => [
                        [
                            'id' => 'title',
                            'type' => 'text',
                            'label' => __('Platform Name', 'tqb'),
                            'placeholder' => 'e.g. Facebook',
                        ],
                        [
                            'id' => 'url',
                            'type' => 'url',
                            'label' => __('Link URL', 'tqb'),
                            'placeholder' => 'https://...',
                        ],
                        [
                            'id' => 'icon',
                            'type' => 'textarea',
                            'label' => __('SVG Icon Code', 'tqb'),
                            'desc' => __('Paste the <svg> code here. <br><strong>Tip:</strong> Ensure the SVG has <code>width="18" height="18"</code> and <code>fill="currentColor"</code> for best results.', 'tqb'),
                        ],
                    ]
                ],
            ]
        ],
        'Homepage' => [
            'label' => __('Homepage', 'tqb'),
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => __('Hero Section', 'tqb')
                ],
                [
                    'id' => 'homepage_slider',
                    'type' => 'group',
                    'label' => __('Slider Slides', 'tqb'),
                    'button' => __('Add Slide', 'tqb'),
                    'sub_fields' => [
                        [
                            'id' => 'slide_tag',
                            'type' => 'text',
                            'label' => __('Tag', 'tqb'),
                        ],
                        [
                            'id' => 'slide_title',
                            'type' => 'text',
                            'label' => __('Title', 'tqb'),
                        ],
                        [
                            'id' => 'slide_desc',
                            'type' => 'textarea',
                            'label' => __('Description', 'tqb'),
                        ],
                        [
                            'id' => 'slide_btn_text',
                            'type' => 'text',
                            'label' => __('Button Text', 'tqb'),
                        ],
                        [
                            'id' => 'slide_btn_url',
                            'type' => 'text',
                            'label' => __('Button URL', 'tqb'),
                        ],
                        [
                            'id' => 'slide_image',
                            'type' => 'image',
                            'label' => __('Slide Image', 'tqb'),
                            'return' => 'url',
                        ],
                    ]
                ],
                [
                    'type' => 'heading',
                    'label' => __('Products Section', 'tqb')
                ],
                [
                    'id' => 'products_tag',
                    'type' => 'text',
                    'label' => __('Section Tag', 'tqb'),
                    'default' => __('Product Categories', 'tqb'),
                ],
                [
                    'id' => 'products_title',
                    'type' => 'text',
                    'label' => __('Section Title', 'tqb'),
                    'default' => __('Engineered for Global Markets', 'tqb'),
                ],
                [
                    'id' => 'products_desc',
                    'type' => 'textarea',
                    'label' => __('Section Description', 'tqb'),
                    'default' => __('Comprehensive product lines designed to meet international standards and diverse market requirements.', 'tqb'),
                ],



                [
                    'type' => 'heading',
                    'label' => __('Image Carousel Section', 'tqb')
                ],
                [
                    'id' => 'image_carousel_tag',
                    'type' => 'text',
                    'label' => __('Section Tag', 'tqb'),
                    'default' => __('Manufacturing Excellence', 'tqb'),
                ],
                [
                    'id' => 'image_carousel_title',
                    'type' => 'text',
                    'label' => __('Section Title', 'tqb'),
                    'default' => __('Inside Our Facilities', 'tqb'),
                ],
                [
                    'id' => 'image_carousel_desc',
                    'type' => 'textarea',
                    'label' => __('Section Description', 'tqb'),
                    'default' => __('State-of-the-art manufacturing equipment and quality control processes that ensure every bearing meets our exacting standards.', 'tqb'),
                ],


                [
                    'type' => 'heading',
                    'label' => __('News Section', 'tqb')
                ],
                [
                    'id' => 'news_section_tag',
                    'type' => 'text',
                    'label' => __('Section Tag', 'tqb'),
                    'default' => __('Latest Updates', 'tqb'),
                ],
                [
                    'id' => 'news_section_title',
                    'type' => 'text',
                    'label' => __('Section Title', 'tqb'),
                    'default' => __('Industry News & Insights', 'tqb'),
                ],
                [
                    'id' => 'news_section_desc',
                    'type' => 'textarea',
                    'label' => __('Section Description', 'tqb'),
                    'default' => __('Stay informed about our latest innovations, industry developments, and technical insights from our engineering team.', 'tqb'),
                ],






            ]
        ],
        'Header' => [
            'label' => __('Header', 'tqb'),
            'fields' => [
                [
                    'id' => 'welcome_message',
                    'type' => 'text',
                    'label' => __('Welcome Message', 'tqb'),
                    'desc' => __('Welcome message to display in the header.', 'tqb'),
                ],
            ]
        ],
        'footer' => [
            'label' => __('Footer', 'tqb'),
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => __('Footer', 'tqb')
                ],
                [
                    'id' => 'whatsapp_qr',
                    'type' => 'image',
                    'label' => __('WhatsApp QR Code', 'tqb'),
                    'desc' => __('Upload WhatsApp QR Code', 'tqb'),
                ],
                [
                    'id' => 'wechat_qr',
                    'type' => 'image',
                    'label' => __('WeChat QR Code', 'tqb'),
                    'desc' => __('Upload WeChat QR Code', 'tqb'),
                ],
                [
                    'id' => 'copyright',
                    'type' => 'text',
                    'label' => __('Copyright', 'tqb'),
                    'desc' => __('Copyright to display in the footer.', 'tqb'),
                ],
                [
                    'id' => 'footer_text',
                    'type' => 'wp_editor',
                    'label' => __('Footer Copyright/Text', 'tqb'),
                ],
                [
                    'id' => 'copyright',
                    'type' => 'text',
                    'label' => __('Copyright', 'tqb'),
                ],
            ]
        ],
        'Pages' => [
            'label' => __('Pages', 'tqb'),
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => __('Pages', 'tqb')
                ],
               
            ]
        ],
        'Products' => [
            'label' => __('Products', 'tqb'),
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => __('Products', 'tqb')
                ],
               
            ]
        ],
        'archive' => [
            'label' => __('Archive Settings', 'tqb'),
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => __('Archive Settings', 'tqb')
                ],
                [
                    'type'  => 'set',
                    'id'  => 'default_set',
                    'label'  => 'Test Set',

                ]
                
            ]
        ],
       
    ];

    // Initialize the Class
    new WP_Rapid_Fields_Pro($config, $tabs);


    // Product Post Meta Configuration
    $product_meta_config = [
        'id' => 'product_meta',
        'title' => __('Product Details', 'tqb'),
        'context' => 'post',
        'post_types' => ['product'],
    ];

    $product_meta_tabs = [
        'gallery' => [
            'label' => __('Gallery Settings', 'tqb'),
            'fields' => [
                [
                    'id' => 'product_gallery',
                    'type' => 'gallery',
                    'label' => __('Product Gallery', 'tqb'),
                    'desc' => __('Select multiple images for the product gallery.', 'tqb'),
                ],
            ]
        ],
        'property' => [
            'label' => __('Property Settings', 'tqb'),
            'fields' => [
                [
                    'id' => 'oem_num',
                    'type' => 'text',
                    'label' => __('OEM Number', 'tqb'),
                ],
                [
                    'id' => 'partnumber',
                    'type' => 'text',
                    'label' => __('Part Number', 'tqb'),
                ],
                [
                    'id' => 'key_features',
                    'type' => 'set',
                    'label' => __('Key Features', 'tqb'),

                ],
                [
                    'id' => 'drawing',
                    'type' => 'post_select',
                    'label' => __('Drawing', 'tqb'),
                    'multiple' => true,
                    'post_type' => 'download',
                ]

            ]
        ],

    ];

    // Initialize Product Post Meta
    new WP_Rapid_Fields_Pro($product_meta_config, $product_meta_tabs);

    // Product Category Term Meta Configuration
    $category_meta_config = [
        'id' => 'category_meta',
        'title' => __('Category Settings', 'tqb'),
        'context' => 'term',
        'taxonomy' => 'product_category',
    ];

    $category_meta_tabs = [
        'general' => [
            'label' => __('General Settings', 'tqb'),
            'fields' => [
                [
                    'id' => 'category_cover_image',
                    'type' => 'image',
                    'label' => __('Cover Image', 'tqb'),
                    'desc' => __('Upload a cover image for this category.', 'tqb'),
                    'return' => 'url',
                ],
            ]
        ]
    ];

    // Initialize Product Category Term Meta
    new WP_Rapid_Fields_Pro($category_meta_config, $category_meta_tabs);

    // Download Post Meta Configuration
    $download_meta_config = [
        'id' => 'download_meta',
        'title' => __('Download Details', 'tqb'),
        'context' => 'post',
        'post_types' => ['download'],
    ];

    $download_meta_tabs = [
        'file' => [
            'label' => __('File Settings', 'tqb'),
            'fields' => [
                [
                    'id' => 'download_file',
                    'type' => 'file',
                    'label' => __('Upload File', 'tqb'),
                    'desc' => __('Upload the specification or manual PDF.', 'tqb'),
                    'return' => 'id',
                ],
                [
                    'id' => 'related_product',
                    'type' => 'post_select',
                    'label' => __('Related Product', 'tqb'),
                    'post_type' => 'product',
                    'multiple' => true,
                    'desc' => __('Select the product(s) this download belongs to (Hold Ctrl/Cmd to select multiple).', 'tqb'),
                ],
            ]
        ]
    ];

    // Initialize Download Post Meta
    new WP_Rapid_Fields_Pro($download_meta_config, $download_meta_tabs);

    // Add Theme Options to Admin Bar
    add_action('admin_bar_menu', 'taiyuetu_admin_bar_theme_options', 999);
    function taiyuetu_admin_bar_theme_options($wp_admin_bar)
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $wp_admin_bar->add_node([
            'id' => 'tqb_options',
            'title' => __('Theme Options', 'tqb'),
            'href' => admin_url('admin.php?page=tqb_options'),
        ]);
    }

    /**
     * Bidirectional Sync for Product and Download
     * When you link a Download to a Product, the Product is automatically added to the Download's list.
     */
    add_action('save_post', 'taiyuetu_sync_relationship_meta', 20, 2);
    function taiyuetu_sync_relationship_meta($post_id, $post)
    {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            return;
        if ($post->post_status === 'auto-draft')
            return;

        $post_type = $post->post_type;
        $meta_key = '';
        $other_meta_key = '';

        if ($post_type === 'product') {
            $meta_key = 'pdf_download';
            $other_meta_key = 'related_product';
        }
        elseif ($post_type === 'download') {
            $meta_key = 'related_product';
            $other_meta_key = 'pdf_download';
        }
        else {
            return;
        }

        // We use a static variable to prevent infinite loops if we were using wp_update_post,
        // although update_post_meta doesn't trigger save_post.
        static $is_syncing = false;
        if ($is_syncing)
            return;
        $is_syncing = true;

        // Get new values from POST
        $new_values = isset($_POST[$meta_key]) ? (array)$_POST[$meta_key] : [];
        $new_values = array_map('intval', array_filter($new_values));

        // Get old values from DB (since we are at priority 20, DB might have been updated by WRF already)
        // Wait, if we are at priority 20, WRF (at 10) already updated the meta.
        // We need the "previous" state to know what was removed.
        // A better approach at priority 21 is to compare what is in the DB now with what SHOULD be in the linked posts.

        // Let's use priority 5 to get the OLD values first, then priority 20 to do the sync.
        // Or simpler: Get all posts that reference this one currently.

        $already_linked = get_posts([
            'post_type' => ($post_type === 'product' ? 'download' : 'product'),
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => $other_meta_key,
                    'value' => '"' . $post_id . '"', // Serialized IDs are stored as strings in "i:123;" or similar
                    'compare' => 'LIKE',
                ]
            ],
            'fields' => 'ids',
            'suppress_filters' => true
        ]);

        // Items that should be linked
        foreach ($new_values as $target_id) {
            $list = get_post_meta($target_id, $other_meta_key, true);
            if (!is_array($list))
                $list = $list ? [$list] : [];
            $list = array_map('intval', $list);

            if (!in_array($post_id, $list)) {
                $list[] = $post_id;
                update_post_meta($target_id, $other_meta_key, array_values(array_unique($list)));
            }
        }

        // Items that were linked but are no longer in new_values
        $to_remove = array_diff($already_linked, $new_values);
        foreach ($to_remove as $target_id) {
            $list = get_post_meta($target_id, $other_meta_key, true);
            if (!is_array($list))
                $list = $list ? [$list] : [];
            $list = array_map('intval', $list);

            $key = array_search($post_id, $list);
            if ($key !== false) {
                unset($list[$key]);
                update_post_meta($target_id, $other_meta_key, array_values($list));
            }
        }

        $is_syncing = false;
    }
}
