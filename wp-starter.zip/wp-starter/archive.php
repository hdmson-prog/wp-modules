<?php
/**
 * The template for displaying archive pages.
 *
 * @package WP_Starter
 */

get_header();
tqb_page_banner();
?>

<main id="primary" class="site-main container">
	<?php if (have_posts()): ?>

		<?php
	while (have_posts()):
		the_post();
		get_template_part('template-parts/content', get_post_type());
	endwhile;

	the_posts_navigation();
?>
	<?php
else: ?>
		<?php get_template_part('template-parts/content', 'none'); ?>
	<?php
endif; ?>
</main>

<?php
get_sidebar();
get_footer();
