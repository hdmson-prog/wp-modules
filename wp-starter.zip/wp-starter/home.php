<?php


get_header();

tqb_page_banner();

?>
<section class="news-filter-section">
        <div class="container">
            <div class="news-filter">
                <button class="filter-btn active" data-category="all"><?php esc_html_e('All News', 'tqb'); ?></button>
                <?php
$categories = get_categories(array('hide_empty' => false));
foreach ($categories as $category) {
    echo '<button class="filter-btn" data-category="' . $category->slug . '">' . $category->name . '</button>';
}
?>
            </div>
        </div>
    </section>

    <section class="news-list-section">
        <div class="container">
            <div class="news-list-grid" id="newsList">
                <?php
$news_query = new WP_Query(array(
    'post_type' => 'post',
    'posts_per_page' => -1,
));

$all_news_items = array();

if ($news_query->have_posts()) {
    while ($news_query->have_posts()) {
        $news_query->the_post();

        $categories = get_the_category();
        $category_name = !empty($categories) ? $categories[0]->name : __('Uncategorized', 'tqb');
        $category_slug = !empty($categories) ? $categories[0]->slug : 'uncategorized';

        $all_news_items[] = array(
            'id' => get_the_ID(),
            'category' => $category_slug,
            'categoryName' => $category_name,
            'title' => get_the_title(),
            'excerpt' => get_the_excerpt(),
            'date' => get_the_date('F j, Y'),
            'link' => get_permalink(),
            'featured' => has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'large') : ''
        );
    }
    wp_reset_postdata();
}
?>

                <script>
                    window.wpNewsData = <?php echo json_encode($all_news_items); ?>;
                </script>

                <div id="news-loading" style="text-align: center; padding: 50px; width: 100%;">
                    <p><?php esc_html_e('Loading news...', 'tqb'); ?></p>
                </div>

    
    </div>

            <!-- Pagination -->
            <div class="news-pagination">
                <button class="pagination-btn" id="prevPage" disabled="">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12.5 15L7.5 10L12.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                    <?php esc_html_e('Previous', 'tqb'); ?>
                </button>
                <div class="pagination-numbers" id="paginationNumbers"><button class="pagination-number active">1</button><button class="pagination-number">2</button></div>
                <button class="pagination-btn" id="nextPage">
                    <?php esc_html_e('Next', 'tqb'); ?>
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                </button>
            </div>
        </div>
    </section>

<?php get_footer(); ?>