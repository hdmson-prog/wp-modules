<?php
/**
 * The template for displaying all single posts.
 *
 * @package WP_Starter
 */

get_header();
tqb_page_banner();
?>
<section class="product-detail-section">
    <div class="container">
        <div class="product-detail-layout">
            <div class="product-images">
                <div class="product-main-image">
                    <?php
$gallery_images = ws_get_post_meta(get_the_ID(), 'product_gallery', true);
$gallery_images = explode(',', $gallery_images);
?>
                    <span class="product-badge-detail"><?php esc_html_e('Best Seller', 'tqb'); ?></span>
                    <div class="main-image-placeholder" style="opacity: 1;">
                        <?php echo wp_kses_post(wp_get_attachment_image($gallery_images[0], 'full')); ?>
                    </div>
                </div>
                <div class="product-thumbnails">
                    <?php
if (!empty($gallery_images)) {
    foreach ($gallery_images as $key => $image) {
        $image_url = wp_get_attachment_image_url($image, 'full');
?>
                            <div class="thumbnail <?php echo $key == 0 ? 'active' : ''; ?>">
                                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                            </div>
                            <?php
    }
}
?>
                </div>
            </div>

            <div class="product-info-detail">
                <h2 class="product-title-detail"><?php the_title(); ?></h2>
                <p class="product-model"><?php esc_html_e('Model:', 'tqb'); ?> <?php echo esc_html(ws_get_post_meta(get_the_ID(), 'partnumber', true)); ?></p>
                <div class="product-rating">
                    <?php product_review_starts(); ?>
                    <span class="rating-count"></span>
                </div>

                <div class="product-excerpt">
                    <p><?php echo esc_html(mb_strimwidth(strip_tags(get_the_content()), 0, 150)); ?></p>
                </div>

                <div class="product-price">
                    <span class="price-label"><a href="<?php echo esc_url(home_url('/contact')); ?>"><?php esc_html_e('Contact for Pricing', 'tqb'); ?></a></span>
                </div>

                <div class="product-meta-info">
                    <div class="meta-item">
                        <span class="meta-label"><?php esc_html_e('OEM Number:', 'tqb'); ?></span>
                        <span class="meta-value"><?php echo esc_html(ws_get_post_meta(get_the_ID(), 'oem_num', true)); ?></span>
                    </div>
                    <div class="meta-item">
                        <span class="meta-label"><?php esc_html_e('Category:', 'tqb'); ?></span>
                        <span class="meta-value"><?php echo wp_kses_post(get_the_term_list(get_the_ID(), 'product_category', '', ', ', '')); ?></span>
                    </div>
                    <div class="meta-item">
                        <span class="meta-label"><?php esc_html_e('Availability:', 'tqb'); ?></span>
                        <span class="meta-value in-stock"><?php esc_html_e('In Stock', 'tqb'); ?></span>
                    </div>
                </div>

                <div class="product-actions">
                    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary btn-large"><?php esc_html_e('Request Quote', 'tqb'); ?></a>
                    <a href="#downloads" class="btn btn-secondary btn-large"><?php esc_html_e('Download Technical Sheet', 'tqb'); ?></a>
                </div>

                <div class="product-features-quick">
                    <h3><?php esc_html_e('Key Features', 'tqb'); ?></h3>
                    <ul>
                        <?php
$key_features = ws_get_post_meta(get_the_ID(), 'key_features', true);
if (is_array($key_features)) {
    foreach ($key_features as $key_feature) {
        echo '<li>' . esc_html($key_feature) . '</li>';
    }
}
else {
    echo '<li>' . esc_html__('No key features found.', 'tqb') . '</li>';
}
?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="product-tabs-section">
    <div class="container">
        <div class="tabs-nav">
            <button class="tab-btn active" data-tab="description"><?php esc_html_e('Description', 'tqb'); ?></button>
            <button class="tab-btn" data-tab="specifications"><?php esc_html_e('Applications table', 'tqb'); ?></button>
            <button class="tab-btn" data-tab="downloads"><?php esc_html_e('Downloads', 'tqb'); ?></button>
        </div>

        <div class="tabs-content">
            <div class="tab-pane active" id="description">
                <h2><?php esc_html_e('Product Description', 'tqb'); ?></h2>
                <?php the_content(); ?>
            </div>

            <div class="tab-pane" id="specifications">
                <h2><?php esc_html_e('Applications table', 'tqb'); ?></h2>
                <div class="specs-grid">
                    <div class="spec-group">
                        <h3><?php esc_html_e('Dimensional Data', 'tqb'); ?></h3>
                        <?php echo do_shortcode('[wtm_table id="1"]'); ?>
                    </div>
                </div>
            </div>

            <div class="tab-pane" id="downloads">
                <h2><?php esc_html_e('Technical Documentation', 'tqb'); ?></h2>
                <div class="downloads-list" id="downloads">
                    <?php
$downloads = ws_get_post_meta(get_the_ID(), 'drawing', true);

if (is_array($downloads)) {
    foreach ($downloads as $download) {
        $download_id = ws_get_post_meta($download, 'download_file', true);
        $file_path = get_attached_file($download_id);
        $file_size_formatted = $file_path && file_exists($file_path)
            ? size_format(filesize($file_path))
            : esc_html__('Unknown size', 'tqb');
        $file_url = wp_get_attachment_url($download_id);
?>
                            <div class="download-item">
                                <div class="download-icon">
                                    <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 16H36M12 24H36M12 32H28" stroke="#1D4E89" stroke-width="2" stroke-linecap="round"></path>
                                        <rect x="8" y="8" width="32" height="32" rx="2" stroke="#1D4E89" stroke-width="2"></rect>
                                    </svg>
                                </div>
                                <div class="download-info">
                                    <h4><?php echo esc_html(get_the_title($download_id)); ?></h4>
                                    <p><?php echo esc_html(get_post_field('post_content', $download_id)); ?></p>
                                    <span class="download-meta"><?php echo esc_html(sprintf(__('PDF | %s', 'tqb'), $file_size_formatted)); ?></span>
                                </div>
                                <a href="<?php echo esc_url($file_url); ?>" class="download-btn" target="_blank" download="<?php echo esc_attr(get_the_title($download_id)); ?>">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M10 3V13M10 13L6 9M10 13L14 9M3 17H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                    <?php esc_html_e('Download', 'tqb'); ?>
                                </a>
                            </div>
                            <?php
    }
}
else {
    echo '<li>' . esc_html__('No downloads found.', 'tqb') . '</li>';
}
?>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="related-products">
    <div class="container">
        <h2 class="section-title"><?php esc_html_e('Related Products', 'tqb'); ?></h2>
        <div class="related-grid">
            <?php

$related = new WP_Query(array('post_type' => 'product', 'posts_per_page' => 3, 'post__not_in' => array(get_the_ID()), 'orderby' => 'rand',
));

if ($related->have_posts()) {
    while ($related->have_posts()) {
        $related->the_post();
?>
        <div class="related-product-card">

            <div class="related-product-image">
                <?php
        if (has_post_thumbnail()) {
            the_post_thumbnail();
        }
        else {
            echo '<svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="3"></circle>
                        <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="2"></circle>
                        <circle cx="40" cy="40" r="8" fill="#1D4E89"></circle>
                    </svg>';
        }
?>
            </div>
                <h3 class="related-product-name"><?php the_title(); ?></h3>
                <p class="related-product-code"><?php echo ws_get_post_meta(get_the_ID(), 'partnumber', true); ?></p>
                <a href="<?php the_permalink(); ?>" class="related-product-link"><?php esc_html_e('View Details', 'tqb'); ?></a>
            </div>

        <?php
    }
    wp_reset_postdata();
}
?>
    </div>
</section>

<?php
get_footer();
