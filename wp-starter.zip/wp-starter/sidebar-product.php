<aside class="sidebar">
    <?php if (is_active_sidebar( 'product-sidebar' )) {
        dynamic_sidebar( 'product-sidebar' );
    } ?>
                    
</aside>