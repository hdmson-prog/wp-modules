<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <?php wp_head(); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="container top-bar-container">
            <div class="top-bar-left">
                <p class="welcome-message"><?php echo ws_get_option('welcome_message'); ?></p>
            </div>
            <div class="top-bar-right">
                <div class="social-icons">
                    <?php
$social_links = ws_get_option('social_links', []);
if (!empty($social_links)):
    foreach ($social_links as $link):
        $url = !empty($link['url']) ? $link['url'] : '#';
        $title = !empty($link['title']) ? $link['title'] : '';
        $icon = !empty($link['icon']) ? $link['icon'] : '';
?>
                            <a href="<?php echo esc_url($url); ?>" class="social-link" aria-label="<?php echo esc_attr($title); ?>" target="_blank">
                                <?php echo $icon; ?>
                            </a>
                        <?php
    endforeach;
endif;
?>
                </div>

                
                <div class="top-bar-contact">

                    <a href="mailto:<?php echo ws_get_option('company_email')[0]; ?>" class="top-bar-link">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M2.5 3.5H13.5C14.0523 3.5 14.5 3.94772 14.5 4.5V11.5C14.5 12.0523 14.0523 12.5 13.5 12.5H2.5C1.94772 12.5 1.5 12.0523 1.5 11.5V4.5C1.5 3.94772 1.94772 3.5 2.5 3.5Z"
                                stroke="currentColor" stroke-width="1.5" />
                            <path d="M1.5 4.5L8 9L14.5 4.5" stroke="currentColor" stroke-width="1.5" />
                        </svg>
                        <?php echo ws_get_option('company_email')[0]; ?>
                    </a>

                    <a href="tel:<?php echo ws_get_option('company_phone'); ?>" class="top-bar-link">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M3.5 1.5C3.22386 1.5 3 1.72386 3 2V3C3 8.52285 7.47715 13 13 13H14C14.2761 13 14.5 12.7761 14.5 12.5V10C14.5 9.72386 14.2761 9.5 14 9.5L11.5 9.5C11.2239 9.5 11 9.72386 11 10V10.9C9.5 10.5 7.5 8.5 7.1 7L8 7C8.27614 7 8.5 6.77614 8.5 6.5V4C8.5 3.72386 8.27614 3.5 8 3.5H3.5Z"
                                stroke="currentColor" stroke-width="1.5" />
                        </svg>
                        <?php echo ws_get_option('company_phone'); ?>
                    </a>

                </div>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="nav" id="mainNav">
        <div class="container nav-container">
            <div class="nav-logo">
                <a href="<?php echo home_url(); ?>">    
                <?php if (ws_get_option('site_logo')) { ?>
                    <img src="<?php echo ws_get_option('site_logo'); ?>" alt="<?php bloginfo('name'); ?>">
                <?php
}
else {
?>
                    <span class="logo-text"><strong><?php esc_html_e('TQB', 'tqb'); ?></strong><?php esc_html_e('BEARINGS', 'tqb'); ?></span>
                <?php
}?>
                </a>
            </div>
       <?php
wp_nav_menu([
    'theme_location' => 'primary', // matches register_nav_menus() key
    'menu_class' => 'nav-menu', // → <ul class="nav-menu" ...>
    'menu_id' => 'navMenu', // → <ul id="navMenu" ...>
    'container' => false, // no wrapping <div>
    'walker' => new Custom_Nav_Walker(),
    'fallback_cb' => false, // hide if no menu assigned
    'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
]);
?>
            <?php if (function_exists('pll_the_languages')): ?>
            <div class="lang-switcher">
                <button class="lang-current" aria-haspopup="true" aria-expanded="false">
                    <span><?php echo esc_html(strtoupper(pll_current_language('slug'))); ?></span>
                    <svg width="10" height="6" viewBox="0 0 10 6" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1L5 5L9 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </button>
                <ul class="lang-dropdown">
                    <?php
    pll_the_languages([
        'show_flags' => 1,
        'show_names' => 1,
        'hide_current' => 1,
    ]);
?>
                </ul>
            </div>
            <?php
endif; ?>
            <button class="search-toggle" id="searchToggle" aria-label="<?php esc_attr_e('Toggle search', 'tqb'); ?>">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="8.5" cy="8.5" r="6" stroke="currentColor" stroke-width="2" />
                    <path d="M13 13L17 17" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                </svg>
            </button>
            <button class="nav-toggle" id="navToggle" aria-label="<?php esc_attr_e('Toggle navigation', 'tqb'); ?>">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </nav>
    <!-- Search Bar -->
    <div class="search-bar" id="searchBar">
        <div class="container search-container">
            <?php get_search_form(); ?>
            <button class="search-close" id="searchClose" aria-label="<?php esc_attr_e('Close search', 'tqb'); ?>">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                </svg>
            </button>
        </div>
    </div>